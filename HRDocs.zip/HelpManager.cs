﻿
#region .Imports

using System;
using System.Collections.Generic;
using System.Linq;

#endregion .Imports

namespace Intrepid.ServiceBus.Business
{
    /// <summary>
    /// 
    /// </summary>
    public static class HelpManager
    {
        //#region .Methods
        //public static Data.Article GetArticleById(Data.IntrepidServiceEntities ContextObject, int ArticleId)
        //{
        //    return new Data.GenericRepository<Data.Article>(ContextObject).GetByID(ArticleId);
        //}
        ///// <summary>
        ///// Gets the Articles.
        ///// </summary>
        ///// <param name="ContextObject">The context object.</param>
        ///// <returns></returns>
        //public static List<Data.Article> GetArticles(Data.IntrepidServiceEntities ContextObject, int SecurityUserId, string status = "", string topic = "", string keyword = "")
        //{
        //        return new Data.GenericRepository<Data.Article>(ContextObject).GetManyQueryable(q => q.CreatedBy == SecurityUserId && (string.IsNullOrEmpty(status) || q.Status == status) && (string.IsNullOrEmpty(topic) || q.ArticleDesc.ToLower().Contains(topic) || q.Summary.ToLower().Contains(topic) || q.ArticleDesc.ToLower().Contains(topic)) && (string.IsNullOrEmpty(keyword) || q.Summary.ToLower().Contains(keyword) || q.ArticleDesc.ToLower().Contains(keyword))).ToList();
        //}
        ///// <summary>
        ///// Saves the specified context object.
        ///// </summary>
        ///// <param name="ContextObject">The context object.</param>
        ///// <param name="Value">The value.</param>
        ///// <returns></returns>
        //public static bool SaveArticles(Data.IntrepidServiceEntities ContextObject, Data.Article Value)
        //{
        //    //return new Data.GenericRepository<Data.Article>(ContextObject).Save(Value);
        //    return true;
        //}
        ///// <summary>
        ///// Deletes the articles.
        ///// </summary>
        ///// <param name="ContextObject">The context object.</param>
        ///// <param name="Value">The value.</param>
        ///// <returns></returns>
        //public static bool DeleteArticles(this Hicom.Core.Client.Sql.Objects.EntityObjectContext Context, Data.Article Value)
        //{
        //    //var Context = (Data.IntrepidServiceEntities)ContextObject;
        //    //Context.addArticles.Attach(Value);
        //    Context.DeleteObject(Value);
        //    return Context.SaveChanges() > 0;
        //}
        //public static bool PublishedOrRemoveArticle(Data.IntrepidServiceEntities ContextObject, int ArticleId, bool IsDelete)
        //{
        //    Data.Article Value = Data.ArticlesQuery.ById(ContextObject,ArticleId);
        //    if (IsDelete)
        //    {
        //        return DeleteArticles(ContextObject, Value);
        //    }
        //    else
        //    {
        //        Value.Status = "Published";
        //        return SaveArticles(ContextObject, Value);
        //    }

        //}
        ///// <summary>
        ///// Gets the FAQ by identifier.
        ///// </summary>
        ///// <param name="ContextObject">The context object.</param>
        ///// <param name="Id">The identifier.</param>
        ///// <returns></returns>
        //public static Data.FAQ GetFAQById(Data.IntrepidServiceEntities ContextObject, int Id)
        //{
        //    return Data.FAQQuery.ById(ContextObject, Id);
        //}
        ///// <summary>
        ///// Gets the FAQs.
        ///// </summary>
        ///// <param name="ContextObject">The context object.</param>
        ///// <returns></returns>
        //public static List<Data.FAQ> GetFAQs(Data.IntrepidServiceEntities ContextObject, string topic = "", string keyword = "")
        //{
        //    return Data.FAQQuery.Find(ContextObject, topic, keyword).ToList();
        //}
        ///// <summary>
        ///// Saves the specified context object.
        ///// </summary>
        ///// <param name="ContextObject">The context object.</param>
        ///// <param name="Value">The value.</param>
        ///// <returns></returns>
        //public static bool SaveFAQs(Data.IntrepidServiceEntities Context, Data.FAQ Value)
        //{
        //    //var Context = (Data.IntrepidServiceEntities)ContextObject;
        //    //if (Value.EntityState != System.Data.EntityState.Modified)
        //    //    Context.AttachTo(Value.GetType().Name, Value);
        //    //if (Value.FAQId == 0) Context.ObjectStateManager.ChangeObjectState(Value, System.Data.EntityState.Added);
        //    //else Context.ObjectStateManager.ChangeObjectState(Value, System.Data.EntityState.Modified);
        //    return Context.SaveChanges() > 0;
        //}
        
        ///// <summary>
        ///// Gets the Tutorials.
        ///// </summary>
        ///// <param name="ContextObject">The context object.</param>
        ///// <returns></returns>
        //public static List<Data.Tutorials> GetTutorials(Data.IntrepidServiceEntities ContextObject, string topic = "")
        //{
        //    return Data.TutorialQuery.Find(ContextObject, topic).ToList();
        //}
        
        //#endregion .Methods
    }
}
