﻿using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Web;
using System.Web.UI;
using Wellness.Common;


public partial class ImageBrowser : System.Web.UI.Page
{
    #region Properties
    BlobFileActions blobFile;
    DiskFileActions diskFile;

    public static FileManagementLocation ManagementLocation
    {
        get
        {
            FileManagementLocation result = FileManagementLocation.FileSystem;
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[StringConstants.FILE_MANAGEMENT_LOCATION]))
            {
                if (ConfigurationManager.AppSettings[StringConstants.FILE_MANAGEMENT_LOCATION] == "2")
                    result = FileManagementLocation.BlogStorage;
            }
            return result;
        }
    }
    #endregion

    public ImageBrowser()
    {
        blobFile = new BlobFileActions();
        diskFile = new DiskFileActions();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindDirectoryList();
            ChangeDirectory(null, null);
        }
        Page.ClientScript.RegisterStartupScript(this.GetType(), "FocusImageList", "window.setTimeout(\"document.getElementById('" + ImageList.ClientID + "').focus();\", 1);", true);
    }

    protected void BindDirectoryList()
    {
        ImageFolder = "";
        string[] directories = GetDirectoriesList(FileImageFolder);
        directories = Array.ConvertAll<string, string>(directories, delegate(string directory) { return directory.Substring(directory.LastIndexOf(@"/") + 1); });
        DirectoryList.DataSource = directories;
        DirectoryList.DataBind();
        DirectoryList.Items.Insert(0, "Root");
    }

    protected void ChangeDirectory(object sender, EventArgs e)
    {        
        ImageFolder = (DirectoryList.SelectedIndex == 0) ? "" : DirectoryList.SelectedValue + "/";
        SearchTerms.Text = "";
        BindImageList();
        SelectImage(null, null);
    }    

    protected void BindImageList()
    {
        ImageList.Items.Clear();
        string[] files = GetFilesList(FileImageFolder);
        
        foreach (string file in files)
        {
            if (IsImage(file) && ManagementLocation == FileManagementLocation.BlogStorage)
            {
                ImageList.Items.Add(file.Substring(file.LastIndexOf(@"/") + 1));
            }

            if (IsImage(file) && ManagementLocation == FileManagementLocation.FileSystem)
            {
                ImageList.Items.Add(Path.GetFileName(file));
            }
        }

        if (files.Length > 0 && ImageList.Items.Count>0)
            ImageList.SelectedIndex = 0;
    }

    protected void Search(object sender, EventArgs e)
    {
        BindImageList();
    }

    protected void SelectImage(object sender, EventArgs e)
    { 
        if (ImageList.Items.Count == 0)
        {
            Image1.ImageUrl = "";            
            return;
        }

        Image1.ImageUrl = ImageFolder + ImageList.SelectedValue + "?" + new Random().Next(1000);

        int pos = ImageList.SelectedItem.Text.LastIndexOf('.');
        if (pos == -1)
            return;
        if (ManagementLocation == FileManagementLocation.FileSystem)
        {
            String strPathAndQuery = HttpContext.Current.Request.Url.PathAndQuery;
            String strUrl = HttpContext.Current.Request.Url.AbsoluteUri.Replace(strPathAndQuery, "/");

            Uri localImageUri = new Uri(strUrl + ImageFolder + ImageList.SelectedValue);
            OkButton.OnClientClick = "window.top.opener.CKEDITOR.dialog.getCurrent().setValueOf('info', 'txtUrl', '" + localImageUri + "'); window.top.close(); window.top.opener.focus();";            
        }
        else
        {
            OkButton.OnClientClick = "window.top.opener.CKEDITOR.dialog.getCurrent().setValueOf('info', 'txtUrl', encodeURI('" + ImageFolder + ImageList.SelectedValue.Replace("'", "\\'") + "')); window.top.close(); window.top.opener.focus();";
        }
    }

    protected void DeleteImage(object sender, EventArgs e)
    {
        if (ManagementLocation == FileManagementLocation.FileSystem)
        {
            string imageFullpPath = HttpContext.Current.Server.MapPath(ImageFolder) + ImageList.SelectedValue;
            diskFile.Delete(imageFullpPath);
        }
        else
        {
            blobFile.Delete(ImageFolder + ImageList.SelectedValue);
        }
        BindImageList();
    }
        

    protected void Upload(object sender, EventArgs e)
    {
        if (IsImage(UploadedImageFile.FileName))
        {
            string filename = UniqueFilename(UploadedImageFile.FileName);
            //adding full path
            string imagePath = ImageFolderRoot.StartsWith("/") ? HttpContext.Current.Server.MapPath(ImageFolderRoot) + filename : ImageFolderRoot + filename;

            byte[] image = ResizeImage(UploadedImageFile.FileBytes, 1024, 1024); //make 1024x1024 the largest image size

            if (ManagementLocation == FileManagementLocation.FileSystem)
            {                
                //string imageFullpPath = HttpContext.Current.Server.MapPath(FileImageFolder) + filename;
                diskFile.Save(UploadedImageFile.PostedFile.InputStream, imagePath);
            }
            else
            {
                blobFile.Save(UploadedImageFile.PostedFile.InputStream, imagePath);
            }

            BindImageList();
            ImageList.SelectedValue = filename;
            SelectImage(null, null);
        }
    }

    protected void Clear(object sender, EventArgs e)
    {
        Session.Remove("viewstate");
    }

    //util methods
    private bool IsImage(string file)
    {
        return file.EndsWith(".jpg", StringComparison.CurrentCultureIgnoreCase) ||
            file.EndsWith(".gif", StringComparison.CurrentCultureIgnoreCase) ||
            file.EndsWith(".png", StringComparison.CurrentCultureIgnoreCase);
    }

    protected string UniqueFilename(string filename)
    {
        string newfilename = filename;

        for (int i = 1; File.Exists(FileImageFolder + newfilename); i++)
        {
            newfilename = filename.Insert(filename.LastIndexOf('.'), "(" + i + ")");
        }

        return newfilename;
    }
       
    protected byte[] ResizeImage(byte[] imageData, int desiredWidth, int desiredHeight)
    {
        using (MemoryStream sourceBuffer = new MemoryStream(imageData))
        using (Image image = Image.FromStream(sourceBuffer))
        {
            double scale = Math.Min(desiredWidth / (double)image.Width, desiredHeight / (double)image.Height);
            if (scale >= 1) //don't enlarge photos
                return imageData;

            int width = (int)Math.Round(image.Width * scale);
            int height = (int)Math.Round(image.Height * scale);
            Bitmap bitmap = new Bitmap(width, height);

            using (Graphics graphic = Graphics.FromImage(bitmap))
            {
                graphic.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphic.DrawImage(image, 0, 0, width, height);
            }

            //keep metadata
            foreach (PropertyItem propertyItem in image.PropertyItems ?? new PropertyItem[0])
            {
                try { bitmap.SetPropertyItem(propertyItem); }
                catch { }
            }

            using (MemoryStream destinationStream = new MemoryStream())
            {
                bitmap.Save(destinationStream, image.RawFormat);
                return destinationStream.ToArray();
            }
        }
    }

    public T Parse<T>(object value)
    {
        try { return (T)TypeDescriptor.GetConverter(typeof(T)).ConvertFrom(value == null ? null : value.ToString()); }
        catch { return default(T); }
    }
    
    //properties
    protected string ImageFolderRoot
    {        
        //get { return ConfigurationManager.AppSettings[StringConstants.USER_PROFILE_IMAGE_PATH]; }
        get { return string.Format("{0}{1}", ConfigurationManager.AppSettings[StringConstants.WELLNESS_CONTENT], ConfigurationManager.AppSettings[StringConstants.CONTENT_MANAGEMENT_IMAGE_PATH]); }
    }

    protected string FileImageFolderRoot
    {       
        get { return ImageFolderRoot; }
    }

    protected string ImageFolder
    {
        get { return ImageFolderRoot + ViewState["folder"]; }
        set { ViewState["folder"] = value; }
    }

    protected string FileImageFolder
    {             
        get { return ImageFolder; }
    }

    
    #region File Actions
    public string[] GetDirectoriesList(string file)
    {
        string[] directories;

        if (ManagementLocation == FileManagementLocation.FileSystem)
        {
            directories = new FileActions(new DiskFileActions()).GetDirectoriesList(file);
        }
        else
        {
           directories = new FileActions(new BlobFileActions()).GetDirectoriesList(file);
        }

        return directories;
    }

    public string[] GetFilesList(string file)
    {
        string[] files;

        if (ManagementLocation == FileManagementLocation.FileSystem)
        {
            files = new FileActions(new DiskFileActions()).GetFilesList(file);
        }
        else
        {
            files = new FileActions(new BlobFileActions()).GetFilesList(file);
        }

        return files;
    }
    #endregion
}
