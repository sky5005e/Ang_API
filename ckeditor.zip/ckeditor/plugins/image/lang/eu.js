﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'eu', {
	alertUrl: 'Mesedez Irudiaren URLa idatzi',
	alt: 'Ordezko Testua',
	border: 'Ertza',
	btnUpload: 'Zerbitzarira bidalia',
	button2Img: 'Aukeratutako irudi botoia, irudi normal batean eraldatu nahi duzu?',
	hSpace: 'HSpace',
	img2Button: 'Aukeratutako irudia, irudi botoi batean eraldatu nahi duzu?',
	infoTab: 'Irudi informazioa',
	linkTab: 'Esteka',
	lockRatio: 'Erlazioa Blokeatu',
	menu: 'Irudi Ezaugarriak',
	resetSize: 'Tamaina Berrezarri',
	title: 'Irudi Ezaugarriak',
	titleButton: 'Irudi Botoiaren Ezaugarriak',
	upload: 'Gora Kargatu',
	urlMissing: 'Irudiaren iturburu URL-a falta da.',
	vSpace: 'VSpace',
	validateBorder: 'Ertza zenbaki oso bat izan behar da.',
	validateHSpace: 'HSpace zenbaki oso bat izan behar da.',
	validateVSpace: 'VSpace zenbaki oso bat izan behar da.'
} );
