﻿var tabCounter = 1;
function addTab(tabTitle, tabContent, tabs) {
    //Verify that Tab does not exists.
    var nameToCheck = tabTitle;
    var tabNameExists = false;
    var index = -1;
    var tabID = $(tabs).attr('id');

    $('#' + tabID + ' ul li a').each(function (i) {
        if (this.text == nameToCheck) {
            tabNameExists = true;
            index = i;
        }
    });

    if (tabNameExists) {
        tabs.tabs('option', 'active', index);
        return false;
    }

    var tabTemplate = "<li><a href='#{href}'>#{label}</a> <span class='ui-icon ui-icon-close'>Remove Tab</span></li>";

    var label = tabTitle || "Tab " + tabCounter,
        id = "tabs-" + tabCounter,
        li = $(tabTemplate.replace(/#\{href\}/g, "#" + id).replace(/#\{label\}/g, label)),
        tabContentHtml = tabContent || "Tab " + tabCounter + " content.";

    tabs.find(".ui-tabs-nav").first().append(li);
    tabs.append("<div id='" + id + "'><p>" + tabContentHtml + "</p></div>");
    tabs.tabs("refresh");

    $('#' + tabID + ' ul li a').each(function (i) {
        if (this.text == nameToCheck) {
            tabNameExists = true;
            index = i;
        }
    });

    tabs.tabs('option', 'active', index);
    tabCounter++;
    //tabs.tabs('select', tabCounter - 1);

    // Bind the event handler to handle close
    // NOTE: It is important that all the tab content is enclosed with in a form tag!
    tabs.on("click", 'span.ui-icon-close', function (e) {

        if (!e.isDefaultPrevented()) {
            e.preventDefault();

            var tabID = $(this).parent().find("a").attr("href");
            var tabContentContainer = $(tabID);

            var form = tabContentContainer.find("form");
            var formID = form.attr("id");

            if (Inforica.App.IsMyContainerDirty(formID)) {
                if (Inforica.App.PromptForDirtyFlag()) {
                    Inforica.App.CleanMyContainer(formID);
                    var panelId = $(this).closest("li").remove().attr("aria-controls");
                    $("#" + panelId).remove();
                    tabs.tabs("refresh");
                    //tabCounter--;
                }
            }
            else {
                var panelId = $(this).closest("li").remove().attr("aria-controls");
                $("#" + panelId).remove();
                tabs.tabs("refresh");
                //tabCounter--;
            }
        }

    });


}

function closeActiveTab(tabTitle) {
	/// <summary>
	/// Closes the Active Tab.
	/// </summary>
	/// <param name="tabTitle"></param>
    var index = $("#" + tabTitle).tabs('option', 'active');

    // Remove the tab
    var tab = $("#" + tabTitle).find(".ui-tabs-nav li:eq(" + index + ")").remove();
    // Find the id of the associated panel
    var panelId = tab.attr("aria-controls");
    // Remove the panel
    $("#" + panelId).remove();
}


