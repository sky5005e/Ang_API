﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.SessionState;

namespace Wellness.Areas.HRA {
    public class HRAEvaluation {
        const decimal MHR_SCORE_START = 100;

        private SqlDataAdapter daRiskReport = new SqlDataAdapter();
        private SqlDataAdapter daRiskGoal = new SqlDataAdapter();
        private SqlDataAdapter daRiskReportDetail = new SqlDataAdapter();
        private SqlDataAdapter daRiskReportActivity = new SqlDataAdapter();
        private SqlDataAdapter daRiskReportCondition = new SqlDataAdapter();
        private SqlDataAdapter daRiskReportDownload = new SqlDataAdapter();
        private SqlDataAdapter daRiskReportEmail = new SqlDataAdapter();
        private SqlDataAdapter daRiskReportGoal = new SqlDataAdapter();
        private SqlDataAdapter daRiskReportLearn = new SqlDataAdapter();
        private SqlDataAdapter daRiskReportMetric = new SqlDataAdapter();
        private SqlDataAdapter daRiskReportTool = new SqlDataAdapter();
        private SqlDataAdapter daReportSection = new SqlDataAdapter();
        private SqlDataAdapter daQuestion = new SqlDataAdapter();
        private SqlDataAdapter daQuestionGender = new SqlDataAdapter();
        private SqlDataAdapter daQuestionSuppress = new SqlDataAdapter();
        private SqlDataAdapter daAnswer = new SqlDataAdapter();
        private SqlDataAdapter daCondition = new SqlDataAdapter();
        private SqlDataAdapter daConditionEmail = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackCondition = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackConditionMatrix = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackRisk = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackRiskActivity = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackRiskDownload = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackRiskEmail = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackRiskGoal = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackRiskLearn = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackRiskMatrix = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackRiskMetric = new SqlDataAdapter();
        private SqlDataAdapter daFeedbackRiskTool = new SqlDataAdapter();
        private SqlDataAdapter daUser = new SqlDataAdapter();
        private SqlDataAdapter daUserInfo = new SqlDataAdapter();
        private SqlDataAdapter daEmailCampaign = new SqlDataAdapter();
        private SqlDataAdapter daDownload = new SqlDataAdapter();
        private SqlDataAdapter daLearnEarn = new SqlDataAdapter();
        private SqlDataAdapter daTool = new SqlDataAdapter();
        private SqlDataAdapter daMetricTracking = new SqlDataAdapter();

        private SqlCommandBuilder cbRiskReport;
        private SqlCommandBuilder cbRiskReportDetail;
        private SqlCommandBuilder cbRiskReportActivity;
        private SqlCommandBuilder cbRiskReportCondition;
        private SqlCommandBuilder cbRiskReportDownload;
        private SqlCommandBuilder cbRiskReportEmail;
        private SqlCommandBuilder cbRiskReportGoal;
        private SqlCommandBuilder cbRiskReportLearn;
        private SqlCommandBuilder cbRiskReportMetric;
        private SqlCommandBuilder cbRiskReportTool;
        private SqlCommandBuilder cbMetricTracking;

        private DataTable tblFeedback;
        private DataTable tblConditionForFeedback;
        private DataTable tblFeedbackRisk = new DataTable("hra_feedback_risk");
        private DataTable tblFeedbackRiskActivity = new DataTable("hra_feedback_risk_activity");
        private DataTable tblFeedbackRiskDownload = new DataTable("hra_feedback_risk_download");
        private DataTable tblFeedbackRiskEmail = new DataTable("hra_feedback_risk_email");
        private DataTable tblFeedbackRiskLearn = new DataTable("hra_feedback_risk_learn");
        private DataTable tblFeedbackRiskMatrix = new DataTable("hra_feedback_risk_matrix");
        private DataTable tblFeedbackRiskMetric = new DataTable("hra_feedback_risk_metric");
        private DataTable tblFeedbackRiskTool = new DataTable("hra_feedback_risk_tool");
        private DataTable tblFeedbackStandardEmail = new DataTable("hra_feedback_standard_email");
        private DataTable tblFeedbackStandardGoal = new DataTable("hra_feedback_standard_goal");
        private DataTable tblFeedbackStandardRisk = new DataTable("hra_feedback_standard_risk");
        private DataTable tblFeedbackStandardActivity = new DataTable("hra_feedback_standard_activity");
        private DataTable tblFeedbackStandardLearn = new DataTable("hra_feedback_standard_learn");
        private DataTable tblFeedbackEmail = new DataTable("hra_feedback_email");
        private DataTable tblRiskReport = new DataTable("hra_risk_report");
        private DataTable tblRiskGoal = new DataTable("hra_risk_goal");
        private DataTable tblRiskReportDetail = new DataTable("hra_risk_report_detail");
        private DataTable tblRiskReportActivity = new DataTable("hra_risk_report_activity");
        private DataTable tblRiskReportCondition = new DataTable("hra_risk_report_condition");
        private DataTable tblRiskReportDownload = new DataTable("hra_risk_report_download");
        private DataTable tblRiskReportEmail = new DataTable("hra_risk_report_email");
        private DataTable tblRiskReportGoal = new DataTable("hra_risk_report_goal");
        private DataTable tblRiskReportLearn = new DataTable("hra_risk_report_learn");
        private DataTable tblRiskReportMetric = new DataTable("hra_risk_report_metric");
        private DataTable tblRiskReportTool = new DataTable("hra_risk_report_tool");
        private DataTable tblReportSection = new DataTable("hra_report_section");
        private DataTable tblQuestion = new DataTable("hra_question");
        private DataTable tblQuestionGender = new DataTable("hra_question");
        private DataTable tblQuestionSuppress = new DataTable("hra_question_suppress");
        private DataTable tblAnswer = new DataTable("hra_answer");
        private DataTable tblCondition = new DataTable("hra_condition");
        private DataTable tblConditionEmail = new DataTable("hra_condition_email");
        private DataTable tblFeedbackCondition = new DataTable("hra_feedback_condition");
        private DataTable tblFeedbackConditionMatrix = new DataTable("hra_feedback_condition_matrix");
        private DataTable tblUser = new DataTable("user");
        private DataTable tblUserInfo = new DataTable("user_info");
        private DataTable tblEmailCampaign = new DataTable("hra_email_campaign");
        private DataTable tblDownload = new DataTable("hra_download");
        private DataTable tblLearnEarn = new DataTable("hra_learn_earn");
        private DataTable tblTool = new DataTable("hra_tool");
        private DataTable tblMetricTracking = new DataTable("metric_tracking");

        private DataRow rowRiskReport;
        private DataRow rowRiskReportDetail;
        private DataRow rowRiskReportActivity;
        private DataRow rowRiskReportCondition;
        private DataRow rowRiskReportDownload;
        private DataRow rowRiskReportEmail;
        private DataRow rowRiskReportGoal;
        private DataRow rowRiskReportLearn;
        private DataRow rowRiskReportMetric;
        private DataRow rowRiskReportTool;
        private DataRow rowQuestion;
        private DataRow rowFeedback;
        private DataRow rowConditionForFeedback;
        private DataRow rowUser;
        private DataRow rowUserInfo;
        private DataRow rowFeedbackCondition;
        private DataRow rowEmailCampaign;
        private DataRow rowDownload;
        private DataRow rowLearnEarn;
        private DataRow rowTool;
        private DataRow rowMetricTracking;

        private SqlConnection cn;

        private int intReportNum;

        private string strSQL;
        private string dbConnectionString;

        decimal decDietaryScore = 0;
        decimal decBMI = 0;
        decimal decMedicationAdherenceScore = 0;
        Boolean bolReceiveMedicationAdherence = false;

        int intWaist = 0;
        int intWeight = 0;
        int intProteinRequirement = 0;
        int intATZMin = 0;
        int intATZMax = 0;
        decimal decMHRS = MHR_SCORE_START;
        int intBioAge;

        HRAUser CurrentUser = new HRAUser();

        protected enum FeedbackCriteriaType {
            Age = 1,
            Waist = 2,
            BMI = 3,
            Dietary = 4,
            Medication = 5
        }

        protected enum FeedbackLinkType {
            Download = 1,
            LearnEarn = 2,
            Tool = 3
        }

        protected enum MetricTypes {
            Weight = 2,
            Waist = 3,
            BMI = 5,
            DietaryScore = 16,
            MHRScore = 17,
            BIOAge = 18,
            MedicationAdherence = 22,
            Age = 23
        }

        /// <summary>
        /// Evaluates a user's HRA answers and generates feedback.
        /// </summary>
        /// <param name="ReportNum"></param>
        public HRAEvaluation(int ReportNum) {
            intReportNum = ReportNum;

            dbConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SEBWellness"].ConnectionString;
            cn = new SqlConnection(dbConnectionString);
            cn.Open();
        }

        private static HttpSessionState Session {
            get { return HttpContext.Current.Session; }
        }


        public void GenerateFeedback() {
            GetRiskReportData();

            GetReportSections();
            GetQuestions();
            GetQuestionsForGender();
            GetAnswers();
            GetSuppressedQuestions();
            GetRiskFeedbackData();
            GetConditionsData();
            GetHRARelatedData();

            RemoveSuppressedQuestions();

            UpdateBMI(intReportNum);
            CalculateDietaryScore(intReportNum);
            CalculateMHRScore(intReportNum);
            CalculateProteinRequirement(intWeight);
            CalculateAerobicTrainingZones(CurrentUser.Age);
            CalculateMedicationAdherenceScore();

            CreateFeedbackTables();
            CreateFeedbackStandard();
            CreateFeedbackCustom();
            CreateFeedbackCluster();
            CreateFeedbackClusterBatches();
            CreateFeedbackCriteria(FeedbackCriteriaType.Age, CurrentUser.Age);
            CreateFeedbackCriteria(FeedbackCriteriaType.Waist, intWaist);
            CreateFeedbackCriteria(FeedbackCriteriaType.BMI, decBMI);
            CreateFeedbackCriteria(FeedbackCriteriaType.Medication, decMedicationAdherenceScore);

            CalculateRisks();

            foreach (var MetricType in Enum.GetValues(typeof(MetricTypes))) {
                switch ((int)MetricType) {
                    case (int)MetricTypes.Weight:
                        CalculateRiskMetric(MetricTypes.Weight, intWeight);
                        break;
                    case (int)MetricTypes.Waist:
                        CalculateRiskMetric(MetricTypes.Waist, intWaist);
                        break;
                    case (int)MetricTypes.BMI:
                        CalculateRiskMetric(MetricTypes.BMI, decBMI);
                        break;
                    case (int)MetricTypes.DietaryScore:
                        CalculateRiskMetric(MetricTypes.DietaryScore, decDietaryScore);
                        break;
                    case (int)MetricTypes.MHRScore:
                        CalculateRiskMetric(MetricTypes.MHRScore, decMHRS);
                        break;
                    case (int)MetricTypes.BIOAge:
                        CalculateRiskMetric(MetricTypes.BIOAge, intBioAge);
                        break;
                    case (int)MetricTypes.MedicationAdherence:
                        CalculateRiskMetric(MetricTypes.MedicationAdherence, decMedicationAdherenceScore);
                        break;
                    case (int)MetricTypes.Age:
                        CalculateRiskMetric(MetricTypes.Age, CurrentUser.Age);
                        break;
                }
            }


            CalculateConditionsForOptIn();

            UpdatePlaceHolders();
            UpdateDownloadLinks();
            UpdateDietaryScoreImages(decDietaryScore);
            UpdateBMIScoreImages(decBMI);

            SaveFeedback(intReportNum, tblFeedback);

            UpdateRiskReport(intReportNum, true);
        }

        protected void GetConditionsData() {
            strSQL = @" select  condition_num, 
                                description, 
                                feedback_section_num, 
                                tag_name, 
                                html_tag, 
                                create_date 
                        from    hra_condition";
            daCondition = new SqlDataAdapter(strSQL, cn);
            daCondition.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daCondition.Fill(tblCondition);

            strSQL = @" select  condition_num, 
                                email_campaign_num, 
                                create_date 
                        from    hra_condition_email";
            daConditionEmail = new SqlDataAdapter(strSQL, cn);
            daConditionEmail.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daConditionEmail.Fill(tblConditionEmail);

            strSQL = @" select  feedback_condition_num, 
                                condition_num, 
                                match_all, 
                                match_criteria, 
                                feedback_condition_group_num, 
                                age_min, 
                                age_max, 
                                age_restricted_included, 
                                create_date 
                        from    hra_feedback_condition";
            daFeedbackCondition = new SqlDataAdapter(strSQL, cn);
            daFeedbackCondition.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCondition.Fill(tblFeedbackCondition);

            strSQL = @" select  feedback_condition_num,
                                question_num,
                                answer_num,
                                create_date
                        from    hra_feedback_condition_matrix";
            daFeedbackConditionMatrix = new SqlDataAdapter(strSQL, cn);
            daFeedbackConditionMatrix.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackConditionMatrix.Fill(tblFeedbackConditionMatrix);
        }

        protected void GetHRARelatedData() {
            strSQL = @" select  email_campaign_num,
                                description,
                                sort_order,
                                sage_crm_field_name,
                                points,
                                create_date
                        from    hra_email_campaign";
            daEmailCampaign = new SqlDataAdapter(strSQL, cn);
            daEmailCampaign.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daEmailCampaign.Fill(tblEmailCampaign);

            strSQL = @" select  content_title, 
                                url,
                                url_text
                        from    blr_campaign_details
                        where   status = 'P' ";
            daDownload = new SqlDataAdapter(strSQL, cn);
            daDownload.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daDownload.Fill(tblDownload);

            strSQL = @" select  name, 
                                url,
                                url_text,
                                points
                        from    blr_learning
                        where   IsDeleted = 0
                        and     active = 1 ";
            daLearnEarn = new SqlDataAdapter(strSQL, cn);
            daLearnEarn.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daLearnEarn.Fill(tblLearnEarn);

            strSQL = @" select  description, 
                                url,
                                url_text
                        from    hra_tool
                        where   active = 1 ";
            daTool = new SqlDataAdapter(strSQL, cn);
            daTool.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daTool.Fill(tblTool);
        }

        protected void GetRiskFeedbackData() {
            //risk feedback
            strSQL = @" select  feedback_risk_num,
                                risk_num,
                                risk_score,
                                main_feedback,
                                summary_feedback,
                                create_date
                        from    hra_feedback_risk";
            daFeedbackRisk = new SqlDataAdapter(strSQL, cn);
            daFeedbackRisk.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackRisk.Fill(tblFeedbackRisk);

            //activity
            strSQL = @" select  feedback_risk_num,
                                activity_num,
                                points,
                                create_date
                        from    hra_feedback_risk_activity";
            daFeedbackRiskActivity = new SqlDataAdapter(strSQL, cn);
            daFeedbackRiskActivity.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackRiskActivity.Fill(tblFeedbackRiskActivity);

            //download
            strSQL = @" select  feedback_risk_num,
                                download_num,
                                points,
                                create_date
                        from    hra_feedback_risk_download";
            daFeedbackRiskDownload = new SqlDataAdapter(strSQL, cn);
            daFeedbackRiskDownload.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackRiskDownload.Fill(tblFeedbackRiskDownload);

            //email
            strSQL = @" select  feedback_risk_num,
                                email_campaign_num,
                                points,
                                create_date
                        from    hra_feedback_risk_email";
            daFeedbackRiskEmail = new SqlDataAdapter(strSQL, cn);
            daFeedbackRiskEmail.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackRiskEmail.Fill(tblFeedbackRiskEmail);

            //goal
            strSQL = @" select  risk_num,
                                risk_score,
                                goal_num,
                                create_date
                        from    hra_risk_goal";
            daRiskGoal = new SqlDataAdapter(strSQL, cn);
            daRiskGoal.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskGoal.Fill(tblRiskGoal);

            //learn
            strSQL = @" select  feedback_risk_num,
                                learn_num,
                                points,
                                create_date
                        from    hra_feedback_risk_learn";
            daFeedbackRiskLearn = new SqlDataAdapter(strSQL, cn);
            daFeedbackRiskLearn.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackRiskLearn.Fill(tblFeedbackRiskLearn);

            //matrix
            strSQL = @" select   feedback_risk_num,
                                 question_num,
                                 answer_num,
                                 create_date
                        from     hra_feedback_risk_matrix 
                        order by feedback_risk_num, 
                                 question_num, 
                                 answer_num";
            daFeedbackRiskMatrix = new SqlDataAdapter(strSQL, cn);
            daFeedbackRiskMatrix.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackRiskMatrix.Fill(tblFeedbackRiskMatrix);

            //metric
            strSQL = @" select  feedback_risk_num,
                                metric_type_num,
                                gender,
                                metric_min,
                                metric_max,
                                create_date
                        from    hra_feedback_risk_metric 
                        where   gender = '" + CurrentUser.Gender + "'";
            daFeedbackRiskMetric = new SqlDataAdapter(strSQL, cn);
            daFeedbackRiskMetric.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackRiskMetric.Fill(tblFeedbackRiskMetric);

            //tool
            strSQL = @" select  feedback_risk_num,
                                tool_num,
                                points,
                                create_date
                        from    hra_feedback_risk_tool";
            daFeedbackRiskTool = new SqlDataAdapter(strSQL, cn);
            daFeedbackRiskTool.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackRiskTool.Fill(tblFeedbackRiskTool);
        }

        protected void CalculateRisks() {
            bool bolReceiveRiskFeedback = false;
            int intFeedbackRiskNum;
            int intPreviousFeedbackRiskNum;
            int intQuestionNum;
            int intAnswerNum;
            int intRiskNum;
            object[] objPK2 = new object[2];

            intPreviousFeedbackRiskNum = 0;
            bolReceiveRiskFeedback = true;

            foreach (DataRow rowFeedbackRiskMatrix in tblFeedbackRiskMatrix.Rows) {
                intFeedbackRiskNum = (int)rowFeedbackRiskMatrix["feedback_risk_num"];
                intQuestionNum = (int)rowFeedbackRiskMatrix["question_num"];
                intAnswerNum = (int)rowFeedbackRiskMatrix["answer_num"];

                if (intFeedbackRiskNum == intPreviousFeedbackRiskNum || intPreviousFeedbackRiskNum == 0) {
                    if (bolReceiveRiskFeedback == true) {
                        objPK2[0] = intReportNum;
                        objPK2[1] = intQuestionNum;
                        rowRiskReportDetail = tblRiskReportDetail.Rows.Find(objPK2);

                        if (rowRiskReportDetail == null) {
                            bolReceiveRiskFeedback = false;
                        }
                        else {
                            if ((int)rowRiskReportDetail["answer_num"] != intAnswerNum) {
                                bolReceiveRiskFeedback = false;
                            }
                        }
                    }
                }
                else {
                    if (bolReceiveRiskFeedback == true) {
                        AddFeedbackRisk(intReportNum, intPreviousFeedbackRiskNum);
                    }

                    bolReceiveRiskFeedback = true;

                    //check the current matrix value
                    objPK2[0] = intReportNum;
                    objPK2[1] = intQuestionNum;
                    rowRiskReportDetail = tblRiskReportDetail.Rows.Find(objPK2);

                    if (rowRiskReportDetail == null) {
                        bolReceiveRiskFeedback = false;
                    }
                    else {
                        if ((int)rowRiskReportDetail["answer_num"] != intAnswerNum) {
                            bolReceiveRiskFeedback = false;
                        }
                    }
                }

                intPreviousFeedbackRiskNum = intFeedbackRiskNum;
            }

            //check last matrix for valid feedback
            if (intPreviousFeedbackRiskNum != 0 && bolReceiveRiskFeedback == true) {
                AddFeedbackRisk(intReportNum, intPreviousFeedbackRiskNum);
            }
        }

        protected void CalculateConditionsForOptIn() {
            bool bolReceiveCondition;

            int intFeedbackConditionNum;
            int intPreviousFeedbackConditionNum;
            int intQuestionNum;
            int intAnswerNum;

            object[] objPK2 = new object[2];

            intPreviousFeedbackConditionNum = 0;
            bolReceiveCondition = true;

            foreach (DataRow rowFeedbackConditionMatrix in tblFeedbackConditionMatrix.Rows) {
                intFeedbackConditionNum = (int)rowFeedbackConditionMatrix["feedback_condition_num"];
                intQuestionNum = (int)rowFeedbackConditionMatrix["question_num"];
                intAnswerNum = (int)rowFeedbackConditionMatrix["answer_num"];

                if (intFeedbackConditionNum == intPreviousFeedbackConditionNum || intPreviousFeedbackConditionNum == 0) {
                    if (bolReceiveCondition == true) {
                        objPK2[0] = intReportNum;
                        objPK2[1] = intQuestionNum;
                        rowRiskReportDetail = tblRiskReportDetail.Rows.Find(objPK2);

                        if (rowRiskReportDetail == null) {
                            bolReceiveCondition = false;
                        }
                        else {
                            if ((int)rowRiskReportDetail["answer_num"] != intAnswerNum) {
                                bolReceiveCondition = false;
                            }
                        }
                    }
                }
                else {
                    if (bolReceiveCondition == true) {
                        AddFeedbackCondition(intReportNum, intPreviousFeedbackConditionNum);
                    }

                    bolReceiveCondition = true;

                    //check the current matrix value
                    objPK2[0] = intReportNum;
                    objPK2[1] = intQuestionNum;
                    rowRiskReportDetail = tblRiskReportDetail.Rows.Find(objPK2);

                    if (rowRiskReportDetail == null) {
                        bolReceiveCondition = false;
                    }
                    else {
                        if ((int)rowRiskReportDetail["answer_num"] != intAnswerNum) {
                            bolReceiveCondition = false;
                        }
                    }
                }

                intPreviousFeedbackConditionNum = intFeedbackConditionNum;
            }

            //check last matrix for valid feedback
            if (intPreviousFeedbackConditionNum != 0 && bolReceiveCondition == true) {
                AddFeedbackCondition(intReportNum, intPreviousFeedbackConditionNum);
            }
        }

        protected void CalculateRiskMetric(MetricTypes MetricType, decimal MetricValue) {
            tblFeedbackRiskMetric.DefaultView.RowFilter = "metric_type_num = " + ((int)MetricType).ToString();
            tblFeedbackRiskMetric.DefaultView.Sort = "metric_min, metric_max";

            foreach (DataRow rowRiskMetric in tblFeedbackRiskMetric.DefaultView.ToTable().Rows) {
                if (MetricValue > (decimal)rowRiskMetric["metric_min"] && MetricValue <= (decimal)rowRiskMetric["metric_max"]) {
                    AddFeedbackRisk(intReportNum, (int)rowRiskMetric["feedback_risk_num"]);
                }
            }
        }

        protected void AddEmailCampaign(int ReportNum, int EmailCampaignNum) {
            object[] objPK2 = new object[2];
            object[] objPK1 = new object[1];

            //get condition first
            objPK1[0] = EmailCampaignNum;
            rowEmailCampaign = tblEmailCampaign.Rows.Find(objPK1);

            if (rowEmailCampaign != null) {
                objPK2[0] = ReportNum;
                objPK2[1] = EmailCampaignNum;
                rowRiskReportEmail = tblRiskReportEmail.Rows.Find(objPK2);

                if (rowRiskReportEmail == null) {
                    rowRiskReportEmail = tblRiskReportEmail.NewRow();
                    rowRiskReportEmail["risk_report_num"] = ReportNum;
                    rowRiskReportEmail["email_campaign_num"] = EmailCampaignNum;
                    rowRiskReportEmail["metric"] = 0;
                    rowRiskReportEmail["points_earned"] = 0;
                    rowRiskReportEmail["opted_out"] = 0;
                    rowRiskReportEmail["status_num"] = 0;
                    rowRiskReportEmail["create_date"] = DateTime.UtcNow;
                    tblRiskReportEmail.Rows.Add(rowRiskReportEmail);
                    daRiskReportEmail.Update(tblRiskReportEmail);
                }
            }
        }

        protected void AddFeedbackCondition(int ReportNum, int FeedbackConditionNum) {
            object[] objPK1 = new object[1];

            //get condition first
            objPK1[0] = FeedbackConditionNum;
            rowFeedbackCondition = tblFeedbackCondition.Rows.Find(objPK1);

            if (rowFeedbackCondition != null) {
                AddCondition(ReportNum, (int)rowFeedbackCondition["condition_num"]);
            }
        }

        protected void AddCondition(int ReportNum, int ConditionNum) {
            object[] objPK2 = new object[2];

            objPK2[0] = ReportNum;
            objPK2[1] = ConditionNum;
            rowRiskReportCondition = tblRiskReportCondition.Rows.Find(objPK2);

            if (rowRiskReportCondition == null) {
                rowRiskReportCondition = tblRiskReportCondition.NewRow();
                rowRiskReportCondition["risk_report_num"] = ReportNum;
                rowRiskReportCondition["condition_num"] = ConditionNum;
                rowRiskReportCondition["create_date"] = DateTime.UtcNow;
                tblRiskReportCondition.Rows.Add(rowRiskReportCondition);
                daRiskReportCondition.Update(tblRiskReportCondition);
            }
        }

        protected void AddFeedbackRisk(int ReportNum, int FeedbackRiskNum) {
            object[] objPK2 = new object[2];

            //add metric
            objPK2[0] = ReportNum;
            objPK2[1] = FeedbackRiskNum;
            rowRiskReportMetric = tblRiskReportMetric.Rows.Find(objPK2);

            if (rowRiskReportMetric == null) {
                rowRiskReportMetric = tblRiskReportMetric.NewRow();
                rowRiskReportMetric["risk_report_num"] = ReportNum;
                rowRiskReportMetric["feedback_risk_num"] = FeedbackRiskNum;
                rowRiskReportMetric["create_date"] = DateTime.UtcNow;
                tblRiskReportMetric.Rows.Add(rowRiskReportMetric);
                daRiskReportMetric.Update(tblRiskReportMetric);
            }

            //add activity
            tblFeedbackRiskActivity.DefaultView.RowFilter = "feedback_risk_num = " + FeedbackRiskNum.ToString();

            foreach (DataRow rowFeedbackRiskActivity in tblFeedbackRiskActivity.DefaultView.ToTable().Rows) {
                objPK2[0] = ReportNum;
                objPK2[1] = rowFeedbackRiskActivity["activity_num"];
                rowRiskReportActivity = tblRiskReportActivity.Rows.Find(objPK2);

                if (rowRiskReportActivity == null) {
                    rowRiskReportActivity = tblRiskReportActivity.NewRow();
                    rowRiskReportActivity["risk_report_num"] = ReportNum;
                    rowRiskReportActivity["activity_num"] = rowFeedbackRiskActivity["activity_num"];
                    rowRiskReportActivity["metric"] = 0;
                    rowRiskReportActivity["points_earned"] = 0;
                    rowRiskReportActivity["status_num"] = 0;
                    rowRiskReportActivity["create_date"] = DateTime.UtcNow;
                    tblRiskReportActivity.Rows.Add(rowRiskReportActivity);
                    daRiskReportActivity.Update(tblRiskReportActivity);
                }
            }

            //add download
            tblFeedbackRiskDownload.DefaultView.RowFilter = "feedback_risk_num = " + FeedbackRiskNum.ToString();

            foreach (DataRow rowFeedbackRiskDownload in tblFeedbackRiskDownload.DefaultView.ToTable().Rows) {
                objPK2[0] = ReportNum;
                objPK2[1] = rowFeedbackRiskDownload["download_num"];
                rowRiskReportDownload = tblRiskReportDownload.Rows.Find(objPK2);

                if (rowRiskReportDownload == null) {
                    rowRiskReportDownload = tblRiskReportDownload.NewRow();
                    rowRiskReportDownload["risk_report_num"] = ReportNum;
                    rowRiskReportDownload["download_num"] = rowFeedbackRiskDownload["download_num"];
                    rowRiskReportDownload["metric"] = 0;
                    rowRiskReportDownload["points_earned"] = 0;
                    rowRiskReportDownload["status_num"] = 0;
                    rowRiskReportDownload["create_date"] = DateTime.UtcNow;
                    tblRiskReportDownload.Rows.Add(rowRiskReportDownload);
                    daRiskReportDownload.Update(tblRiskReportDownload);
                }
            }

            //add email
            tblFeedbackRiskEmail.DefaultView.RowFilter = "feedback_risk_num = " + FeedbackRiskNum.ToString();

            foreach (DataRow rowFeedbackRiskEmail in tblFeedbackRiskEmail.DefaultView.ToTable().Rows) {
                AddEmailCampaign(intReportNum, (int)rowFeedbackRiskEmail["email_campaign_num"]);
            }

            //add goal
            AddRiskGoal(ReportNum, FeedbackRiskNum);

            //add learn
            tblFeedbackRiskLearn.DefaultView.RowFilter = "feedback_risk_num = " + FeedbackRiskNum.ToString();

            foreach (DataRow rowFeedbackRiskLearn in tblFeedbackRiskLearn.DefaultView.ToTable().Rows) {
                objPK2[0] = ReportNum;
                objPK2[1] = rowFeedbackRiskLearn["learn_num"];
                rowRiskReportLearn = tblRiskReportLearn.Rows.Find(objPK2);

                if (rowRiskReportLearn == null) {
                    rowRiskReportLearn = tblRiskReportLearn.NewRow();
                    rowRiskReportLearn["risk_report_num"] = ReportNum;
                    rowRiskReportLearn["learn_num"] = rowFeedbackRiskLearn["learn_num"];
                    rowRiskReportLearn["create_date"] = DateTime.UtcNow;
                    tblRiskReportLearn.Rows.Add(rowRiskReportLearn);
                    daRiskReportLearn.Update(tblRiskReportLearn);
                }
            }

            //add tool
            tblFeedbackRiskTool.DefaultView.RowFilter = "feedback_risk_num = " + FeedbackRiskNum.ToString();

            foreach (DataRow rowFeedbackRiskTool in tblFeedbackRiskTool.DefaultView.ToTable().Rows) {
                objPK2[0] = ReportNum;
                objPK2[1] = rowFeedbackRiskTool["tool_num"];
                rowRiskReportTool = tblRiskReportTool.Rows.Find(objPK2);

                if (rowRiskReportTool == null) {
                    rowRiskReportTool = tblRiskReportTool.NewRow();
                    rowRiskReportTool["risk_report_num"] = ReportNum;
                    rowRiskReportTool["tool_num"] = rowFeedbackRiskTool["tool_num"];
                    rowRiskReportTool["metric"] = 0;
                    rowRiskReportTool["points_earned"] = 0;
                    rowRiskReportTool["status_num"] = 1;
                    rowRiskReportTool["create_date"] = DateTime.UtcNow;
                    tblRiskReportTool.Rows.Add(rowRiskReportTool);
                    daRiskReportTool.Update(tblRiskReportTool);
                }
            }
        }

        protected void AddRiskGoal(int ReportNum, int FeedbackRiskNum) {
            object[] objPK2 = new object[2];
            int RiskNum;
            int RiskScore;

            DataRow rowFeedbackRisk = tblFeedbackRisk.Rows.Find(FeedbackRiskNum);

            if (rowFeedbackRisk != null) {
                RiskNum = (int)rowFeedbackRisk["risk_num"];
                RiskScore = (int)rowFeedbackRisk["risk_score"];
                tblRiskGoal.DefaultView.RowFilter = "risk_num = " + RiskNum.ToString() + " and risk_score = " + RiskScore.ToString();

                foreach (DataRow rowRiskGoal in tblRiskGoal.DefaultView.ToTable().Rows) {
                    objPK2[0] = ReportNum;
                    objPK2[1] = rowRiskGoal["goal_num"];
                    rowRiskReportGoal = tblRiskReportGoal.Rows.Find(objPK2);

                    if (rowRiskReportGoal == null) {
                        rowRiskReportGoal = tblRiskReportGoal.NewRow();
                        rowRiskReportGoal["risk_report_num"] = ReportNum;
                        rowRiskReportGoal["goal_num"] = rowRiskGoal["goal_num"];
                        rowRiskReportGoal["metric"] = 0;
                        rowRiskReportGoal["points_earned"] = 0;
                        rowRiskReportGoal["goal_set"] = 0;
                        rowRiskReportGoal["goal_type"] = 1;
                        rowRiskReportGoal["status_num"] = 1;
                        rowRiskReportGoal["create_date"] = DateTime.UtcNow;
                        tblRiskReportGoal.Rows.Add(rowRiskReportGoal);
                        daRiskReportGoal.Update(tblRiskReportGoal);
                    }
                }
            }
        }

        protected void GetRiskReportData() {
            strSQL = @" select  risk_report_num,
                                user_id,
                                bmi,
                                dietary_score,
                                waist,
                                weight,
                                mhrs_score,
                                bio_age,
                                completed,
                                IsSyncRequired,
                                LastSyncedDate,
                                show_welcome_msg,
                                IsDeleted,
                                create_date
                        from    hra_risk_report 
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReport = new SqlDataAdapter(strSQL, cn);
            cbRiskReport = new SqlCommandBuilder(daRiskReport);
            tblRiskReport.Clear();
            daRiskReport.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReport.Fill(tblRiskReport);

            if (tblRiskReport.Rows.Count > 0) {
                rowRiskReport = tblRiskReport.Rows[0];

                intWaist = (int)rowRiskReport["waist"];
                CurrentUser.ID = rowRiskReport["user_id"].ToString();
                GetUserProfile(CurrentUser.ID);
            }

            strSQL = @" select  risk_report_num,
                                question_num,
                                answer_num,
                                create_date
                        from    hra_risk_report_detail 
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReportDetail = new SqlDataAdapter(strSQL, cn);
            cbRiskReportDetail = new SqlCommandBuilder(daRiskReportDetail);
            tblRiskReportDetail.Clear();
            daRiskReportDetail.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportDetail.Fill(tblRiskReportDetail);


            //simply fetch schema for tables as no data will exist for the new risk report

            //activity
            strSQL = @" select  risk_report_num,
                                activity_num,
                                metric,
                                points_earned,
                                status_num,
                                start_date,
                                end_date,
                                complete_date
                                user_input,
                                create_date
                        from    hra_risk_report_activity 
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReportActivity = new SqlDataAdapter(strSQL, cn);
            cbRiskReportActivity = new SqlCommandBuilder(daRiskReportActivity);
            tblRiskReportActivity.Clear();
            daRiskReportActivity.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportActivity.Fill(tblRiskReportActivity);

            //condition
            strSQL = @" select  risk_report_num,
                                condition_num,
                                create_date
                        from    hra_risk_report_condition 
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReportCondition = new SqlDataAdapter(strSQL, cn);
            cbRiskReportCondition = new SqlCommandBuilder(daRiskReportCondition);
            tblRiskReportCondition.Clear();
            daRiskReportCondition.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportCondition.Fill(tblRiskReportCondition);

            //download
            strSQL = @" select  risk_report_num,
                                download_num,
                                metric,
                                points_earned,
                                status_num,
                                start_date,
                                end_date,
                                complete_date
                                user_input,
                                create_date
                        from    hra_risk_report_download 
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReportDownload = new SqlDataAdapter(strSQL, cn);
            cbRiskReportDownload = new SqlCommandBuilder(daRiskReportDownload);
            tblRiskReportDownload.Clear();
            daRiskReportDownload.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportDownload.Fill(tblRiskReportDownload);

            //email
            strSQL = @" select  risk_report_num,
                                email_campaign_num,
                                metric,
                                points_earned,
                                opted_out,
                                status_num,
                                start_date,
                                end_date,
                                complete_date
                                user_input,
                                create_date
                        from    hra_risk_report_email 
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReportEmail = new SqlDataAdapter(strSQL, cn);
            cbRiskReportEmail = new SqlCommandBuilder(daRiskReportEmail);
            tblRiskReportEmail.Clear();
            daRiskReportEmail.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportEmail.Fill(tblRiskReportEmail);

            //goal
            strSQL = @" select  risk_report_num,
                                goal_num,
                                metric,
                                points_earned,
                                goal_set,
                                goal_type,
                                status_num,
                                start_date,
                                end_date,
                                complete_date
                                user_input,
                                is_dont_show,
                                create_date
                        from    hra_risk_report_goal
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReportGoal = new SqlDataAdapter(strSQL, cn);
            cbRiskReportGoal = new SqlCommandBuilder(daRiskReportGoal);
            tblRiskReportGoal.Clear();
            daRiskReportGoal.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportGoal.Fill(tblRiskReportGoal);

            //learn
            strSQL = @" select  risk_report_num,
                                learn_num,
                                create_date
                        from    hra_risk_report_learn
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReportLearn = new SqlDataAdapter(strSQL, cn);
            cbRiskReportLearn = new SqlCommandBuilder(daRiskReportLearn);
            tblRiskReportLearn.Clear();
            daRiskReportLearn.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportLearn.Fill(tblRiskReportLearn);

            //metric
            strSQL = @" select  risk_report_num,
                                feedback_risk_num,
                                create_date
                        from    hra_risk_report_metric 
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReportMetric = new SqlDataAdapter(strSQL, cn);
            cbRiskReportMetric = new SqlCommandBuilder(daRiskReportMetric);
            tblRiskReportMetric.Clear();
            daRiskReportMetric.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportMetric.Fill(tblRiskReportMetric);

            //tool
            strSQL = @" select  risk_report_num,
                                tool_num,
                                metric,
                                points_earned,
                                status_num,
                                start_date,
                                end_date,
                                complete_date
                                user_input,
                                create_date
                        from    hra_risk_report_tool
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReportTool = new SqlDataAdapter(strSQL, cn);
            cbRiskReportTool = new SqlCommandBuilder(daRiskReportTool);
            tblRiskReportTool.Clear();
            daRiskReportTool.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportTool.Fill(tblRiskReportTool);

            strSQL = @" select  top 1 metric_tracking_num,
                                metric_type_num,
                                metric_source_num,
                                user_id,
                                metric,
                                uom_num,
                                create_date,
                                create_user
                        from    metric_tracking
                        where   user_id = '" + CurrentUser.ID + "'";

            daMetricTracking = new SqlDataAdapter(strSQL, cn);
            cbMetricTracking = new SqlCommandBuilder(daMetricTracking);
            tblMetricTracking = new DataTable();
            daMetricTracking.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daMetricTracking.Fill(tblMetricTracking);
        }

        private void GetUserProfile(string UserId) {
            if (UserId == null || UserId == "") {
                return;
            }

            strSQL = @" select  Id,
                                LastLogin,
                                FirstName,
                                LastName,
                                Email,
                                EmailConfirmed,
                                PasswordHash,
                                SecurityStamp,
                                PhoneNumber,
                                TwoFactorEnabled,
                                LockoutEndDateUtc,
                                LockoutEnabled,
                                AccessFailedCount,
                                UserName
                        from    AspNetUsers 
                        where   Id = '" + UserId + "'";

            daUser = new SqlDataAdapter(strSQL, cn);
            tblUser.Clear();
            daUser.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daUser.Fill(tblUser);

            if (tblUser.Rows.Count > 0) {
                rowUser = tblUser.Rows[0];

                CurrentUser.FirstName = rowUser["FirstName"].ToString();
                CurrentUser.Surname = rowUser["LastName"].ToString();
            }

            daUser.Dispose();

            strSQL = @" select  ASPNetUserId,
                                DateOfBirth,
                                Height,
                                Gender,
                                ProfileImage,
                                RegistrationDate
                        from    AspNetUsersInfo 
                        where   ASPNetUserId = '" + UserId + "'";

            daUserInfo = new SqlDataAdapter(strSQL, cn);
            tblUserInfo.Clear();
            daUserInfo.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daUserInfo.Fill(tblUserInfo);

            if (tblUserInfo.Rows.Count > 0) {
                rowUserInfo = tblUserInfo.Rows[0];

                CurrentUser.Gender = rowUserInfo["Gender"].ToString();
                CurrentUser.DOB = (DateTime)rowUserInfo["DateOfBirth"];
                CurrentUser.Height = (int)rowUserInfo["Height"];
            }

            daUserInfo.Dispose();
        }

        protected void RemoveSuppressedQuestions() {
            int intQuestionNum;
            int intAnswerNum;
            int intQuestionNumSuppress;
            object[] objPK2 = new object[2];

            foreach (DataRow rowQuestionSuppress in tblQuestionSuppress.Rows) {
                intQuestionNum = (int)rowQuestionSuppress["question_num"];
                intAnswerNum = (int)rowQuestionSuppress["answer_num"];
                intQuestionNumSuppress = (int)rowQuestionSuppress["question_num_suppress"];
                objPK2[0] = intReportNum;
                objPK2[1] = intQuestionNum;

                rowRiskReportDetail = tblRiskReportDetail.Rows.Find(objPK2);

                if (rowRiskReportDetail != null) {
                    if ((int)rowRiskReportDetail["answer_num"] == intAnswerNum) {
                        objPK2[0] = intReportNum;
                        objPK2[1] = intQuestionNumSuppress;

                        rowRiskReportDetail = tblRiskReportDetail.Rows.Find(objPK2);

                        if (rowRiskReportDetail != null) {
                            rowRiskReportDetail.Delete();
                            daRiskReportDetail.Update(tblRiskReportDetail);
                        }
                    }
                }
            }
        }

        protected void GetReportSections() {
            //get sections for user's gender and unisex questions
            strSQL = @" select  report_section_num,
                                title,
                                description,
                                sort_order,
                                active,
                                create_date
                        from    hra_report_section
                        where   report_section_num in (select distinct(report_section_num)
                                                     from hra_question
                                                     where gender in ('" + (CurrentUser.Gender == "1" || CurrentUser.Gender == "M" ? "M" : "F") + @"','U')
                                                     and age_min <= " + CurrentUser.Age.ToString() + @"
                                                     and age_max >= " + CurrentUser.Age.ToString() + @"
                                                     and active = 1)
                        order by sort_order";

            daReportSection = new SqlDataAdapter(strSQL, cn);
            tblReportSection.Clear();
            daReportSection.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daReportSection.Fill(tblReportSection);
            daReportSection.Dispose();
        }

        protected void GetQuestions() {
            strSQL = @" select      q.question_num,
                                    q.report_section_num,
                                    q.gender,
                                    q.sort_order,
                                    q.question,
                                    q.question_french,
                                    q.active,
                                    q.age_min,
                                    q.age_max,
                                    q.question_type,
                                    q.question_group_num,
                                    q.qm,
                                    q.qf,
                                    q.qmh,
                                    q.mh_map_ref,
                                    q.create_date, 
                                    qg.preamble
                        from        hra_question q
                        left join   hra_question_group qg on qg.question_group_num = q.question_group_num
                        where       q.gender in ('" + (CurrentUser.Gender == "1" || CurrentUser.Gender == "M" ? "M" : "F") + @"','U')
                        and         q.age_min <= " + CurrentUser.Age.ToString() + @"
                        and         q.age_max >= " + CurrentUser.Age.ToString() + @"
                        and         q.active = 1
                        order by    q.report_section_num, 
                                    q.sort_order";

            daQuestion = new SqlDataAdapter(strSQL, cn);
            tblQuestion.Clear();
            daQuestion.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daQuestion.Fill(tblQuestion);
            daQuestion.Dispose();
        }

        protected void GetQuestionsForGender() {
            strSQL = @" select      q.question_num,
                                    q.report_section_num,
                                    q.gender,
                                    q.sort_order,
                                    q.question,
                                    q.question_french,
                                    q.active,
                                    q.age_min,
                                    q.age_max,
                                    q.question_type,
                                    q.question_group_num,
                                    q.qm,
                                    q.qf,
                                    q.qmh,
                                    q.mh_map_ref,
                                    q.create_date, 
                                    qg.preamble
                        from        hra_question q
                        left join   hra_question_group qg on qg.question_group_num = q.question_group_num
                        where       q.gender in ('" + (CurrentUser.Gender == "1" || CurrentUser.Gender == "M" ? "M" : "F") + @"','U')
                        and         q.active = 1
                        order by    q.report_section_num, 
                                    q.sort_order";

            daQuestionGender = new SqlDataAdapter(strSQL, cn);
            tblQuestionGender.Clear();
            daQuestionGender.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daQuestionGender.Fill(tblQuestionGender);
            daQuestionGender.Dispose();
        }

        protected void GetAnswers() {
            strSQL = @" select      question_num,
                                    answer_num,
                                    answer,
                                    answer_french,
                                    sort_order,
                                    active,
                                    mhrs,
                                    dietary,
                                    reward_points,
                                    default_answer,
                                    create_date
                        from        hra_answer
                        order by    question_num, 
                                    sort_order";
            daAnswer = new SqlDataAdapter(strSQL, cn);
            tblAnswer.Clear();
            daAnswer.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daAnswer.Fill(tblAnswer);
            daAnswer.Dispose();
        }

        protected void GetSuppressedQuestions() {
            strSQL = @" select  question_num,
                                answer_num,
                                question_num_suppress,
                                create_date
                        from    hra_question_suppress";

            daQuestionSuppress = new SqlDataAdapter(strSQL, cn);
            tblQuestionSuppress.Clear();
            daQuestionSuppress.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daQuestionSuppress.Fill(tblQuestionSuppress);
            daQuestionSuppress.Dispose();
        }

        protected void CreateFeedbackTables() {
            //general feedback table
            tblFeedback = new DataTable();
            tblConditionForFeedback = new DataTable();
            DataColumn col;
            DataColumn[] colPK1 = new DataColumn[1];
            DataColumn[] colPK2 = new DataColumn[2];


            col = new DataColumn();
            col.ColumnName = "FeedbackNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AutoIncrement = true;
            col.AutoIncrementSeed = 1;
            col.AutoIncrementStep = 1;
            col.AllowDBNull = false;
            col.Unique = true;
            colPK1[0] = col;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "FeedbackSectionNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "FeedbackClusterGroupNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "SortOrder";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "ConditionNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = true;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "ClusterNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = true;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "CriteriaNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = true;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "CustomNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = true;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "StandardNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = true;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "QuestionNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "AnswerNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "MainFeedback";
            col.DataType = System.Type.GetType("System.String");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "SummaryFeedback";
            col.DataType = System.Type.GetType("System.String");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "Description";
            col.DataType = System.Type.GetType("System.String");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "Nutrition";
            col.DataType = System.Type.GetType("System.String");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "Supplements";
            col.DataType = System.Type.GetType("System.String");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "OtherConsiderations";
            col.DataType = System.Type.GetType("System.String");
            col.AllowDBNull = false;
            col.Unique = false;
            tblFeedback.Columns.Add(col);

            tblFeedback.PrimaryKey = colPK1;

            //Conditions for feedback table
            col = new DataColumn();
            col.ColumnName = "FeedbackNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            tblConditionForFeedback.Columns.Add(col);
            colPK2[0] = col;

            col = new DataColumn();
            col.ColumnName = "ConditionNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = true;
            col.Unique = false;
            colPK2[1] = col;
            tblConditionForFeedback.Columns.Add(col);

            tblConditionForFeedback.PrimaryKey = colPK2;

            //standard feedback email campaigns
            tblFeedbackStandardEmail = new DataTable();

            col = new DataColumn();
            col.ColumnName = "FeedbackStandardNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            colPK2[0] = col;
            tblFeedbackStandardEmail.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "EmailCampaignNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            colPK2[1] = col;
            tblFeedbackStandardEmail.Columns.Add(col);

            tblFeedbackStandardEmail.PrimaryKey = colPK2;

            //standard feedback goals
            tblFeedbackStandardGoal = new DataTable();

            col = new DataColumn();
            col.ColumnName = "FeedbackStandardNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            colPK2[0] = col;
            tblFeedbackStandardGoal.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "GoalNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            colPK2[1] = col;
            tblFeedbackStandardGoal.Columns.Add(col);

            tblFeedbackStandardGoal.PrimaryKey = colPK2;

            //standard feedback risks
            tblFeedbackStandardRisk = new DataTable();

            col = new DataColumn();
            col.ColumnName = "FeedbackStandardNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            colPK2[0] = col;
            tblFeedbackStandardRisk.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "RiskNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            colPK2[1] = col;
            tblFeedbackStandardRisk.Columns.Add(col);

            tblFeedbackStandardRisk.PrimaryKey = colPK2;

            //standard feedback activities
            tblFeedbackStandardActivity = new DataTable();

            col = new DataColumn();
            col.ColumnName = "FeedbackStandardNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            colPK2[0] = col;
            tblFeedbackStandardActivity.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "ActivityNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            colPK2[1] = col;
            tblFeedbackStandardActivity.Columns.Add(col);

            tblFeedbackStandardActivity.PrimaryKey = colPK2;

            //standard feedback learn & earn modules
            tblFeedbackStandardLearn = new DataTable();

            col = new DataColumn();
            col.ColumnName = "FeedbackStandardNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            colPK2[0] = col;
            tblFeedbackStandardLearn.Columns.Add(col);

            col = new DataColumn();
            col.ColumnName = "LearnNum";
            col.DataType = System.Type.GetType("System.Int32");
            col.AllowDBNull = false;
            col.Unique = false;
            colPK2[1] = col;
            tblFeedbackStandardLearn.Columns.Add(col);

            tblFeedbackStandardLearn.PrimaryKey = colPK2;
        }

        protected void CreateFeedbackStandard() {
            SqlDataAdapter daFeedbackStandard;
            SqlDataAdapter daFeedbackStandardEmail;
            SqlDataAdapter daFeedbackStandardGoal;
            SqlDataAdapter daFeedbackStandardRisk;
            SqlDataAdapter daFeedbackStandardActivity;
            SqlDataAdapter daFeedbackStandardLearn;
            SqlDataAdapter daFeedbackStandardCondition;
            DataTable tblFeedbackStandard;
            DataTable tblFeedbackStandardEmail;
            DataTable tblFeedbackStandardGoal;
            DataTable tblFeedbackStandardRisk;
            DataTable tblFeedbackStandardActivity;
            DataTable tblFeedbackStandardLearn;
            DataTable tblFeedbackStandardCondition;
            int intFeedbackStandardNum;
            int intFeedbackSectionNum;
            int intSortOrder;
            bool bolAllowFeedback;

            strSQL = @" select      st.feedback_standard_num,
                                    st.main_feedback,
                                    st.main_feedback_french,
                                    st.summary_feedback,
                                    st.summary_feedback_french,
                                    st.description,
                                    st.nutrition,
                                    st.supplements,
                                    st.other_considerations,
                                    st.age_min,
                                    st.age_max,
                                    st.gender,
                                    st.create_date,
                                    ss.feedback_section_num,
                                    ss.summary_section,
                                    ss.sort_order,
                                    ss.create_date
                        from        hra_feedback_standard st
                        inner join  hra_feedback_standard_section ss on ss.feedback_standard_num = st.feedback_standard_num";
            daFeedbackStandard = new SqlDataAdapter(strSQL, cn);
            tblFeedbackStandard = new DataTable();
            daFeedbackStandard.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackStandard.Fill(tblFeedbackStandard);

            strSQL = @" select  feedback_standard_num,
                                email_campaign_num
                        from    hra_feedback_standard_email";
            daFeedbackStandardEmail = new SqlDataAdapter(strSQL, cn);
            tblFeedbackStandardEmail = new DataTable();
            daFeedbackStandardEmail.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackStandardEmail.Fill(tblFeedbackStandardEmail);

            strSQL = @" select  feedback_standard_num,
                                goal_num
                        from    hra_feedback_standard_goal";
            daFeedbackStandardGoal = new SqlDataAdapter(strSQL, cn);
            tblFeedbackStandardGoal = new DataTable();
            daFeedbackStandardGoal.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackStandardGoal.Fill(tblFeedbackStandardGoal);

            strSQL = @" select  feedback_standard_num,
                                risk_num
                        from    hra_feedback_standard_risk";
            daFeedbackStandardRisk = new SqlDataAdapter(strSQL, cn);
            tblFeedbackStandardRisk = new DataTable();
            daFeedbackStandardRisk.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackStandardRisk.Fill(tblFeedbackStandardRisk);

            strSQL = @" select  feedback_standard_num,
                                activity_num
                        from    hra_feedback_standard_activity";
            daFeedbackStandardActivity = new SqlDataAdapter(strSQL, cn);
            tblFeedbackStandardActivity = new DataTable();
            daFeedbackStandardActivity.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackStandardActivity.Fill(tblFeedbackStandardActivity);

            strSQL = @" select  feedback_standard_num,
                                learn_num
                        from    hra_feedback_standard_learn";
            daFeedbackStandardLearn = new SqlDataAdapter(strSQL, cn);
            tblFeedbackStandardLearn = new DataTable();
            daFeedbackStandardLearn.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackStandardLearn.Fill(tblFeedbackStandardLearn);

            strSQL = @" select  feedback_standard_num, 
                                condition_num
                        from    hra_feedback_standard_condition";
            daFeedbackStandardCondition = new SqlDataAdapter(strSQL, cn);
            tblFeedbackStandardCondition = new DataTable();
            daFeedbackStandardCondition.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackStandardCondition.Fill(tblFeedbackStandardCondition);

            foreach (DataRow rowFeedbackStandard in tblFeedbackStandard.DefaultView.ToTable().Rows) {
                intFeedbackStandardNum = (int)rowFeedbackStandard["feedback_standard_num"];
                intFeedbackSectionNum = (int)rowFeedbackStandard["feedback_section_num"];
                intSortOrder = (int)rowFeedbackStandard["sort_order"];
                bolAllowFeedback = false;

                if ((int)rowFeedbackStandard["age_min"] == 0 && (int)rowFeedbackStandard["age_max"] == 0) {
                    bolAllowFeedback = true;
                }
                else {
                    if ((int)rowFeedbackStandard["age_min"] <= CurrentUser.Age && (int)rowFeedbackStandard["age_max"] >= CurrentUser.Age) {
                        bolAllowFeedback = true;
                    }
                }

                if (bolAllowFeedback == true) {
                    rowFeedback = tblFeedback.NewRow();
                    rowFeedback["FeedbackSectionNum"] = intFeedbackSectionNum;
                    rowFeedback["FeedbackClusterGroupNum"] = 0;
                    rowFeedback["SortOrder"] = intSortOrder;
                    rowFeedback["QuestionNum"] = 0;
                    rowFeedback["AnswerNum"] = 0;
                    rowFeedback["MainFeedback"] = AddNewLine(2) + rowFeedbackStandard["main_feedback"];
                    rowFeedback["SummaryFeedback"] = AddNewLine(2) + rowFeedbackStandard["summary_feedback"];
                    rowFeedback["Description"] = AddNewLine(2) + rowFeedbackStandard["description"];
                    rowFeedback["Nutrition"] = AddNewLine(2) + rowFeedbackStandard["nutrition"];
                    rowFeedback["Supplements"] = AddNewLine(2) + rowFeedbackStandard["supplements"];
                    rowFeedback["OtherConsiderations"] = AddNewLine(2) + rowFeedbackStandard["other_considerations"];
                    tblFeedback.Rows.Add(rowFeedback);

                    //add condition(s) applicable for feedback
                    tblFeedbackStandardCondition.DefaultView.RowFilter = "feedback_standard_num = " + intFeedbackStandardNum.ToString();

                    foreach (DataRow rowFeedbackStandardCondition in tblFeedbackStandardCondition.DefaultView.ToTable().Rows) {
                        rowConditionForFeedback = tblFeedbackCondition.NewRow();
                        rowConditionForFeedback["FeedbackNum"] = rowFeedback["FeedbackNum"];
                        rowConditionForFeedback["ConditionNum"] = rowFeedbackStandardCondition["condition_num"];
                        tblConditionForFeedback.Rows.Add(rowConditionForFeedback);
                    }

                    tblFeedbackStandardEmail.DefaultView.RowFilter = "feedback_standard_num = " + intFeedbackStandardNum.ToString();

                    foreach (DataRow rowFeedbackStandardEmail in tblFeedbackStandardEmail.DefaultView.ToTable().Rows) {
                        AddEmailCampaign(intReportNum, (int)rowFeedbackStandardEmail["email_campaign_num"]);
                    }
                }
            }
        }

        protected void CreateFeedbackCustom() {
            SqlDataAdapter daFeedbackCustom;
            SqlDataAdapter daFeedbackCustomSection;
            SqlDataAdapter daFeedbackCustomEmail;
            SqlDataAdapter daFeedbackCustomCondition;
            DataTable tblFeedbackCustom = new DataTable("hra_feedback_custom");
            DataTable tblFeedbackCustomSection = new DataTable("hra_feedback_custom_section");
            DataTable tblFeedbackCustomEmail = new DataTable("hra_feedback_custom_email");
            DataTable tblFeedbackCustomCondition = new DataTable("hra_feedback_custom_condition");
            int intFeedbackCustomNum;
            int intQuestionNum;
            int intAnswerNum;
            int intFeedbackSectionNum;
            int intSortOrder;
            bool bolAllowFeedback;

            strSQL = @" select  feedback_custom_num,
                                question_num,
                                answer_num,
                                main_feedback,
                                main_feedback_french,
                                summary_feedback,
                                summary_feedback_french,
                                age_min,
                                age_max,
                                age_restriction_included,
                                description,
                                nutrition,
                                supplements,
                                other_considerations
                        from    hra_feedback_custom";
            daFeedbackCustom = new SqlDataAdapter(strSQL, cn);
            daFeedbackCustom.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCustom.Fill(tblFeedbackCustom);

            strSQL = @" select  feedback_custom_num,
                                feedback_section_num,
                                summary_section,
                                sort_order
                        from    hra_feedback_custom_section";
            daFeedbackCustomSection = new SqlDataAdapter(strSQL, cn);
            daFeedbackCustomSection.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCustomSection.Fill(tblFeedbackCustomSection);

            strSQL = @" select  feedback_custom_num,
                                email_campaign_num
                        from    hra_feedback_custom_email";
            daFeedbackCustomEmail = new SqlDataAdapter(strSQL, cn);
            daFeedbackCustomEmail.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCustomEmail.Fill(tblFeedbackCustomEmail);

            strSQL = @" select  feedback_custom_num, 
                                condition_num 
                        from    hra_feedback_custom_condition";
            daFeedbackCustomCondition = new SqlDataAdapter(strSQL, cn);
            daFeedbackCustomCondition.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCustomCondition.Fill(tblFeedbackCustomCondition);

            foreach (DataRow rowRiskReportDetail in tblRiskReportDetail.Rows) {
                intQuestionNum = (int)rowRiskReportDetail["question_num"];
                intAnswerNum = (int)rowRiskReportDetail["answer_num"];

                rowQuestion = tblQuestion.Rows.Find(intQuestionNum);

                if (rowQuestion != null) {
                    if ((int)rowQuestion["age_min"] <= CurrentUser.Age && (int)rowQuestion["age_max"] >= CurrentUser.Age) {
                        tblFeedbackCustom.DefaultView.RowFilter = "question_num = " + intQuestionNum.ToString() + " and answer_num = " + intAnswerNum.ToString();

                        foreach (DataRow rowFeedbackCustom in tblFeedbackCustom.DefaultView.ToTable().Rows) {
                            intFeedbackCustomNum = (int)rowFeedbackCustom["feedback_custom_num"];
                            tblFeedbackCustomSection.DefaultView.RowFilter = "feedback_custom_num = " + intFeedbackCustomNum.ToString();

                            foreach (DataRow rowFeedbackCustomSection in tblFeedbackCustomSection.DefaultView.ToTable().Rows) {
                                intFeedbackSectionNum = (int)rowFeedbackCustomSection["feedback_section_num"];
                                intSortOrder = (int)rowFeedbackCustomSection["sort_order"];
                                bolAllowFeedback = false;

                                if ((bool)rowFeedbackCustom["age_restriction_included"] == true) {
                                    if ((int)rowFeedbackCustom["age_min"] >= CurrentUser.Age && (int)rowFeedbackCustom["age_max"] >= CurrentUser.Age) {
                                        bolAllowFeedback = true;
                                    }
                                }
                                else {
                                    bolAllowFeedback = true;
                                }

                                if (bolAllowFeedback == true) {
                                    rowFeedback = tblFeedback.NewRow();
                                    rowFeedback["FeedbackSectionNum"] = intFeedbackSectionNum;
                                    rowFeedback["FeedbackClusterGroupNum"] = 0;
                                    rowFeedback["SortOrder"] = intSortOrder;
                                    rowFeedback["QuestionNum"] = intQuestionNum;
                                    rowFeedback["AnswerNum"] = intAnswerNum;
                                    rowFeedback["MainFeedback"] = AddNewLine(2) + rowFeedbackCustom["main_feedback"];
                                    rowFeedback["SummaryFeedback"] = AddNewLine(2) + rowFeedbackCustom["summary_feedback"];
                                    rowFeedback["Description"] = AddNewLine(2) + rowFeedbackCustom["description"];
                                    rowFeedback["Nutrition"] = AddNewLine(2) + rowFeedbackCustom["nutrition"];
                                    rowFeedback["Supplements"] = AddNewLine(2) + rowFeedbackCustom["supplements"];
                                    rowFeedback["OtherConsiderations"] = AddNewLine(2) + rowFeedbackCustom["other_considerations"];
                                    tblFeedback.Rows.Add(rowFeedback);

                                    //add applicable condition(s)
                                    tblFeedbackCustomCondition.DefaultView.RowFilter = "feedback_custom_num = " + intFeedbackCustomNum.ToString();

                                    foreach (DataRow rowFeedbackCustomCondition in tblFeedbackCustomCondition.DefaultView.ToTable().Rows) {
                                        rowConditionForFeedback = tblConditionForFeedback.NewRow();
                                        rowConditionForFeedback["FeedbackNum"] = rowFeedback["FeedbackNum"];
                                        rowConditionForFeedback["ConditionNum"] = rowFeedbackCustomCondition["condition_num"];
                                        tblConditionForFeedback.Rows.Add(rowConditionForFeedback);

                                        //add condition for risk report
                                        //AddCondition(intReportNum, (int)rowFeedbackCustomCondition["condition_num"]);
                                    }

                                    tblFeedbackCustomEmail.DefaultView.RowFilter = "feedback_custom_num = " + intFeedbackCustomNum.ToString();

                                    foreach (DataRow rowFeedbackCustomEmail in tblFeedbackCustomEmail.DefaultView.ToTable().Rows) {
                                        AddEmailCampaign(intReportNum, (int)rowFeedbackCustomEmail["email_campaign_num"]);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        protected void CreateFeedbackCluster() {
            SqlDataAdapter daFeedbackCluster;
            SqlDataAdapter daFeedbackClusterMatrix;
            SqlDataAdapter daFeedbackClusterSection;
            SqlDataAdapter daFeedbackClusterEmail;
            SqlDataAdapter daFeedbackClusterCondition;
            DataTable tblFeedbackCluster = new DataTable("hra_feedback_cluster");
            DataTable tblFeedbackClusterMatrix = new DataTable("hra_feedback_cluster_matrix");
            DataTable tblFeedbackClusterSection = new DataTable("hra_feedback_cluster_section");
            DataTable tblFeedbackClusterEmail = new DataTable("hra_feedback_cluster_email");
            DataTable tblFeedbackClusterCondition = new DataTable("hra_feedback_cluster_condition");

            object[] objPK2 = new object[2];
            int intQuestionNum;
            int intAnswerNum;
            int intFeedbackSectionNum;
            int intSortOrder;
            int intFeedbackClusterNum;
            int intFeedbackClusterGroupNum;
            int intAgeMin;
            int intAgeMax;
            bool bolReceiveFeedback;
            bool bolClusterGroupFound;

            strSQL = @" select  feedback_cluster_num,
                                feedback_cluster_group_num,
                                feedback_cluster_batch_num,
                                main_feedback,
                                main_feedback_french,
                                summary_feedback,
                                summary_feedback_french,
                                description,
                                nutrition,
                                supplements,
                                other_considerations,
                                mhrs,
                                age_min,
                                age_max,
                                age_restriction_included,
                                match_all,
                                match_criteria,
                                match_count
                        from    hra_feedback_cluster
                        where   feedback_cluster_batch_num = 0";
            daFeedbackCluster = new SqlDataAdapter(strSQL, cn);
            daFeedbackCluster.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCluster.Fill(tblFeedbackCluster);

            strSQL = @" select  feedback_cluster_num,
                                question_num,
                                answer_num
                        from    hra_feedback_cluster_matrix";
            daFeedbackClusterMatrix = new SqlDataAdapter(strSQL, cn);
            daFeedbackClusterMatrix.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackClusterMatrix.Fill(tblFeedbackClusterMatrix);

            strSQL = @" select  feedback_cluster_num,
                                feedback_section_num,
                                summary_section,
                                sort_order
                        from    hra_feedback_cluster_section";
            daFeedbackClusterSection = new SqlDataAdapter(strSQL, cn);
            daFeedbackClusterSection.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackClusterSection.Fill(tblFeedbackClusterSection);

            strSQL = @" select  feedback_cluster_num,
                                email_campaign_num
                        from    hra_feedback_cluster_email";
            daFeedbackClusterEmail = new SqlDataAdapter(strSQL, cn);
            daFeedbackClusterEmail.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackClusterEmail.Fill(tblFeedbackClusterEmail);

            strSQL = @" select  feedback_cluster_num, 
                                condition_num 
                        from    hra_feedback_cluster_condition";
            daFeedbackClusterCondition = new SqlDataAdapter(strSQL, cn);
            daFeedbackClusterCondition.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackClusterCondition.Fill(tblFeedbackClusterCondition);

            foreach (DataRow rowFeedbackCluster in tblFeedbackCluster.Rows) {
                bolReceiveFeedback = true;
                bolClusterGroupFound = false;
                intFeedbackClusterNum = (int)rowFeedbackCluster["feedback_cluster_num"];
                intFeedbackClusterGroupNum = (int)rowFeedbackCluster["feedback_cluster_group_num"];
                intAgeMin = (int)rowFeedbackCluster["age_min"];
                intAgeMax = (int)rowFeedbackCluster["age_max"];

                if ((bool)rowFeedbackCluster["age_restriction_included"] == true) {
                    if (CurrentUser.Age < intAgeMin || CurrentUser.Age > intAgeMax) {
                        bolReceiveFeedback = false;
                    }
                }

                if (bolReceiveFeedback == true) {
                    if (intFeedbackClusterGroupNum != 0) {
                        DataRow[] rowCheck = tblFeedback.Select("FeedbackClusterGroupNum = " + intFeedbackClusterGroupNum.ToString());

                        if (rowCheck.Length != 0) {
                            bolClusterGroupFound = true;
                        }
                    }

                    if (intFeedbackClusterGroupNum == 0 || bolClusterGroupFound == false) {
                        tblFeedbackClusterMatrix.DefaultView.RowFilter = "feedback_cluster_num = " + intFeedbackClusterNum.ToString();

                        foreach (DataRow rowFeedbackClusterMatrix in tblFeedbackClusterMatrix.DefaultView.ToTable().Rows) {
                            intQuestionNum = (int)rowFeedbackClusterMatrix["question_num"];
                            intAnswerNum = (int)rowFeedbackClusterMatrix["answer_num"];
                            objPK2[0] = intReportNum;
                            objPK2[1] = intQuestionNum;

                            rowRiskReportDetail = tblRiskReportDetail.Rows.Find(objPK2);

                            if ((bool)rowFeedbackCluster["match_all"] == true) {
                                if (rowRiskReportDetail == null) {
                                    //verify if the question is suppressed
                                    if (tblQuestionGender.Rows.Find(intQuestionNum) == null) {
                                        bolReceiveFeedback = false;
                                        break;
                                    }
                                }
                                else {
                                    if ((int)rowRiskReportDetail["answer_num"] != intAnswerNum) {
                                        bolReceiveFeedback = false;
                                        break;
                                    }
                                }
                            }
                            else {
                                if (rowRiskReportDetail != null) {
                                    if ((int)rowRiskReportDetail["answer_num"] == intAnswerNum) {
                                        bolReceiveFeedback = true;
                                    }
                                    else {
                                        bolReceiveFeedback = false;
                                    }
                                }
                            }
                        }

                        if (bolReceiveFeedback == true) {
                            tblFeedbackClusterSection.DefaultView.RowFilter = "feedback_cluster_num =" + intFeedbackClusterNum.ToString();

                            foreach (DataRow rowFeedbackClusterSection in tblFeedbackClusterSection.DefaultView.ToTable().Rows) {
                                intFeedbackSectionNum = (int)rowFeedbackClusterSection["feedback_section_num"];
                                intSortOrder = (int)rowFeedbackClusterSection["sort_order"];

                                rowFeedback = tblFeedback.NewRow();
                                rowFeedback["FeedbackSectionNum"] = intFeedbackSectionNum;
                                rowFeedback["FeedbackClusterGroupNum"] = intFeedbackClusterGroupNum;
                                rowFeedback["SortOrder"] = intSortOrder;
                                rowFeedback["QuestionNum"] = 0;
                                rowFeedback["AnswerNum"] = 0;
                                rowFeedback["MainFeedback"] = AddNewLine(2) + rowFeedbackCluster["main_feedback"];
                                rowFeedback["SummaryFeedback"] = AddNewLine(2) + rowFeedbackCluster["summary_feedback"];
                                rowFeedback["Description"] = AddNewLine(2) + rowFeedbackCluster["description"];
                                rowFeedback["Nutrition"] = AddNewLine(2) + rowFeedbackCluster["nutrition"];
                                rowFeedback["Supplements"] = AddNewLine(2) + rowFeedbackCluster["supplements"];
                                rowFeedback["OtherConsiderations"] = AddNewLine(2) + rowFeedbackCluster["other_considerations"];
                                tblFeedback.Rows.Add(rowFeedback);

                                //add applicable condition(s)
                                tblFeedbackClusterCondition.DefaultView.RowFilter = "feedback_cluster_num =" + intFeedbackClusterNum.ToString();

                                foreach (DataRow rowFeedbackClusterCondition in tblFeedbackClusterCondition.DefaultView.ToTable().Rows) {
                                    objPK2[0] = rowFeedback["FeedbackNum"];
                                    objPK2[1] = rowFeedbackClusterCondition["condition_num"];

                                    rowConditionForFeedback = tblConditionForFeedback.Rows.Find(objPK2);

                                    if (rowConditionForFeedback == null) {
                                        rowConditionForFeedback = tblConditionForFeedback.NewRow();
                                        rowConditionForFeedback["FeedbackNum"] = rowFeedback["FeedbackNum"];
                                        rowConditionForFeedback["ConditionNum"] = rowFeedbackClusterCondition["condition_num"];
                                        tblConditionForFeedback.Rows.Add(rowConditionForFeedback);
                                    }
                                }
                            }

                            tblFeedbackClusterEmail.DefaultView.RowFilter = "feedback_cluster_num = " + intFeedbackClusterNum.ToString();

                            foreach (DataRow rowFeedbackClusterEmail in tblFeedbackClusterEmail.DefaultView.ToTable().Rows) {
                                AddEmailCampaign(intReportNum, (int)rowFeedbackClusterEmail["email_campaign_num"]);
                            }
                        }
                    }
                }
            }
        }

        protected void CreateFeedbackClusterBatches() {
            SqlDataAdapter daFeedbackCluster;
            SqlDataAdapter daFeedbackClusterMatrix;
            SqlDataAdapter daFeedbackClusterSection;
            SqlDataAdapter daFeedbackClusterEmail;
            SqlDataAdapter daFeedbackClusterCondition;
            DataTable tblFeedbackCluster = new DataTable("hra_feedback_cluster");
            DataTable tblFeedbackClusterMatrix = new DataTable("hra_feedback_cluster_matrix");
            DataTable tblFeedbackClusterSection = new DataTable("hra_feedback_cluster_section");
            DataTable tblFeedbackClusterEmail = new DataTable("hra_feedback_cluster_email");
            DataTable tblFeedbackClusterCondition = new DataTable("hra_feedback_cluster_condition");

            object[] objPK2 = new object[2];
            int intQuestionNum;
            int intAnswerNum;
            int intFeedbackSectionNum;
            int intSortOrder;
            int intFeedbackClusterNum;
            int intFeedbackClusterGroupNum;
            int intFeedbackClusterBatchNum;
            int intPreviousClusterNum = 0;
            int intPreviousClusterBatchNum = 0;
            bool bolReceiveFeedback = true;
            bool bolClusterGroupFound;
            int intAgeMin;
            int intAgeMax;
            List<int> lstClusterNumbers = new List<int>();
            List<int> lstBatchClusterNumbers = new List<int>();

            strSQL = @" select   feedback_cluster_num,
                                 feedback_cluster_group_num,
                                 feedback_cluster_batch_num,
                                 main_feedback,
                                 main_feedback_french,
                                 summary_feedback,
                                 summary_feedback_french,
                                 description,
                                 nutrition,
                                 supplements,
                                 other_considerations,
                                 mhrs,
                                 age_min,
                                 age_max,
                                 age_restriction_included,
                                 match_all,
                                 match_criteria,
                                 match_count
                        from     hra_feedback_cluster
                        where    feedback_cluster_batch_num > 0
                        order by feedback_cluster_batch_num,
                                 feedback_cluster_group_num ";
            daFeedbackCluster = new SqlDataAdapter(strSQL, cn);
            daFeedbackCluster.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCluster.Fill(tblFeedbackCluster);

            strSQL = @" select  feedback_cluster_num,
                                question_num,
                                answer_num
                        from    hra_feedback_cluster_matrix";
            daFeedbackClusterMatrix = new SqlDataAdapter(strSQL, cn);
            daFeedbackClusterMatrix.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackClusterMatrix.Fill(tblFeedbackClusterMatrix);

            strSQL = @" select  feedback_cluster_num,
                                feedback_section_num,
                                summary_section,
                                sort_order
                        from    hra_feedback_cluster_section";
            daFeedbackClusterSection = new SqlDataAdapter(strSQL, cn);
            daFeedbackClusterSection.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackClusterSection.Fill(tblFeedbackClusterSection);

            strSQL = @" select  feedback_cluster_num,
                                email_campaign_num
                        from    hra_feedback_cluster_email";
            daFeedbackClusterEmail = new SqlDataAdapter(strSQL, cn);
            daFeedbackClusterEmail.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackClusterEmail.Fill(tblFeedbackClusterEmail);

            strSQL = @" select  feedback_cluster_num, 
                                condition_num 
                        from    hra_feedback_cluster_condition";
            daFeedbackClusterCondition = new SqlDataAdapter(strSQL, cn);
            daFeedbackClusterCondition.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackClusterCondition.Fill(tblFeedbackClusterCondition);

            foreach (DataRow rowFeedbackCluster in tblFeedbackCluster.Rows) {
                intFeedbackClusterBatchNum = (int)rowFeedbackCluster["feedback_cluster_batch_num"];
                intFeedbackClusterNum = (int)rowFeedbackCluster["feedback_cluster_num"];
                intFeedbackClusterGroupNum = (int)rowFeedbackCluster["feedback_cluster_group_num"];
                intAgeMin = (int)rowFeedbackCluster["age_min"];
                intAgeMax = (int)rowFeedbackCluster["age_max"];

                if (intFeedbackClusterBatchNum == intPreviousClusterBatchNum) {
                    if (bolReceiveFeedback == false) {
                        //jump to next record, batch already failed test
                        continue;
                    }
                }
                else {
                    if (intPreviousClusterBatchNum == 0) {
                        bolReceiveFeedback = true;
                    }
                    else {
                        if (bolReceiveFeedback == true) {
                            //add all the clusters for the valid batch
                            for (int i = 0; i < lstBatchClusterNumbers.Count; i++) {
                                lstClusterNumbers.Add(lstBatchClusterNumbers[i]);
                            }
                        }

                        bolReceiveFeedback = false;
                        lstBatchClusterNumbers.Clear();
                    }
                }

                bolClusterGroupFound = false;

                if (intFeedbackClusterGroupNum != 0) {
                    DataRow[] rowCheck = tblFeedback.Select("FeedbackClusterGroupNum = " + intFeedbackClusterGroupNum.ToString());

                    if (rowCheck.Length != 0) {
                        bolClusterGroupFound = true;
                    }
                }

                if (intFeedbackClusterGroupNum == 0 || bolClusterGroupFound == false) {
                    tblFeedbackClusterMatrix.DefaultView.RowFilter = "feedback_cluster_num = " + intFeedbackClusterNum.ToString();

                    bolReceiveFeedback = (bool)rowFeedbackCluster["match_all"];

                    foreach (DataRow rowFeedbackClusterMatrix in tblFeedbackClusterMatrix.DefaultView.ToTable().Rows) {
                        intQuestionNum = (int)rowFeedbackClusterMatrix["question_num"];
                        intAnswerNum = (int)rowFeedbackClusterMatrix["answer_num"];
                        objPK2[0] = intReportNum;
                        objPK2[1] = intQuestionNum;

                        rowRiskReportDetail = tblRiskReportDetail.Rows.Find(objPK2);

                        if ((bool)rowFeedbackCluster["match_all"] == true) {
                            if (rowRiskReportDetail == null) {
                                //verify if the question is suppressed
                                if (tblQuestionGender.Rows.Find(intQuestionNum) == null) {
                                    bolReceiveFeedback = false;
                                    break;
                                }
                            }
                            else {
                                if ((int)rowRiskReportDetail["answer_num"] != intAnswerNum) {
                                    bolReceiveFeedback = false;
                                    break;
                                }
                            }
                        }
                        else {
                            if (rowRiskReportDetail == null) {
                                //verify if the question is suppressed
                                if (tblQuestionGender.Rows.Find(intQuestionNum) == null) {
                                    bolReceiveFeedback = false;
                                    break;
                                }
                            }
                            else {
                                if ((int)rowRiskReportDetail["answer_num"] == intAnswerNum) {
                                    bolReceiveFeedback = true;
                                    break;
                                }
                            }
                        }
                    }

                    if ((bool)rowFeedbackCluster["age_restriction_included"] == true) {
                        if (intAgeMin > CurrentUser.Age || intAgeMax < CurrentUser.Age) {
                            bolReceiveFeedback = false;
                        }
                    }

                    if (bolReceiveFeedback == true) {
                        lstBatchClusterNumbers.Add(intFeedbackClusterNum);
                    }
                }

                intPreviousClusterNum = intFeedbackClusterNum;
                intPreviousClusterBatchNum = intFeedbackClusterBatchNum;
            }

            if (lstClusterNumbers.Count > 0) {
                DataRow rowFeedbackCluster;

                for (int i = 0; i < lstClusterNumbers.Count; i++) {
                    intFeedbackClusterNum = lstClusterNumbers[i];
                    rowFeedbackCluster = tblFeedbackCluster.Rows.Find(intFeedbackClusterNum);

                    if (rowFeedbackCluster != null) {
                        tblFeedbackClusterSection.DefaultView.RowFilter = "feedback_cluster_num =" + intFeedbackClusterNum.ToString();

                        foreach (DataRow rowFeedbackClusterSection in tblFeedbackClusterSection.DefaultView.ToTable().Rows) {
                            intFeedbackSectionNum = (int)rowFeedbackClusterSection["feedback_section_num"];
                            intSortOrder = (int)rowFeedbackClusterSection["sort_order"];
                            intFeedbackClusterGroupNum = (int)rowFeedbackCluster["feedback_cluster_group_num"];

                            rowFeedback = tblFeedback.NewRow();
                            rowFeedback["FeedbackSectionNum"] = intFeedbackSectionNum;
                            rowFeedback["FeedbackClusterGroupNum"] = intFeedbackClusterGroupNum;
                            rowFeedback["SortOrder"] = intSortOrder;
                            rowFeedback["QuestionNum"] = 0;
                            rowFeedback["AnswerNum"] = 0;
                            rowFeedback["MainFeedback"] = AddNewLine(2) + rowFeedbackCluster["main_feedback"];
                            rowFeedback["SummaryFeedback"] = AddNewLine(2) + rowFeedbackCluster["summary_feedback"];
                            rowFeedback["Description"] = AddNewLine(2) + rowFeedbackCluster["description"];
                            rowFeedback["Nutrition"] = AddNewLine(2) + rowFeedbackCluster["nutrition"];
                            rowFeedback["Supplements"] = AddNewLine(2) + rowFeedbackCluster["supplements"];
                            rowFeedback["OtherConsiderations"] = AddNewLine(2) + rowFeedbackCluster["other_considerations"];
                            tblFeedback.Rows.Add(rowFeedback);

                            //add applicable condition(s)
                            tblFeedbackClusterCondition.DefaultView.RowFilter = "feedback_cluster_num =" + intFeedbackClusterNum.ToString();

                            foreach (DataRow rowFeedbackClusterCondition in tblFeedbackClusterCondition.DefaultView.ToTable().Rows) {
                                objPK2[0] = rowFeedback["FeedbackNum"];
                                objPK2[1] = rowFeedbackClusterCondition["condition_num"];

                                rowConditionForFeedback = tblConditionForFeedback.Rows.Find(objPK2);

                                if (rowConditionForFeedback == null) {
                                    rowConditionForFeedback = tblConditionForFeedback.NewRow();
                                    rowConditionForFeedback["FeedbackNum"] = rowFeedback["FeedbackNum"];
                                    rowConditionForFeedback["ConditionNum"] = rowFeedbackClusterCondition["condition_num"];
                                    tblConditionForFeedback.Rows.Add(rowConditionForFeedback);
                                }
                            }
                        }

                        tblFeedbackClusterEmail.DefaultView.RowFilter = "feedback_cluster_num = " + intFeedbackClusterNum.ToString();

                        foreach (DataRow rowFeedbackClusterEmail in tblFeedbackClusterEmail.DefaultView.ToTable().Rows) {
                            AddEmailCampaign(intReportNum, (int)rowFeedbackClusterEmail["email_campaign_num"]);
                        }
                    }
                }
            }
        }

        protected void CreateFeedbackCriteria(FeedbackCriteriaType CriteriaType, decimal CriteriaValue) {
            SqlDataAdapter daFeedbackCriteria;
            SqlDataAdapter daFeedbackCriteriaSection;
            SqlDataAdapter daFeedbackCriteriaEmail;
            SqlDataAdapter daFeedbackCriteriaCondition;
            DataTable tblFeedbackCriteria = new DataTable("hra_feedback_criteria");
            DataTable tblFeedbackCriteriaSection = new DataTable("hra_feedback_criteria_section");
            DataTable tblFeedbackCriteriaEmail = new DataTable("hra_feedback_criteria_email");
            DataTable tblFeedbackCriteriaCondition = new DataTable("hra_feedback_criteria_condition");

            object[] objPK2 = new object[2];
            int intFeedbackCriteriaNum;
            int intFeedbackSectionNum;
            int intSortOrder;

            //suppress medication adherence feedback, if medication adherence score = 0
            if (CriteriaType == FeedbackCriteriaType.Medication) {
                if (bolReceiveMedicationAdherence == false) {
                    return;
                }
            }

            strSQL = @" select  feedback_criteria_num,
                                feedback_criteria_type_num,
                                criteria_min,
                                criteria_max,
                                gender,
                                main_feedback,
                                main_feedback_french,
                                summary_feedback,
                                summary_feedback_french,
                                description,
                                nutrition,
                                supplements,
                                other_considerations,
                                mhrs
                        from    hra_feedback_criteria 
                        where   feedback_criteria_type_num = " + Convert.ChangeType(CriteriaType, CriteriaType.GetTypeCode());
            daFeedbackCriteria = new SqlDataAdapter(strSQL, cn);
            daFeedbackCriteria.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCriteria.Fill(tblFeedbackCriteria);

            strSQL = @" select  feedback_criteria_num,
                                feedback_section_num,
                                summary_section,
                                sort_order
                        from    hra_feedback_criteria_section";
            daFeedbackCriteriaSection = new SqlDataAdapter(strSQL, cn);
            daFeedbackCriteriaSection.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCriteriaSection.Fill(tblFeedbackCriteriaSection);

            strSQL = @" select  feedback_criteria_num,
                                email_campaign_num
                        from    hra_feedback_criteria_email";
            daFeedbackCriteriaEmail = new SqlDataAdapter(strSQL, cn);
            daFeedbackCriteriaEmail.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCriteriaEmail.Fill(tblFeedbackCriteriaEmail);

            strSQL = @" select  feedback_criteria_num, 
                                condition_num 
                        from    hra_feedback_criteria_condition";
            daFeedbackCriteriaCondition = new SqlDataAdapter(strSQL, cn);
            daFeedbackCriteriaCondition.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daFeedbackCriteriaCondition.Fill(tblFeedbackCriteriaCondition);

            foreach (DataRow rowFeedbackCriteria in tblFeedbackCriteria.Rows) {
                intFeedbackCriteriaNum = (int)rowFeedbackCriteria["feedback_criteria_num"];

                if (rowFeedbackCriteria["gender"].ToString() == CurrentUser.Gender || rowFeedbackCriteria["gender"].ToString() == "U") {
                    if ((decimal)rowFeedbackCriteria["criteria_min"] <= CriteriaValue && CriteriaValue <= (decimal)rowFeedbackCriteria["criteria_max"]) {
                        //criteria is met, give user feedback
                        tblFeedbackCriteriaSection.DefaultView.RowFilter = "feedback_criteria_num = " + rowFeedbackCriteria["feedback_criteria_num"].ToString();

                        foreach (DataRow rowFeedbackCriteriaSection in tblFeedbackCriteriaSection.DefaultView.ToTable().Rows) {
                            intFeedbackSectionNum = (int)rowFeedbackCriteriaSection["feedback_section_num"];
                            intSortOrder = (int)rowFeedbackCriteriaSection["sort_order"];

                            rowFeedback = tblFeedback.NewRow();
                            rowFeedback["FeedbackSectionNum"] = intFeedbackSectionNum;
                            rowFeedback["FeedbackClusterGroupNum"] = 0;
                            rowFeedback["SortOrder"] = intSortOrder;
                            rowFeedback["QuestionNum"] = 0;
                            rowFeedback["AnswerNum"] = 0;

                            if ((bool)rowFeedbackCriteriaSection["summary_section"] == true) {
                                rowFeedback["MainFeedback"] = AddNewLine(2) + rowFeedbackCriteria["summary_feedback"];
                                rowFeedback["SummaryFeedback"] = AddNewLine(2) + rowFeedbackCriteria["summary_feedback"];
                            }
                            else {
                                rowFeedback["MainFeedback"] = AddNewLine(2) + rowFeedbackCriteria["main_feedback"];
                                rowFeedback["SummaryFeedback"] = AddNewLine(2) + rowFeedbackCriteria["summary_feedback"];
                            }

                            rowFeedback["Description"] = AddNewLine(2) + rowFeedbackCriteria["description"];
                            rowFeedback["Nutrition"] = AddNewLine(2) + rowFeedbackCriteria["nutrition"];
                            rowFeedback["Supplements"] = AddNewLine(2) + rowFeedbackCriteria["supplements"];
                            rowFeedback["OtherConsiderations"] = AddNewLine(2) + rowFeedbackCriteria["other_considerations"];
                            tblFeedback.Rows.Add(rowFeedback);

                            //add applicable condition(s)
                            tblFeedbackCriteriaCondition.DefaultView.RowFilter = "feedback_criteria_num =" + intFeedbackCriteriaNum.ToString();

                            foreach (DataRow rowFeedbackCriteriaCondition in tblFeedbackCriteriaCondition.DefaultView.ToTable().Rows) {
                                //add condition for feedback for risk report
                                rowConditionForFeedback = tblConditionForFeedback.NewRow();
                                rowConditionForFeedback["FeedbackNum"] = rowFeedback["FeedbackNum"];
                                rowConditionForFeedback["ConditionNum"] = rowFeedbackCriteriaCondition["condition_num"];
                                tblConditionForFeedback.Rows.Add(rowConditionForFeedback);

                                //add condition for risk report
                                //AddCondition(intReportNum, (int)rowFeedbackCriteriaCondition["condition_num"]);
                            }
                        }

                        tblFeedbackCriteriaEmail.DefaultView.RowFilter = "feedback_criteria_num = " + intFeedbackCriteriaNum.ToString();

                        foreach (DataRow rowFeedbackCriteriaEmail in tblFeedbackCriteriaEmail.DefaultView.ToTable().Rows) {
                            AddEmailCampaign(intReportNum, (int)rowFeedbackCriteriaEmail["email_campaign_num"]);
                        }
                    }
                }
            }
        }

        protected string AddNewLine(int NumberOfLines) {
            string str = "";

            for (int i = 0; i < NumberOfLines; i++) {
                str += System.Environment.NewLine;
            }

            return str;
        }

        protected void UpdateBMI(int ReportNum) {
            strSQL = @" select isnull(weight, 0)
                        from hra_risk_report
                        where risk_report_num = " + ReportNum.ToString();

            SqlCommand cmdPK = new SqlCommand(strSQL, cn);
            intWeight = Convert.ToInt32(cmdPK.ExecuteScalar());
            decBMI = CalculateBMI(CurrentUser.Height, intWeight, MeasurementUnit.Imperial);

            strSQL = @" select  risk_report_num,
                                bmi 
                        from    hra_risk_report 
                        where   risk_report_num = " + ReportNum.ToString();
            daRiskReport = new SqlDataAdapter(strSQL, cn);
            cbRiskReport = new SqlCommandBuilder(daRiskReport);
            tblRiskReport = new DataTable();
            tblRiskReport.Clear();
            daRiskReport.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReport.Fill(tblRiskReport);

            if (tblRiskReport.Rows.Count > 0) {
                tblRiskReport.Rows[0]["bmi"] = decBMI;
                daRiskReport.Update(tblRiskReport);
            }

            TrackMetric(MetricTypes.BMI, decBMI);
        }

        protected void TrackMetric(MetricTypes MetricType, decimal MetricValue) {
            rowMetricTracking = tblMetricTracking.NewRow();
            rowMetricTracking["metric_type_num"] = Convert.ChangeType(MetricType, MetricType.GetTypeCode());
            rowMetricTracking["metric_source_num"] = 3;  //HRA
            rowMetricTracking["user_id"] = CurrentUser.ID;
            rowMetricTracking["metric"] = MetricValue;

            switch (MetricType) {
                case MetricTypes.Weight:
                    rowMetricTracking["uom_num"] = 16;
                    break;
                case MetricTypes.Waist:
                    rowMetricTracking["uom_num"] = 11;
                    break;
                case MetricTypes.BMI:
                    rowMetricTracking["uom_num"] = 10;
                    break;
                case MetricTypes.DietaryScore:
                    rowMetricTracking["uom_num"] = 29;
                    break;
                case MetricTypes.MHRScore:
                    rowMetricTracking["uom_num"] = 29;
                    break;
                case MetricTypes.BIOAge:
                    rowMetricTracking["uom_num"] = 20;
                    break;
                default:
                    rowMetricTracking["uom_num"] = null;
                    break;
            }

            rowMetricTracking["create_date"] = DateTime.UtcNow;
            rowMetricTracking["create_user"] = CurrentUser.ID;
            tblMetricTracking.Rows.Add(rowMetricTracking);
            daMetricTracking.Update(tblMetricTracking);
        }


        public enum MeasurementUnit {
            Metric = 1,
            Imperial = 2
        };

        public static decimal CalculateBMI(int Height, int Weight, MeasurementUnit Units) {
            decimal BMI = 0;

            if (Height == 0 || Weight == 0)
                return 0;

            if (Units == MeasurementUnit.Metric) {
                BMI = (decimal)System.Math.Round((Weight / System.Math.Pow(Height, 2)), 2);
            }
            else {
                BMI = (decimal)System.Math.Round((Weight / System.Math.Pow(Height, 2)) * 703, 2);
            }

            return BMI;
        }

        protected void CalculateDietaryScore(int ReportNum) {
            string strSQL;

            strSQL = @" select      isnull(sum(a.dietary),0)
                        from        hra_risk_report_detail rrd
                        inner join  hra_answer a on a.answer_num = rrd.answer_num 
                        and         a.question_num = rrd.question_num
                        where       rrd.risk_report_num = " + ReportNum.ToString();

            SqlCommand cmdPK = new SqlCommand(strSQL, cn);
            decDietaryScore = Convert.ToDecimal(cmdPK.ExecuteScalar());

            strSQL = @" select  risk_report_num,
                                dietary_score 
                        from    hra_risk_report 
                        where   risk_report_num = " + ReportNum.ToString();
            daRiskReport = new SqlDataAdapter(strSQL, cn);
            cbRiskReport = new SqlCommandBuilder(daRiskReport);
            tblRiskReport = new DataTable();
            tblRiskReport.Clear();
            daRiskReport.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReport.Fill(tblRiskReport);

            if (tblRiskReport.Rows.Count > 0) {
                tblRiskReport.Rows[0]["dietary_score"] = decDietaryScore;
                daRiskReport.Update(tblRiskReport);
            }

            TrackMetric(MetricTypes.DietaryScore, decDietaryScore);
        }

        protected void CalculateMHRScore(int ReportNum) {
            //MHR score starts at 100.  MHRS values based on user's answers are deducted from 100.
            string strSQL;
            //decimal decMHRS = MHR_SCORE_START;

            //calculate initial MHR score based on user's answers
            strSQL = @" select isnull(sum(a.mhrs), 0)
                        from hra_risk_report_detail rrd
                        inner join hra_answer a on a.question_num = rrd.question_num and a.answer_num = rrd.answer_num
                        where rrd.risk_report_num = " + ReportNum.ToString();

            SqlCommand cmdPK = new SqlCommand(strSQL, cn);
            decMHRS -= Convert.ToDecimal(cmdPK.ExecuteScalar());

            //update MHRS based on MHRS clusters
            strSQL = @" select      mhrs_cluster_num,
                                    mhrs
                        from        hra_mhrs_cluster
                        order by    mhrs_cluster_num";
            SqlDataAdapter daCluster = new SqlDataAdapter(strSQL, cn);
            DataTable tblCluster = new DataTable();
            daCluster.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daCluster.Fill(tblCluster);

            strSQL = @" select      mhrs_cluster_num,
                                    question_num,
                                    answer_num
                        from        hra_mhrs_cluster_matrix
                        order by    mhrs_cluster_num";

            SqlDataAdapter daClusterMatrix = new SqlDataAdapter(strSQL, cn);
            DataTable tblClusterMatrix = new DataTable();
            daClusterMatrix.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daClusterMatrix.Fill(tblClusterMatrix);
            int intPreviousCluster = 0;
            bool bolValidateCluster = true;
            int intQuestionNum;
            int intAnswerNum;
            DataRow rowAnswer;
            DataRow rowCluster;
            object[] objPK2 = new object[2];
            int intBioAge = 0;

            foreach (DataRow rowClusterMatrix in tblClusterMatrix.Rows) {
                if ((int)rowClusterMatrix["mhrs_cluster_num"] != intPreviousCluster) {
                    if (intPreviousCluster != 0) {
                        if (bolValidateCluster == true) {
                            //cluster passed test, apply MHRS
                            rowCluster = tblCluster.Rows.Find(intPreviousCluster);

                            if (rowCluster != null) {
                                decMHRS -= (decimal)rowCluster["mhrs"];
                            }
                        }
                    }

                    bolValidateCluster = true;
                }

                if (bolValidateCluster == true) {
                    intQuestionNum = (int)rowClusterMatrix["question_num"];
                    intAnswerNum = (int)rowClusterMatrix["answer_num"];
                    objPK2[0] = ReportNum;
                    objPK2[1] = intQuestionNum;
                    rowAnswer = tblRiskReportDetail.Rows.Find(objPK2);

                    if (rowAnswer == null) {
                        bolValidateCluster = false;
                    }
                    else {
                        if ((int)rowAnswer["answer_num"] != intAnswerNum) {
                            bolValidateCluster = false;
                        }
                    }
                }

                intPreviousCluster = (int)rowClusterMatrix["mhrs_cluster_num"];
            }


            //update MHRS based on BMI
            strSQL = @" select      bmi_num,
                                    gender,
                                    bmi_min,
                                    bmi_max,
                                    mhrs
                        from        hra_mhrs_bmi
                        where       gender in ('" + (CurrentUser.Gender == "1" || CurrentUser.Gender == "M" ? "M" : "F") + @"','U')
                        order by    bmi_min, 
                                    bmi_max";

            SqlDataAdapter daBMI = new SqlDataAdapter(strSQL, cn);
            DataTable tblBMI = new DataTable();
            daBMI.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daBMI.Fill(tblBMI);

            foreach (DataRow rowBMI in tblBMI.Rows) {
                if (decBMI >= (decimal)rowBMI["bmi_min"] && decBMI <= (decimal)rowBMI["bmi_max"]) {
                    decMHRS -= (decimal)rowBMI["mhrs"];
                    break;
                }
            }

            //update MHRS based on waist circumference
            strSQL = @" select      waist_num,
                                    gender,
                                    waist_min,
                                    waist_max,
                                    mhrs
                        from        hra_mhrs_waist
                        where       gender in ('" + (CurrentUser.Gender == "1" || CurrentUser.Gender == "M" ? "M" : "F") + @"','U')
                        order by    waist_min, 
                                    waist_max";

            SqlDataAdapter daWaist = new SqlDataAdapter(strSQL, cn);
            DataTable tblWaist = new DataTable();
            daWaist.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daWaist.Fill(tblWaist);

            foreach (DataRow rowWaist in tblWaist.Rows) {
                if (intWaist >= (decimal)rowWaist["waist_min"] && intWaist <= (decimal)rowWaist["waist_max"]) {
                    decMHRS -= (decimal)rowWaist["mhrs"];
                    break;
                }
            }

            //update report with MHRS
            strSQL = @" select  risk_report_num,
                                mhrs_score,
                                bio_age
                        from    hra_risk_report 
                        where   risk_report_num = " + ReportNum.ToString();
            daRiskReport = new SqlDataAdapter(strSQL, cn);
            cbRiskReport = new SqlCommandBuilder(daRiskReport);
            tblRiskReport = new DataTable();
            tblRiskReport.Clear();
            daRiskReport.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReport.Fill(tblRiskReport);

            if (tblRiskReport.Rows.Count > 0) {
                intBioAge = CalculateBioAge(Convert.ToInt32(decMHRS));

                tblRiskReport.Rows[0]["mhrs_score"] = decMHRS;
                tblRiskReport.Rows[0]["bio_age"] = intBioAge;
                daRiskReport.Update(tblRiskReport);

                TrackMetric(MetricTypes.MHRScore, decMHRS);
                TrackMetric(MetricTypes.BIOAge, intBioAge);
            }
        }

        protected int CalculateBioAge(int MHRS) {
            intBioAge = CurrentUser.Age;

            if (MHRS >= 90) {
                intBioAge -= 10;
            }
            else if (MHRS >= 80 && MHRS <= 89) {
                intBioAge -= 5;
            }
            else if (MHRS >= 70 && MHRS <= 79) {
                intBioAge -= 0;
            }
            else if (MHRS >= 60 && MHRS <= 69) {
                intBioAge += 5;
            }
            else if (MHRS >= 50 && MHRS <= 59) {
                intBioAge += 10;
            }
            else {
                intBioAge += 15;
            }

            if (intBioAge < 0) {
                return CurrentUser.Age;
            }
            else {
                return intBioAge;
            }
        }

        protected void CalculateProteinRequirement(int Weight) {
            intProteinRequirement = (int)(Weight * 0.5);
        }

        protected void CalculateAerobicTrainingZones(int Age) {
            intATZMin = (int)((220 - Age) * 0.6);
            intATZMax = (int)((220 - Age) * 0.85);
        }

        protected void CalculateMedicationAdherenceScore() {
            int intQuestionNum;
            int intAnswerNum;

            decMedicationAdherenceScore = 0;
            bolReceiveMedicationAdherence = false;

            foreach (DataRow rowRiskReportDetail in tblRiskReportDetail.Rows) {
                intQuestionNum = (int)rowRiskReportDetail["question_num"];
                intAnswerNum = (int)rowRiskReportDetail["answer_num"];

                switch (intQuestionNum) {
                    case 222:
                        if (intAnswerNum == 2) {
                            decMedicationAdherenceScore += 1;
                        }

                        bolReceiveMedicationAdherence = true;
                        break;
                    case 223:
                        if (intAnswerNum == 2) {
                            decMedicationAdherenceScore += 1;
                        }

                        bolReceiveMedicationAdherence = true;
                        break;
                    case 224:
                        if (intAnswerNum == 2) {
                            decMedicationAdherenceScore += 1;
                        }

                        bolReceiveMedicationAdherence = true;
                        break;
                    case 225:
                        if (intAnswerNum == 2) {
                            decMedicationAdherenceScore += 1;
                        }

                        bolReceiveMedicationAdherence = true;
                        break;
                    case 226:
                        if (intAnswerNum == 2) {
                            decMedicationAdherenceScore += 1;
                        }

                        bolReceiveMedicationAdherence = true;
                        break;
                    case 227:
                        //should NEVER happen as the HRA has default answers
                        if (intAnswerNum == 0) {
                            decMedicationAdherenceScore += 1;
                        }
                        else if (intAnswerNum == 2) {
                            decMedicationAdherenceScore += 1;
                        }


                        bolReceiveMedicationAdherence = true;
                        break;
                    case 228:
                        if (intAnswerNum == 2) {
                            decMedicationAdherenceScore += 1;
                        }

                        bolReceiveMedicationAdherence = true;
                        break;
                    case 229:
                        switch (intAnswerNum) {
                            case 1:
                                decMedicationAdherenceScore += 4 / 4;
                                break;
                            case 2:
                                decMedicationAdherenceScore += 3 / 4;
                                break;
                            case 3:
                                decMedicationAdherenceScore += 2 / 4;
                                break;
                            case 4:
                                decMedicationAdherenceScore += 1 / 4;
                                break;
                        }

                        bolReceiveMedicationAdherence = true;
                        break;
                }
            }
        }

        protected void UpdatePlaceHolders() {
            foreach (DataRow rowFeedback in tblFeedback.Rows) {
                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[BMI]", decBMI.ToString("#0.00"));
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[BMI]", decBMI.ToString("#0.00"));
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[BMI]", decBMI.ToString("#0.00"));
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[BMI]", decBMI.ToString("#0.00"));
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[BMI]", decBMI.ToString("#0.00"));
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[BMI]", decBMI.ToString("#0.00"));

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[DietaryScore]", decDietaryScore.ToString("#0.00"));
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[DietaryScore]", decDietaryScore.ToString("#0.00"));
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[DietaryScore]", decDietaryScore.ToString("#0.00"));
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[DietaryScore]", decDietaryScore.ToString("#0.00"));
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[DietaryScore]", decDietaryScore.ToString("#0.00"));
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[DietaryScore]", decDietaryScore.ToString("#0.00"));

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[FirstName]", CurrentUser.FirstName);
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[FirstName]", CurrentUser.FirstName);
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[FirstName]", CurrentUser.FirstName);
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[FirstName]", CurrentUser.FirstName);
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[FirstName]", CurrentUser.FirstName);
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[FirstName]", CurrentUser.FirstName);

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[Surname]", CurrentUser.Surname);
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[Surname]", CurrentUser.Surname);
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[Surname]", CurrentUser.Surname);
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[Surname]", CurrentUser.Surname);
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[Surname]", CurrentUser.Surname);
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[Surname]", CurrentUser.Surname);

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[Age]", CurrentUser.Age.ToString("#0"));
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[Age]", CurrentUser.Age.ToString("#0"));
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[Age]", CurrentUser.Age.ToString("#0"));
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[Age]", CurrentUser.Age.ToString("#0"));
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[Age]", CurrentUser.Age.ToString("#0"));
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[Age]", CurrentUser.Age.ToString("#0"));

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[WaistCirc]", intWaist.ToString("#0"));
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[WaistCirc]", intWaist.ToString("#0"));
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[WaistCirc]", intWaist.ToString("#0"));
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[WaistCirc]", intWaist.ToString("#0"));
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[WaistCirc]", intWaist.ToString("#0"));
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[WaistCirc]", intWaist.ToString("#0"));

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[ProteinRequirement]", intProteinRequirement.ToString("#0"));
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[ProteinRequirement]", intProteinRequirement.ToString("#0"));
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[ProteinRequirement]", intProteinRequirement.ToString("#0"));
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[ProteinRequirement]", intProteinRequirement.ToString("#0"));
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[ProteinRequirement]", intProteinRequirement.ToString("#0"));
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[ProteinRequirement]", intProteinRequirement.ToString("#0"));

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[ATZMin]", intATZMin.ToString("#0"));
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[ATZMin]", intATZMin.ToString("#0"));
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[ATZMin]", intATZMin.ToString("#0"));
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[ATZMin]", intATZMin.ToString("#0"));
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[ATZMin]", intATZMin.ToString("#0"));
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[ATZMin]", intATZMin.ToString("#0"));

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[ATZMax]", intATZMax.ToString("#0"));
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[ATZMax]", intATZMax.ToString("#0"));
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[ATZMax]", intATZMax.ToString("#0"));
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[ATZMax]", intATZMax.ToString("#0"));
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[ATZMax]", intATZMax.ToString("#0"));
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[ATZMax]", intATZMax.ToString("#0"));

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[IMG]multivitamin.jpg", "<img src=\"/images/hra/Multivitamin.jpg\" alt=\"Multivitamin\"");
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[IMG]multivitamin.jpg", "<img src=\"/images/hra/Multivitamin.jpg\" alt=\"Multivitamin\"");
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[IMG]multivitamin.jpg", "<img src=\"/images/hra/Multivitamin.jpg\" alt=\"Multivitamin\"");
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[IMG]multivitamin.jpg", "<img src=\"/images/hra/Multivitamin.jpg\" alt=\"Multivitamin\"");
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[IMG]multivitamin.jpg", "<img src=\"/images/hra/Multivitamin.jpg\" alt=\"Multivitamin\"");
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[IMG]multivitamin.jpg", "<img src=\"/images/hra/Multivitamin.jpg\" alt=\"Multivitamin\"");

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[IMG]BloodTestsOfSignificance.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/basic_blood_tests.pdf\"> <img src=\"/images/hra/BloodTestsOfSignificance.jpg\" alt=\"Multivitamin\"> </a>");
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[IMG]BloodTestsOfSignificance.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/basic_blood_tests.pdf\"> <img src=\"/images/hra/BloodTestsOfSignificance.jpg\" alt=\"Multivitamin\"> </a>");
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[IMG]BloodTestsOfSignificance.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/basic_blood_tests.pdf\"> <img src=\"/images/hra/BloodTestsOfSignificance.jpg\" alt=\"Multivitamin\"> </a>");
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[IMG]BloodTestsOfSignificance.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/basic_blood_tests.pdf\"> <img src=\"/images/hra/BloodTestsOfSignificance.jpg\" alt=\"Multivitamin\"> </a>");
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[IMG]BloodTestsOfSignificance.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/basic_blood_tests.pdf\"> <img src=\"/images/hra/BloodTestsOfSignificance.jpg\" alt=\"Multivitamin\"> </a>");
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[IMG]BloodTestsOfSignificance.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/basic_blood_tests.pdf\"> <img src=\"/images/hra/BloodTestsOfSignificance.jpg\" alt=\"Multivitamin\"> </a>");

                rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[IMG]blood_interp.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/blood_interp.pdf\"> <img src=\"/images/hra/blood_interp.jpg\" alt=\"BloodInterp\"> </a>");
                rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[IMG]blood_interp.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/blood_interp.pdf\"> <img src=\"/images/hra/blood_interp.jpg\" alt=\"BloodInterp\"> </a>");
                rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[IMG]blood_interp.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/blood_interp.pdf\"> <img src=\"/images/hra/blood_interp.jpg\" alt=\"BloodInterp\"> </a>");
                rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[IMG]blood_interp.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/blood_interp.pdf\"> <img src=\"/images/hra/blood_interp.jpg\" alt=\"BloodInterp\"> </a>");
                rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[IMG]blood_interp.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/blood_interp.pdf\"> <img src=\"/images/hra/blood_interp.jpg\" alt=\"BloodInterp\"> </a>");
                rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[IMG]blood_interp.jpg", "<a href=\"https://meschinowellness.blob.core.windows.net/downloads/blood_interp.pdf\"> <img src=\"/images/hra/blood_interp.jpg\" alt=\"BloodInterp\"> </a>");
            }
        }

        protected void UpdateDownloadLinks() {
            foreach (DataRow rowFeedback in tblFeedback.Rows) {
                if (rowFeedback["MainFeedback"].ToString().Contains("[Download]")) {
                    rowFeedback["MainFeedback"] = ReplaceFeedbackLink(rowFeedback["MainFeedback"].ToString(), FeedbackLinkType.Download);
                }

                if (rowFeedback["SummaryFeedback"].ToString().Contains("[Download]")) {
                    rowFeedback["SummaryFeedback"] = ReplaceFeedbackLink(rowFeedback["SummaryFeedback"].ToString(), FeedbackLinkType.Download);
                }

                if (rowFeedback["Description"].ToString().Contains("[Download]")) {
                    rowFeedback["Description"] = ReplaceFeedbackLink(rowFeedback["Description"].ToString(), FeedbackLinkType.Download);
                }

                if (rowFeedback["Nutrition"].ToString().Contains("[Download]")) {
                    rowFeedback["Nutrition"] = ReplaceFeedbackLink(rowFeedback["Nutrition"].ToString(), FeedbackLinkType.Download);
                }

                if (rowFeedback["Supplements"].ToString().Contains("[Download]")) {
                    rowFeedback["Supplements"] = ReplaceFeedbackLink(rowFeedback["Supplements"].ToString(), FeedbackLinkType.Download);
                }

                if (rowFeedback["OtherConsiderations"].ToString().Contains("[Download]")) {
                    rowFeedback["OtherConsiderations"] = ReplaceFeedbackLink(rowFeedback["OtherConsiderations"].ToString(), FeedbackLinkType.Download);
                }

                if (rowFeedback["MainFeedback"].ToString().Contains("[LearnEarn]")) {
                    rowFeedback["MainFeedback"] = ReplaceFeedbackLink(rowFeedback["MainFeedback"].ToString(), FeedbackLinkType.LearnEarn);
                }

                if (rowFeedback["SummaryFeedback"].ToString().Contains("[LearnEarn]")) {
                    rowFeedback["SummaryFeedback"] = ReplaceFeedbackLink(rowFeedback["SummaryFeedback"].ToString(), FeedbackLinkType.LearnEarn);
                }

                if (rowFeedback["Description"].ToString().Contains("[LearnEarn]")) {
                    rowFeedback["Description"] = ReplaceFeedbackLink(rowFeedback["Description"].ToString(), FeedbackLinkType.LearnEarn);
                }

                if (rowFeedback["Nutrition"].ToString().Contains("[LearnEarn]")) {
                    rowFeedback["Nutrition"] = ReplaceFeedbackLink(rowFeedback["Nutrition"].ToString(), FeedbackLinkType.LearnEarn);
                }

                if (rowFeedback["Supplements"].ToString().Contains("[LearnEarn]")) {
                    rowFeedback["Supplements"] = ReplaceFeedbackLink(rowFeedback["Supplements"].ToString(), FeedbackLinkType.LearnEarn);
                }

                if (rowFeedback["OtherConsiderations"].ToString().Contains("[LearnEarn]")) {
                    rowFeedback["OtherConsiderations"] = ReplaceFeedbackLink(rowFeedback["OtherConsiderations"].ToString(), FeedbackLinkType.LearnEarn);
                }

                if (rowFeedback["MainFeedback"].ToString().Contains("[Tool]")) {
                    rowFeedback["MainFeedback"] = ReplaceFeedbackLink(rowFeedback["MainFeedback"].ToString(), FeedbackLinkType.Tool);
                }

                if (rowFeedback["SummaryFeedback"].ToString().Contains("[Tool]")) {
                    rowFeedback["SummaryFeedback"] = ReplaceFeedbackLink(rowFeedback["SummaryFeedback"].ToString(), FeedbackLinkType.Tool);
                }

                if (rowFeedback["Description"].ToString().Contains("[Tool]")) {
                    rowFeedback["Description"] = ReplaceFeedbackLink(rowFeedback["Description"].ToString(), FeedbackLinkType.Tool);
                }

                if (rowFeedback["Nutrition"].ToString().Contains("[Tool]")) {
                    rowFeedback["Nutrition"] = ReplaceFeedbackLink(rowFeedback["Nutrition"].ToString(), FeedbackLinkType.Tool);
                }

                if (rowFeedback["Supplements"].ToString().Contains("[Tool]")) {
                    rowFeedback["Supplements"] = ReplaceFeedbackLink(rowFeedback["Supplements"].ToString(), FeedbackLinkType.Tool);
                }

                if (rowFeedback["OtherConsiderations"].ToString().Contains("[Tool]")) {
                    rowFeedback["OtherConsiderations"] = ReplaceFeedbackLink(rowFeedback["OtherConsiderations"].ToString(), FeedbackLinkType.Tool);
                }
            }
        }

        protected void UpdateDietaryScoreImages(decimal DietaryScore) {
            string strImageLink;

            strImageLink = "<img src=\"/images/hra/DietaryPatternUnhealthy.jpg\" alt=\"DietaryPatternUnhealthy\"";

            if (DietaryScore <= 5) {
                strImageLink = "<img src=\"/images/hra/DietaryPatternExcellent.jpg\" alt=\"DietaryPatternExcellent\"";
            }
            else if (DietaryScore > 5 && DietaryScore <= 10) {
                strImageLink = "<img src=\"/images/hra/DietaryPatternGood.jpg\" alt=\"DietaryPatternGood\"";
            }
            else if (DietaryScore > 10 && DietaryScore <= 20) {
                strImageLink = "<img src=\"/images/hra/DietaryPatternFair.jpg\" alt=\"DietaryPatternFair\"";
            }
            else if (DietaryScore > 20 && DietaryScore <= 30) {
                strImageLink = "<img src=\"/images/hra/DietaryPatternPoor.jpg\" alt=\"DietaryPatternPoor\"";
            }
            else if (DietaryScore > 30 && DietaryScore <= 40) {
                strImageLink = "<img src=\"/images/hra/DietaryPatternVeryPoor.jpg\" alt=\"DietaryPatternVeryPoor\"";
            }
            else if (DietaryScore > 40) {
                strImageLink = "<img src=\"/images/hra/DietaryPatternUnhealthy.jpg\" alt=\"DietaryPatternUnhealthy\"";
            }

            foreach (DataRow rowFeedback in tblFeedback.Rows) {
                if (rowFeedback["MainFeedback"].ToString().Contains("[ImageDietaryScore]")) {
                    rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[ImageDietaryScore]", strImageLink);
                }

                if (rowFeedback["SummaryFeedback"].ToString().Contains("[ImageDietaryScore]")) {
                    rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[ImageDietaryScore]", strImageLink);
                }

                if (rowFeedback["Description"].ToString().Contains("[ImageDietaryScore]")) {
                    rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[ImageDietaryScore]", strImageLink);
                }

                if (rowFeedback["Nutrition"].ToString().Contains("[ImageDietaryScore]")) {
                    rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[ImageDietaryScore]", strImageLink);
                }

                if (rowFeedback["Supplements"].ToString().Contains("[ImageDietaryScore]")) {
                    rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[ImageDietaryScore]", strImageLink);
                }

                if (rowFeedback["OtherConsiderations"].ToString().Contains("[ImageDietaryScore]")) {
                    rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[ImageDietaryScore]", strImageLink);
                }

            }
        }

        protected void UpdateBMIScoreImages(decimal BMIScore) {
            string strImageLink;

            strImageLink = "<img src=\"/images/hra/BMIUnderweight.jpg\" alt=\"BMIUnderweight\"";

            if (BMIScore < 20) {
                strImageLink = "<img src=\"/images/hra/BMIUnderweight.jpg\" alt=\"BMIUnderweight\"";
            }
            else if (BMIScore >= 20 && BMIScore <= 25) {
                strImageLink = "<img src=\"/images/hra/BMINormal.jpg\" alt=\"BMINormal\"";
            }
            else if (BMIScore > 25 && BMIScore < 30) {
                strImageLink = "<img src=\"/images/hra/BMIGrade1.jpg\" alt=\"BMIGrade1\"";
            }
            else if (BMIScore >= 30 && BMIScore <= 40) {
                strImageLink = "<img src=\"/images/hra/BMIGrade2.jpg\" alt=\"BMIGrade2\"";
            }
            else if (BMIScore > 40) {
                strImageLink = "<img src=\"/images/hra/BMIGrade3.jpg\" alt=\"BMIGrade3\"";
            }

            foreach (DataRow rowFeedback in tblFeedback.Rows) {
                if (rowFeedback["MainFeedback"].ToString().Contains("[ImageBMIScore]")) {
                    rowFeedback["MainFeedback"] = rowFeedback["MainFeedback"].ToString().Replace("[ImageBMIScore]", strImageLink);
                }

                if (rowFeedback["SummaryFeedback"].ToString().Contains("[ImageBMIScore]")) {
                    rowFeedback["SummaryFeedback"] = rowFeedback["SummaryFeedback"].ToString().Replace("[ImageBMIScore]", strImageLink);
                }

                if (rowFeedback["Description"].ToString().Contains("[ImageBMIScore]")) {
                    rowFeedback["Description"] = rowFeedback["Description"].ToString().Replace("[ImageBMIScore]", strImageLink);
                }

                if (rowFeedback["Nutrition"].ToString().Contains("[ImageBMIScore]")) {
                    rowFeedback["Nutrition"] = rowFeedback["Nutrition"].ToString().Replace("[ImageBMIScore]", strImageLink);
                }

                if (rowFeedback["Supplements"].ToString().Contains("[ImageBMIScore]")) {
                    rowFeedback["Supplements"] = rowFeedback["Supplements"].ToString().Replace("[ImageBMIScore]", strImageLink);
                }

                if (rowFeedback["OtherConsiderations"].ToString().Contains("[ImageBMIScore]")) {
                    rowFeedback["OtherConsiderations"] = rowFeedback["OtherConsiderations"].ToString().Replace("[ImageBMIScore]", strImageLink);
                }

            }
        }

        protected string ReplaceFeedbackLink(string Feedback, FeedbackLinkType LinkType) {
            string strTag;
            string strTagID;
            string strTagName;
            string strTerminator = "<";
            string strHTML;
            int intTagStart;
            int intTagEnd;
            int intTagLength;

            switch (LinkType) {
                case FeedbackLinkType.Download:
                    strTagID = "[Download]";
                    break;
                case FeedbackLinkType.LearnEarn:
                    strTagID = "[LearnEarn]";
                    break;
                case FeedbackLinkType.Tool:
                    strTagID = "[Tool]";
                    break;
                default:
                    strTagID = "[Download]";
                    break;
            }

            do {
                if (Feedback.Contains(strTagID)) {
                    intTagStart = Feedback.IndexOf(strTagID);
                    intTagEnd = Feedback.IndexOf(strTerminator, intTagStart) + strTerminator.Length;

                    //ensure terminator is found at end of tag
                    if (intTagEnd <= strTerminator.Length) {
                        intTagEnd = intTagStart + LinkType.ToString().Length + 2;  //+2 for square brackets
                        intTagLength = intTagEnd - intTagStart;
                        strTag = Feedback.Substring(intTagStart, intTagLength);
                        strTagName = "";
                        strHTML = "ERROR! - Missing Terminator - " + LinkType.ToString();
                    }
                    else {
                        intTagLength = intTagEnd - intTagStart;
                        strTag = Feedback.Substring(intTagStart, intTagLength - strTerminator.Length);
                        strTagName = Feedback.Substring(intTagStart + strTagID.Length, intTagLength - strTagID.Length - strTerminator.Length);

                        switch (LinkType) {
                            case FeedbackLinkType.Download:
                                strHTML = GetDownloadLink(strTagName);
                                break;
                            case FeedbackLinkType.LearnEarn:
                                strHTML = GetLearnEarnLink(strTagName);
                                break;
                            case FeedbackLinkType.Tool:
                                strHTML = GetToolLink(strTagName);
                                break;
                            default:
                                strHTML = "";
                                break;
                        }
                    }

                    Feedback = Feedback.Replace(strTag, strHTML);
                }
                else {
                    break;
                }
            } while (true);

            return Feedback;
        }

        protected string CleanHTMLCoding(string Title) {
            string strTitleClean = Title;

            //replace ' with html encoding for '
            strTitleClean = strTitleClean.Replace("&#32;", " ");
            strTitleClean = strTitleClean.Replace("&#33;", "!");
            strTitleClean = strTitleClean.Replace("&#34;", "\"");
            strTitleClean = strTitleClean.Replace("&quot;", "\"");
            strTitleClean = strTitleClean.Replace("&#35;", "#");
            strTitleClean = strTitleClean.Replace("&#36;", "$");
            strTitleClean = strTitleClean.Replace("&#37;", "%");
            strTitleClean = strTitleClean.Replace("&#38;", "&");
            strTitleClean = strTitleClean.Replace("&amp;", "&");
            strTitleClean = strTitleClean.Replace("&#39;", "''");
            strTitleClean = strTitleClean.Replace("&#40;", "(");
            strTitleClean = strTitleClean.Replace("&#41;", ")");
            strTitleClean = strTitleClean.Replace("&#42;", "*");
            strTitleClean = strTitleClean.Replace("&#43;", "+");
            strTitleClean = strTitleClean.Replace("&#44;", ",");
            strTitleClean = strTitleClean.Replace("&#45;", "-");
            strTitleClean = strTitleClean.Replace("&NDASH;", "-");
            strTitleClean = strTitleClean.Replace("&#46;", ".");
            strTitleClean = strTitleClean.Replace("&#47;", "/");

            return strTitleClean;
        }

        protected string GetDownloadLink(string Title) {
            string strURL = string.Empty;
            string strURLDefault = "/MyWellnessWallet";
            string strURLText = string.Empty;
            string strHTML = string.Empty;
            Boolean bolUpdateLink = true;

            if (Title == null || Title == "") {
                strHTML = "<a style=\"color: red; font: bold;\" href=\"" + strURLDefault + "\"> * * * * * " + Title.ToUpper() + " * * * * * </a>";
                strHTML = string.Empty;
            }
            else {
                //find download by title 
                tblDownload.DefaultView.RowFilter = "content_title = '" + CleanHTMLCoding(Title.Replace("'", "''")) + "'";

                if (tblDownload.DefaultView.ToTable().Rows.Count > 0) {
                    rowDownload = tblDownload.DefaultView.ToTable().Rows[0];
                    strURL = rowDownload["url"].ToString();
                    strURLText = rowDownload["url_text"].ToString();

                    if (strURLText == "" || strURLText == null) {
                        Title += " - URL Text is Missing for Download";
                        bolUpdateLink = false;
                    }

                    if (strURL == "" || strURL == null) {
                        Title += " - URL is Missing for Download";
                        bolUpdateLink = false;
                    }
                }
                else {
                    Title += " - Download Not Found";
                    bolUpdateLink = false;
                }

                if (bolUpdateLink == true) {
                    strHTML = "<a href=\"" + strURL + "\">" + strURLText + "</a>";
                }
                else {
                    strHTML = "<a style=\"color: red; font: bold;\" href=\"" + strURLDefault + "\"> * * * * * " + Title.ToUpper() + " * * * * * </a>";
                    strHTML = string.Empty;
                }
            }

            return strHTML;
        }

        protected string GetLearnEarnLink(string Name) {
            string strURL = string.Empty;
            string strURLDefault = "/MyWellnessWallet";
            string strURLText = string.Empty;
            string strHTML = string.Empty;
            string strPoints = string.Empty;
            Boolean bolUpdateLink = true;

            if (Name == null || Name == "") {
                strHTML = "<a style=\"color: red; font: bold;\" href=\"" + strURLDefault + "\"> * * * * * " + Name.ToUpper() + " * * * * * </a>";
                strHTML = string.Empty;
            }
            else {
                //escape any single quotes with double quotes
                tblLearnEarn.DefaultView.RowFilter = "name = '" + CleanHTMLCoding(Name.Replace("'", "''")) + "'";

                if (tblLearnEarn.DefaultView.ToTable().Rows.Count > 0) {
                    rowLearnEarn = tblLearnEarn.DefaultView.ToTable().Rows[0];
                    strURL = rowLearnEarn["url"].ToString();
                    strURLText = rowLearnEarn["url_text"].ToString();
                    strPoints = rowLearnEarn["points"].ToString();

                    if (strURLText == "" || strURLText == null) {
                        Name += " - URL Text is Missing for Learn & Earn";
                        bolUpdateLink = false;
                    }

                    if (strURL == "" || strURL == null) {
                        Name += " - URL is Missing for Learn & Earn";
                        bolUpdateLink = false;
                    }
                }
                else {
                    Name += " - Learn & Earn Not Found";
                    bolUpdateLink = false;
                }

                if (bolUpdateLink == true) {
                    strHTML = "<a href=\"" + strURL + "\" style=\"text-decoration: underline;\">" + strURLText + "</a><text> (Learn and Earn: Earn </text><text style=\"font-weight: bold;\">" + strPoints + " Reward Points</text><text>)</text>";
                }
                else {
                    strHTML = "<a style=\"color: red; font: bold;\" href=\"" + strURLDefault + "\"> * * * * * " + Name.ToUpper() + " * * * * * </a>";
                    strHTML = string.Empty;
                }
            }

            return strHTML;
        }

        protected string GetToolLink(string Title) {
            string strURL = string.Empty;
            string strURLDefault = "/MyWellnessWallet";
            string strURLText = string.Empty;
            string strHTML = string.Empty;
            Boolean bolUpdateLink = true;

            if (Title == null || Title == "") {
                strHTML = "<a style=\"color: red; font: bold;\" href=\"" + strURLDefault + "\"> * * * * * " + Title.ToUpper() + " * * * * * </a>";
                strHTML = string.Empty;
            }
            else {
                tblTool.DefaultView.RowFilter = "description = '" + CleanHTMLCoding(Title.Replace("'", "''")) + "'";

                if (tblTool.DefaultView.ToTable().Rows.Count > 0) {
                    rowTool = tblTool.DefaultView.ToTable().Rows[0];
                    strURL = rowTool["url"].ToString();
                    strURLText = rowTool["url_text"].ToString();

                    if (strURLText == "" || strURLText == null) {
                        Title += " - URL Text is Missing for Tool";
                        bolUpdateLink = false;
                    }

                    if (strURL == "" || strURL == null) {
                        Title += " - URL is Missing for Tool";
                        bolUpdateLink = false;
                    }
                }
                else {
                    Title += " - Tool Not Found";
                    bolUpdateLink = false;
                }

                if (bolUpdateLink == true) {
                    strHTML = "<a href=\"" + strURL + "\">" + strURLText + "</a>";
                }
                else {
                    strHTML = "<a style=\"color: red; font: bold;\" href=\"" + strURLDefault + "\"> * * * * * " + Title.ToUpper() + " * * * * * </a>";
                    strHTML = string.Empty;
                }
            }

            return strHTML;
        }

        protected void SaveFeedback(int ReportNum, DataTable Feedback) {
            SqlDataAdapter daRiskReportFeedback;
            SqlDataAdapter daRiskReportFeedbackCondition;
            SqlCommandBuilder cbRiskReportFeedback;
            SqlCommandBuilder cbRiskReportFeedbackCondition;
            DataTable tblRiskReportFeedback = new DataTable("hra_risk_report_feedback");
            DataTable tblRiskReportFeedbackCondition = new DataTable("hra_risk_report_feedback_condition");
            DataRow rowRiskReportFeedback;
            DataRow rowRiskReportFeedbackCondition;
            int intRiskReportFeedbackNum;
            object[] objPK2 = new object[2];


            strSQL = @" select  risk_report_feedback_num,
                                risk_report_num,
                                feedback_section_num,
                                sort_order,
                                condition_num,
                                question_num,
                                answer_num,
                                main_feedback,
                                summary_feedback,
                                description,
                                nutrition,
                                supplements,
                                other_considerations,
                                create_date
                        from    hra_risk_report_feedback 
                        where   risk_report_num = " + ReportNum;
            daRiskReportFeedback = new SqlDataAdapter(strSQL, cn);
            cbRiskReportFeedback = new SqlCommandBuilder(daRiskReportFeedback);
            tblRiskReportFeedback.Clear();
            daRiskReportFeedback.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportFeedback.Fill(tblRiskReportFeedback);

            //ensure all existing feedback for this report is deleted, if it exists.
            foreach (DataRow row in tblRiskReportFeedback.Rows) {
                row.Delete();
            }
            daRiskReportFeedback.Update(tblRiskReportFeedback);

            strSQL = @" select  risk_report_feedback_num, 
                                risk_report_num, 
                                condition_num 
                        from    hra_risk_report_feedback_condition 
                        where   risk_report_num = " + ReportNum;
            daRiskReportFeedbackCondition = new SqlDataAdapter(strSQL, cn);
            cbRiskReportFeedbackCondition = new SqlCommandBuilder(daRiskReportFeedbackCondition);
            tblRiskReportFeedbackCondition.Clear();
            daRiskReportFeedbackCondition.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReportFeedbackCondition.Fill(tblRiskReportFeedbackCondition);

            //ensure all existing feedback conditions for this report are deleted, if they exists.
            foreach (DataRow row in tblRiskReportFeedbackCondition.Rows) {
                row.Delete();
            }
            daRiskReportFeedbackCondition.Update(tblRiskReportFeedbackCondition);

            //sort feedback to control feedback order
            tblFeedback.DefaultView.Sort = "SortOrder ASC";

            foreach (DataRow rowFeedback in tblFeedback.DefaultView.ToTable().Rows) {
                rowRiskReportFeedback = tblRiskReportFeedback.NewRow();
                rowRiskReportFeedback["risk_report_num"] = ReportNum;
                rowRiskReportFeedback["feedback_section_num"] = rowFeedback["FeedbackSectionNum"];
                rowRiskReportFeedback["sort_order"] = rowFeedback["SortOrder"];
                rowRiskReportFeedback["condition_num"] = rowFeedback["ConditionNum"];
                rowRiskReportFeedback["question_num"] = rowFeedback["QuestionNum"];
                rowRiskReportFeedback["answer_num"] = rowFeedback["AnswerNum"];
                rowRiskReportFeedback["main_feedback"] = rowFeedback["MainFeedback"];
                rowRiskReportFeedback["summary_feedback"] = rowFeedback["SummaryFeedback"];
                rowRiskReportFeedback["description"] = rowFeedback["Description"];
                rowRiskReportFeedback["nutrition"] = rowFeedback["Nutrition"];
                rowRiskReportFeedback["supplements"] = rowFeedback["Supplements"];
                rowRiskReportFeedback["other_considerations"] = rowFeedback["OtherConsiderations"];
                rowRiskReportFeedback["create_date"] = DateTime.UtcNow;
                tblRiskReportFeedback.Rows.Add(rowRiskReportFeedback);
                daRiskReportFeedback.Update(tblRiskReportFeedback);

                //get new feedback # from db using identity
                SqlCommand cmdPK = new SqlCommand("select @@identity", cn);
                intRiskReportFeedbackNum = (int)(decimal)cmdPK.ExecuteScalar();
                cmdPK.Dispose();

                tblConditionForFeedback.DefaultView.RowFilter = "FeedbackNum = " + rowFeedback["FeedbackNum"].ToString();

                foreach (DataRow rowConditionForFeedback in tblConditionForFeedback.DefaultView.ToTable().Rows) {
                    objPK2[0] = intRiskReportFeedbackNum;
                    objPK2[1] = rowConditionForFeedback["ConditionNum"];

                    DataRow rowCheck = tblRiskReportFeedbackCondition.Rows.Find(objPK2);

                    if (rowCheck == null) {
                        rowRiskReportFeedbackCondition = tblRiskReportFeedbackCondition.NewRow();
                        rowRiskReportFeedbackCondition["risk_report_feedback_num"] = intRiskReportFeedbackNum;
                        rowRiskReportFeedbackCondition["condition_num"] = rowConditionForFeedback["ConditionNum"];
                        rowRiskReportFeedbackCondition["risk_report_num"] = ReportNum;
                        tblRiskReportFeedbackCondition.Rows.Add(rowRiskReportFeedbackCondition);
                        daRiskReportFeedbackCondition.Update(tblRiskReportFeedbackCondition);
                    }
                }
            }
        }

        protected void UpdateRiskReport(int ReportNum, bool Completed) {
            //update report status
            strSQL = @" select  risk_report_num,
                                completed,
                                completed_date,
                                IsSyncRequired,
                                IsDeleted,
                                weight,
                                waist
                        from    hra_risk_report 
                        where   risk_report_num = " + ReportNum.ToString();
            daRiskReport = new SqlDataAdapter(strSQL, cn);
            cbRiskReport = new SqlCommandBuilder(daRiskReport);
            tblRiskReport = new DataTable();
            tblRiskReport.Clear();
            daRiskReport.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReport.Fill(tblRiskReport);

            if (tblRiskReport.Rows.Count > 0) {
                tblRiskReport.Rows[0]["completed"] = true;
                tblRiskReport.Rows[0]["completed_date"] = DateTime.UtcNow;
                tblRiskReport.Rows[0]["IsSyncRequired"] = true;
                tblRiskReport.Rows[0]["IsDeleted"] = false;
                daRiskReport.Update(tblRiskReport);

                TrackMetric(MetricTypes.Weight, Convert.ToDecimal(tblRiskReport.Rows[0]["weight"]));
                TrackMetric(MetricTypes.Waist, Convert.ToDecimal(tblRiskReport.Rows[0]["waist"]));
            }
        }
    }

    //temporary user class to use within HRA while user tables schema defined.
    public class HRAUser {
        private int _Age;
        private string _FirstName;
        private string _Surname;
        private DateTime _DOB;
        private int _Height;
        private string _ID;
        private string _Gender;

        private const int DEFAULT_AGE = 25;
        private const int DEFAULT_HEIGHT = 60;
        private const string DEFAULT_GENDER = "M";

        public HRAUser() {
            //default to a male of 25 years of age with height of 60"
            _DOB = DateTime.Today.AddYears(DEFAULT_AGE * -1);
            _Gender = DEFAULT_GENDER;
            _Height = DEFAULT_HEIGHT;
        }

        public int Age {
            get {
                if (DOB == null) {
                    return DEFAULT_AGE;
                }
                else {
                    _Age = DateTime.Today.Year - DOB.Year;

                    if (_Age > 0) {
                        _Age -= Convert.ToInt32(DateTime.Today < DOB.Date.AddYears(_Age));
                    }
                    else {
                        _Age = DEFAULT_AGE;
                    }

                    return _Age;
                }
            }
        }

        public string FirstName {
            get { return _FirstName; }
            set {
                if (value == null || value == "") {
                    _FirstName = "No First Name";
                }
                else {
                    _FirstName = value;
                }
            }
        }

        public string Surname {
            get { return _Surname; }
            set {
                if (value == null || value == "") {
                    _Surname = "No Surname";
                }
                else {
                    _Surname = value;
                }
            }
        }

        public DateTime DOB {
            get { return _DOB; }
            set { _DOB = value; }
        }

        public int Height {
            get { return _Height; }
            set { _Height = value; }
        }

        public string ID {
            get { return _ID; }
            set { _ID = value; }
        }

        public string Gender {
            get { return _Gender; }
            set {
                switch (value) {
                    case null:
                        _Gender = DEFAULT_GENDER;
                        break;
                    case "Male":
                        _Gender = "M";
                        break;
                    case "M":
                        _Gender = "M";
                        break;
                    case "Female":
                        _Gender = "F";
                        break;
                    case "F":
                        _Gender = "F";
                        break;
                    default:
                        _Gender = DEFAULT_GENDER;
                        break;
                }
            }
        }
    }
}
