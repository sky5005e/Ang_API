﻿/**
 * Project: Inforica - Date Util Library
 * Author: Naga Phaneendra Nagubandi
 * Contributors: Kiran Banda, Sanghi Krishna Kanhiya
 *
 * Dependencies: JQuery
 *
 * Utility to handle date functions.
 *
 * License: Inforica India Private Limited
 *
 */
Inforica.DateUtil = new function () {
    /// <summary>
    /// Inforica.DateUtil Library - A custom Jquery library for Date functions.
    /// <method>IsValidDate</method>
    /// <method>IsAFutureDate</method>
    /// <method>IsAPastDate</method>
    /// <method>CompareDates</method>
    /// </summary>
    /// <returns type=""></returns>


    function IsValidDate(date) {
        /// <summary>
        /// Validate given string is a valid Date or not
        /// Returns Boolean Value
        /// </summary>
        /// <param name="date"></param>
        /// <returns type=""></returns>
        Inforica.Logger.Log(ToString("IsValidDate"), "Is a Valid Date - " + date);
        try {
            if ($.trim(date).length == 0) {
                return;
            }
            var test = Date.parseExact(date, "MM/dd/yyyy");
            if (!test) {
                return false;
            }
            Inforica.Logger.Log(ToString("IsValidDate"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("IsValidDate"), e.toString());
        }
    }

    function IsAFutureDate(date) {
        /// <summary>
        /// Validates the given date is a future date or not.
        /// Returns boolean if it is a valid date else it will return error message.
        /// </summary>
        /// <param name="date"></param>
        /// <returns type=""></returns>
        Inforica.Logger.Log(ToString("IsAFutureDate"), "Is a Future Date - " + date);
        try {
            if ($.trim(date).length == 0) {
                return;
            }

            var test = Date.parseExact(date, "MM/dd/yyyy");
            if (!test) {
                return "Invalid date. Enter date in MM/DD/YYYY format";
            }
            var now = new Date();
            if (date > now) {
                return true;
            }
            else {
                return false;
            }
            Inforica.Logger.Log(ToString("IsAFutureDate"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("IsAFutureDate"), e.toString());
        }
    }

    function IsAPastDate(date) {
        /// <summary>
        /// Validates the given date is a past date or not.
        /// Returns boolean if it is a valid date else it will return error message.
        /// </summary>
        /// <param name="date"></param>
        /// <returns type=""></returns>
        Inforica.Logger.Log(ToString("IsAPastDate"), "Is a Past Date - " + date);
        try {
            if ($.trim(date).length == 0) {
                return;
            }
            var test = Date.parseExact(date, "MM/dd/yyyy");
            if (!test) {
                return "Invalid date. Enter date in MM/DD/YYYY format";
            }
            var now = new Date();
            if (date < now) {
                return true;
            }
            else {
                return false;
            }
            Inforica.Logger.Log(ToString("IsAPastDate"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("IsAPastDate"), e.toString());
        }
    }

    function CompareDates(dateFirst, dateSecond, format) {
        /// <summary>
        /// Compares both the dates.
        /// Return boolean value
        /// </summary>
        /// <param name="dateFirst"></param>
        /// <param name="dateSecond"></param>
        /// <param name="format"></param>
        /// <returns type=""></returns>
        Inforica.Logger.Log(ToString("CompareDates"), "Compares the Dates - " + dateFirst + ", " + dateSecond + " with the format - " + format);
        try {
            var date1 = Date.parseExact(d1, format);
            var date2 = Date.parseExact(d2, format);
            return date1.compareTo(date2);
            Inforica.Logger.Log(ToString("CompareDates"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("CompareDates"), e.toString());
        }
    }

    function ToString(methodName) {
        /// <summary>
        /// Gives the Class Name appended before the method name.
        /// </summary>
        /// <param name="methodName"></param>
        /// <returns type=""></returns>
        return "Inforica.DateUtil." + methodName + " ";
    }

    return {
        IsValidDate: IsValidDate,
        IsAFutureDate: IsAFutureDate,
        IsAPastDate: IsAPastDate,
        CompareDates: CompareDates
    };
};