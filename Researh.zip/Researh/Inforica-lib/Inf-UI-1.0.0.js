﻿/**
 * Project: Inforica - UI Libraray
 * Author: Sanghi Krishna Kanhiya
 * Contributors: Kiran Banda
 *
 * Dependencies: JQuery, Bootstrap and Bootbox
 *
 *
 * License: Inforica India Private Limited
 *
 */

Inforica.UI = new function () {
    /// <summary>
    /// Inforica.UI Library - A custom Jquery library for UI elements.
    /// </summary>
    /// <method>Alert</method>
    /// <method>AlertWithCallBack</method>
    /// <method>Confirm</method>
    /// <method>GetWindowHeight</method>
    /// <method>GetWindowWidth</method>
    /// <returns type=""></returns>

    function Alert(message) {
        /// <summary>
        /// Opens an Alert Message.
        /// </summary>
        /// <param name="message"></param>
        Inforica.Logger.Log(ToString("Alert"), "Alert - " + message);
        try {
            bootbox.alert(message);
            Inforica.Logger.Log(ToString("Alert"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("Alert"), e.toString());
        }
    }

    function AlertWithCallBack(message, fnCallBackFunction) {
        /// <summary>
        /// Opens an Alert with a CallBackFunction
        /// </summary>
        /// <param name="message"></param>
        /// <param name="fnCallBackFunction"></param>
        Inforica.Logger.Log(ToString("AlertWithCallBack"), "Alert - " + message + " with Call Back Function - ");
        try {
            bootbox.confirm(message, fnCallBackFunction);
            Inforica.Logger.Log(ToString("AlertWithCallBack"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("AlertWithCallBack"), e.toString());
        }
    }

    function Confirm(message, fnCallBack) {
        /// <summary>
        /// Opens a confirm window with call back function.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="fnCallBack"></param>
        Inforica.Logger.Log(ToString("Confirm"), "Confirm - " + message + " with Call Back Function - ");
        try {
            bootbox.confirm(message, function (result) {
                fnCallBack(result);
            });
            Inforica.Logger.Log(ToString("Confirm"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("Confirm"), e.toString());
        }
    }

    function GetWindowHeight() {
        /// <summary>
        /// Returns the Window height
        /// </summary>
        /// <returns type=""></returns>
        Inforica.Logger.Log(ToString("GetWindowHeight"), "Returns the Window height");
        try {
            if (window.innerHeight) {
                return window.innerHeight;
            }
            return document.documentElement.clientHeight;
            Inforica.Logger.Log(ToString("GetWindowHeight"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("GetWindowHeight"), e.toString());
        }
    }

    function ApplyMasking(formID) {

        $('#' + formID + " .mask").each(function () {
            var format = $(this).attr('format');
            if (format != undefined) {
                $(this).inputmask(format, { "clearIncomplete": true });
            }
        });

        $('#' + formID + " .mask").change(function () {
            var targetControlID = $(this).attr('targetControlID');
            if ($(this).inputmask("isComplete")) {
                var value = $(this).val().replace(/\-/g, '');
                value = value.replace(/\(/g, '');
                value = value.replace(/\)/g, '');
                $('#' + targetControlID).val(value);
            }
            else {
                $('#' + targetControlID).val('');
            }
        });
    }

    function GetWindowWidth() { }

    function GetContactAdminMessage() {
        return "<div class='row'><div class='col-md-9'><div class='alert alert-danger'> Sorry there has been an error.  Please try reloading this module by exiting then returning to the module. If the module still does not load please contact customer support (<a href='mailto:support@meschinowellness.com'>support@meschinowellness.com</a>)</div></div></div>";
    }

    function ToString(methodName) {
        /// <summary>
        /// Gives the Class Name appended before the method name.
        /// </summary>
        /// <param name="methodName"></param>
        /// <returns type=""></returns>
        return "Inforica.UI." + methodName + " ";
    }

    return {
        Alert: Alert,
        AlertWithCallBack: AlertWithCallBack,
        Confirm: Confirm,
        GetWindowHeight: GetWindowHeight,
        GetWindowWidth: GetWindowWidth,
        ApplyMasking: ApplyMasking,
        GetContactAdminMessage: GetContactAdminMessage
    };
};
