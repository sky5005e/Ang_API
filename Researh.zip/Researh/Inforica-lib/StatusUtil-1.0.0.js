﻿/**
 * Project: Inforica - Status Util Library
 * Author: Naga Phaneendra Nagubandi
 * Contributors: Kiran Banda, Sanghi Krishna Kanhiya
 *
 * Dependencies: JQuery
 *
 * Utility to handle notifications.
 *
 * License: Inforica India Private Limited
 *
 */
Inforica.StatusUtil = new function () {
    /// <summary>
    /// Inforica.StatusUtil Library - A custom Jquery Library for Showing the Statuses on web pages.
    /// </summary>
    /// <method>ShowStatus</method>
    /// <method>HideStatus</method>
    /// <method>ShowProgressBar</method>
    /// <method>HideProgressBar</method>
    /// <method>ShowNotes</method>
    /// <method>CleanContainer</method>
    /// <returns type=""></returns>
    function ShowProgressBar(progressBarType, targetContainer, message) {
        /// <summary>
        /// Show progress indicator
        /// </summary>
        /// <param name="progressBarType">Possible values : success / info / warning / danger</param>
        /// <param name="targetContainer">Container ID</param>
        /// <param name="message">Message to be displayed along with the progress indicator</param>
        Inforica.Logger.Log(ToString("ShowProgressBar"), "Show Progress Bar for a given container ID : " + targetContainer);
        try {
            if (progressBarType == null) {
                progressBarType = "info";
            }
            if (message == null) {
                message = '';
            }
            var reference = $('#' + targetContainer);
            if (reference.length > 0) {
                reference.removeClass();
                reference.removeAttr('class');
                reference.addClass("progress progress-striped active");
                reference.html("<div class='progress-bar progress-bar-" + progressBarType + "' role='progressbar' style='width: 100%'<span class='sr-only'>" + message + "</span></div>");
                Inforica.Logger.Log(ToString("ShowProgressBar"), "Success");
            }
        }
        catch (e) {
            Inforica.Logger.Log(ToString("ShowProgressBar"), e.toString());
        }
    }

    function HideProgressBar(targetContainerID) {
        /// <summary>
        /// Hide progress indicator
        /// </summary>        
        /// <param name="targetContainerID">Container ID</param>
        Inforica.Logger.Log(ToString("HideProgressBar"), "Hide Progress Bar for a given container ID : " + targetContainerID);
        try {
            var reference = $('#' + targetContainerID);
            if (reference.length > 0) {
                reference.removeClass();
                reference.removeAttr('class');
                reference.html('');
                Inforica.Logger.Log(ToString("HideProgressBar"), "Success");
            }
        }
        catch (e) {
            Inforica.Logger.Log(ToString("HideProgressBar"), e.toString());
        }

    }

    function ShowStatus(status, containerID, msg) {
        /// <summary>
        /// Show status / progress indicator
        /// </summary>
        /// <param name="status">Possible values : success / info / warning / danger</param>
        /// <param name="msg">Message to be displayed along with the progress indicator</param>
        /// <param name="containerID">Container ID</param>
        Inforica.Logger.Log(ToString("ShowStatus"), "Show Status for a given container ID : " + containerID);
        try {
            $container = $("#" + containerID);

            var statusMessage = "";
            if (status == "success") {
                statusMessage = "<strong>Success! </strong>";
            }
            else if (status == "info") {
                statusMessage = "<strong>Info! </strong>";
            }
            else if (status == "warning") {
                statusMessage = "<strong>Warning! </strong>";
            }
            else if (status == "danger") {
                statusMessage = "<strong>Error! </strong>";
            }
            $container.html("<div class='alert alert-" + status + "'> <strong>" + statusMessage + "</strong> " + msg + "</div>");
            Inforica.Logger.Log(ToString("ShowStatus"), "Success");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("ShowStatus"), e.toString());
        }
    }

    function HideStatus(containerID) {
        /// <summary>
        /// Hide status / progress indicator
        /// </summary>
        /// <param name="containerID">Container ID</param>
        Inforica.Logger.Log(ToString("HideStatus"), "Hide Status Indicator for a given container ID : " + containerID);
        try {
            $container = $("#" + containerID);
            $container.html('');
            Inforica.Logger.Log(ToString("HideStatus"), "Success");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("HideStatus"), e.toString());
        }
    }

    function ShowNotes(status, containerID, message) {
        /// <summary>
        /// Show Notes
        /// </summary>
        /// <param name="status"></param>
        /// <param name="containerID"></param>
        /// <param name="message"></param>
        Inforica.Logger.Log(ToString("ShowNotes"), "Show Notes Bar for a given container ID : " + containerID);
        try {
            var targetContainer = $("#" + containerID);
            if (targetContainer.length > 0) {
                targetContainer.removeClass();
                targetContainer.removeAttr('class');
                targetContainer.addClass("note note-" + status);
                targetContainer.html("<p>" + message + "</p>");
            }
            Inforica.Logger.Log(ToString("ShowNotes"), "Success");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("ShowNotes"), e.toString());
        }
    }

    function CleanContainer(containerID) {
        /// <summary>
        /// Cleans the container.
        /// </summary>
        /// <param name="containerID"></param>
        Inforica.Logger.Log(ToString("CleanContainer"), "Clean Container for a given container ID : " + containerID);
        try {
            var targetContainer = $("#" + containerID);
            if (targetContainer.length > 0) {
                targetContainer.removeClass();
                targetContainer.removeAttr('class');
                targetContainer.html('');
            }
            Inforica.Logger.Log(ToString("CleanContainer"), "Success");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("CleanContainer"), e.toString());
        }
    }

    function ToString(methodName) {
        return "Inforica.StatusUtil." + methodName + " ";
    }

    function BlockBootstrapModel(modelId) {
        if (modelId != undefined && modelId != null) {
            $('#' + modelId + ' .modal-dialog .modal-content').block({
                message: "<div class='loading-message loading-message-boxed'>"
                + "<img align='center' class='img-spinner-gray' alt='spinner'/><span>&nbsp;&nbsp;Please Wait ...</span></div>",
                css: { border: 'none', background: '#666666' }
            });
        }
    }

    function UnBlockBootstrapModel(modelId) {
        if (modelId != undefined && modelId != null) {
            $('#' + modelId + ' .modal-dialog .modal-content').unblock();
        }
    }

    function ShowModelStatus(message, fnCallBack) {
        if (fnCallBack != undefined && fnCallBack != null) {
            bootbox.alert(message, function () {
                fnCallBack();
            });
        }
        else {
            bootbox.alert(message);
        }
    }

    function CallFunction(fnFunction) {
        if (fnFunction != undefined && fnFunction != null && window[fnFunction] != undefined) {
            window[fnFunction]();
        }
    }

    function HideBootstrapModel(modelId) {
        if (modelId != undefined && modelId != null) {
            $("#" + modelId).modal('hide');
        }
    }

    return {
        ShowStatus: ShowStatus,
        HideStatus: HideStatus,
        ShowProgressBar: ShowProgressBar,
        HideProgressBar: HideProgressBar,
        ShowNotes: ShowNotes,
        CleanContainer: CleanContainer,
        BlockBootstrapModel: BlockBootstrapModel,
        UnBlockBootstrapModel: UnBlockBootstrapModel,
        ShowModelStatus: ShowModelStatus,
        CallFunction: CallFunction,
        HideBootstrapModel: HideBootstrapModel
    };    
};

Inforica.Constants =
{
    Info: "info",
    Success: "success",
    Danger: "danger",
    Warning: "warning"
};


