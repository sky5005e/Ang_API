﻿/**
 * Project: Inforica - Notifications Util Library
 * Author: Naga Phaneendra Nagubandi
 * Contributors: Kiran Banda, Sanghi Krishna Kanhiya
 *
 * Dependencies: JQuery, toastr, jquery.notific8
 *
 * Utility to handle notifications.
 *
 * License: Inforica India Private Limited
 *
 */
Inforica.NotificationUtil = new function () {
	/// <summary>
    /// Notification Util
	/// </summary>
	/// <returns type=""></returns>
    var toastCount = 0,
        $toastlast;

    function ShowToasterNotification(notificationType, message, title) {
        /// <summary>
        /// Shows Notification
        /// </summary>
        /// <param name="notificationType">Possible Values : success / info / warning / danger </param>
        /// <param name="message">Message to be displayed in notification</param>
        /// <param name="title">Title for the notification</param>
        Inforica.Logger.Log(ToString("ShowToasterNotification"), "Show Toaster Notification.");
        try {

            if ($.trim(notificationType).length == 0) {
                notificationType = "info";
            }
            if ($.trim(message).length == 0) {
                message = "Please provide a message to display.";
            }
            if ($.trim(title).length == 0) {
                title = "Please provide a title.";
            }

            var shortCutFunction = notificationType;
            var msg = message;
            var title = title;
            var showDuration = 1000;
            var hideDuration = 1000;
            var timeOut = 5000;
            var extendedTimeOut = 1000;
            var showEasing = 'swing';
            var hideEasing = 'linear';
            var showMethod = 'fadeIn';
            var hideMethod = 'fadeOut';
            var toastIndex = toastCount++;
            var toastPosition = 'toast-top-right'

            toastr.options = {
                closeButton: true,
                debug: false,
                positionClass: toastPosition,
                onclick: null
            };


            toastr.options.onclick = function () {
                alert('You clicked the notification');
            };


            toastr.options.showDuration = showDuration;
            toastr.options.hideDuration = hideDuration;
            toastr.options.timeOut = timeOut;
            toastr.options.extendedTimeOut = extendedTimeOut;
            toastr.options.showEasing = showEasing;
            toastr.options.hideEasing = hideEasing;
            toastr.options.showMethod = showMethod;
            toastr.options.hideMethod = hideMethod;

            var $toast = toastr[shortCutFunction](msg, title); // Wire up an event handler to a button in the toast, if it exists
            $toastlast = $toast;
            Inforica.Logger.Log(ToString("ShowToasterNotification"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("ShowToasterNotification"), e.toString());
        }
    }

    function clearToasterNotifications() {
        /// <summary>
        /// Clears all toaster notifications on the page.
        /// </summary>
        Inforica.Logger.Log(ToString("clearToasterNotifications"), "Clear All Toaster Notifications.");
        try {
            toastr.clear();
            Inforica.Logger.Log(ToString("clearToasterNotifications"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("clearToasterNotifications"), e.toString());
        }
    };

    function clearLastToasterNotification() {
        /// <summary>
        /// Clears last toaster notification on the page.
        /// </summary>
        Inforica.Logger.Log(ToString("clearLastToasterNotification"), "Clear Last Toaster Notification.");
        try {
            if ($toastlast != null) {
                toastr.clear($toastlast);
                $toastlast = null;
                Inforica.Logger.Log(ToString("clearLastToasterNotification"), "Success.");
            }
            else {
                Inforica.UI.Alert("Last Notification already turned off.");
                Inforica.Logger.Log(ToString("clearLastToasterNotification"), "Last Notification already turned off.");
            }

        }
        catch (e) {
            Inforica.Logger.Log(ToString("clearLastToasterNotification"), e.toString());
        }
    };

    function ShowNotification(msg, notificationTheme, isSticky, horizontalEdge, verticalEdge, heading, notificationTime) {
        /// <summary>
        /// Show styled Notification
        /// </summary>
        /// <param name="msg">Message to be displayed in Notification.</param>
        /// <param name="notificationTheme">The theme for notification. Possible Vaalues : amethyst / ruby / tangerine / lemon / lime / ebony / smoke </param>
        /// <param name="isSticky">Does the notification has to be sticky? Possible values : true / false.</param>
        /// <param name="horizontalEdge">Possible Values : top / bottom</param>
        /// <param name="verticalEdge">Possible Values : right / left</param>
        /// <param name="heading">Heading for the Notification</param>
        /// <param name="notificationTime">How much time the notification should be displayed? - If isSticky is false</param>
        Inforica.Logger.Log(ToString("ShowNotification"), "Show Notification.");
        try {
            if ($.trim(notificationTheme).length == 0) {
                notificationTheme = "ebony";
            }
            if ($.trim(msg).length == 0) {
                msg = "Please provide a message to display.";
            }
            if ($.trim(isSticky).length == 0) {
                isSticky = false;
            }
            if ($.trim(horizontalEdge).length == 0) {
                horizontalEdge = "top";
            }
            if ($.trim(verticalEdge).length == 0) {
                verticalEdge = "right";
            }
            if ($.trim(notificationTime).length == 0) {
                notificationTime = 60;
            }
            var settings = {
                theme: notificationTheme,
                sticky: isSticky,
                horizontalEdge: horizontalEdge,
                verticalEdge: verticalEdge
            };

            settings.heading = heading;

            if (!isSticky) {
                settings.life = notificationTime;
            }

            $.notific8('zindex', 11500);
            $.notific8($.trim(msg), settings); Inforica.Logger.Log(ToString("ShowNotification"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("ShowNotification"), e.toString());
        }
    }

    function ToString(methodName) {
        return "Inforica.NotificationUtil." + methodName + " ";
    }

    return {
        ShowToasterNotification: ShowToasterNotification,
        clearToasterNotifications: clearToasterNotifications,
        clearLastToasterNotification: clearLastToasterNotification,
        ShowNotification: ShowNotification
    };
};