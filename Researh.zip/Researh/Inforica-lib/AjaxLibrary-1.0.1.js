﻿0/**
 * Project: Inforica - Ajax Library
 * Author: Sanghi Krishna Kanhiya
 * Contributors: Kiran Banda
 *
 * Dependencies: JQuery
 *
 * Ajax base library to to handle ajax request through out in application
 *
 * License: Inforica India Private Limited
 *
 */

Inforica.Ajax = new function () {

    var _showGlobalProgress = true;
    var ShowGlobalProgress = function (show) {
        _showGlobalProgress = show;
    }
	/// <summary>
	/// Inforica.Ajax Library
    /// </summary>
    /// <method>Get</method>
    /// <method>GetAsync</method>
    /// <method>Post</method>
    /// <method>PostAsync</method>
    /// <method>ConfigurePageLoader</method>
    /// <method>GetErrorDetails</method>
	/// <returns type=""></returns>
    function ConfigurePageLoader() {
    	/// <summary>
    	/// Configures the Ajax Page Loader
    	/// </summary>
        $(document).ajaxStart(fnBlockUI).ajaxStop(fnUnBlockUI).ajaxError(fnUnBlockUI);
    }

    var fnBlockUI = function () {
    	/// <summary>
    	/// Blocks UI
        /// </summary>
        if (_showGlobalProgress) {
            $.blockUI({
                message: '<img src="/Content/img/win8-loader.GIF" style="z-index:999999"/>',
                css: { backgroundColor: 'transparent', border: 'none' },
                overlayCSS: { backgroundColor: 'transparent', opacity: 0.0, cursor: 'wait', "z-index" : 999999 }
            });
        }
    }

    var fnUnBlockUI = function () {
    	/// <summary>
    	/// Unblocks UI.
        /// </summary>
        if (_showGlobalProgress) {
            $.unblockUI();
        }
    }

    function BuildUrl(action, controller, area) {
    	/// <summary>
    	/// Builds URL with given parameters.
    	/// </summary>
    	/// <param name="action"></param>
    	/// <param name="controller"></param>
    	/// <param name="area"></param>
    	/// <returns type=""></returns>
        Inforica.Logger.Log(ToString("BuildUrl"), "Buliding url");
        try {
            var url = '';
            if (area != null && area != undefined && area != '') {
                url = "/" + area + "/" + controller + "/" + action;
            }
            else {
                url = "/" + controller + "/" + action;
            }
            Inforica.Logger.Log(ToString("BuildUrl"), "Url Created : " + url);
            return url;

        } catch (e) {
            Inforica.Logger.Log("BuildUrl", e)
        }
    }

    function GetErrorDetails(error) {
        /// <summary>
    	/// Get Error Details from the error.
    	/// </summary>
    	/// <param name="error"></param>
        /// <returns type=""></returns>
        var errorMessage = 'An error occurred while processing the request.';
        try {
            var isJsonResponse = false;
            if (error.status == 403) {
                errorMessage = "Session time out."
                isJsonResponse = true;
            }
            else if (error.status == 404) {
                errorMessage = "File not found"
            }
            else if (error.status == 500) {
                errorMessage = "Internal Server Error"
                isJsonResponse = true;
            }
            else {
                errorMessage = "Unknown error"
            }
            if (isJsonResponse) {
                var errorDescription = $.parseJSON(error.responseText);
                errorMessage = errorDescription.ErrorMessage;
            }
            else {
                errorMessage = error.responseText;
            }

        } catch (e) {

        }
        return errorMessage;
    }

    function DefaultErrorHandler(error) {
    	/// <summary>
    	/// Default Error Handler.
    	/// </summary>
    	/// <param name="error"></param>
        var errorMessage = ' An error has occurred while processing your request';
        try {
            var isJsonResponse = false;
            if (error.status == 403) {
                Inforica.Logger.Log(ToString("DefaultErrorHandler"), "403");
                isJsonResponse = true;
            }
            else if (error.status == 404) {
                Inforica.Logger.Log(ToString("DefaultErrorHandler"), "404");
            }
            else if (error.status == 500) {
                Inforica.Logger.Log(ToString("DefaultErrorHandler"), "500");
                isJsonResponse = true;
            }
            else {
                Inforica.Logger.Log(ToString("DefaultErrorHandler"), "Unspecified Error");
            }
            if (isJsonResponse) {
                var errorDescription = $.parseJSON(error.responseText);
                Inforica.Logger.Log(ToString("DefaultErrorHandler"), errorDescription.ErrorMessage);
                Inforica.UI.Alert(errorDescription.ErrorMessage);
            }
            else {
                Inforica.Logger.Log(ToString("DefaultErrorHandler"), error.responseText);
                Inforica.UI.Alert(error.responseText);
            }


        } catch (e) {
            Inforica.Logger.Log(ToString("DefaultErrorHandler"), e);
        }
    }

    function ToString(methodName) {
    	/// <summary>
    	/// Gives the Class Name appended before the method name.
    	/// </summary>
    	/// <param name="methodName"></param>
    	/// <returns type=""></returns>
        return "Inforica.Ajax." + methodName + " ";
    }

    function Get(action, controller, area, params, fnSuccessCallBack, fnErrorCallBack) {
    	/// <summary>
    	/// Ajax Call - Get
    	/// </summary>
    	/// <param name="action"></param>
    	/// <param name="controller"></param>
    	/// <param name="area"></param>
    	/// <param name="params"></param>
    	/// <param name="fnSuccessCallBack"></param>
    	/// <param name="fnErrorCallBack"></param>
        if (fnSuccessCallBack == undefined) { throw "Success call back is not specified" }
        $.ajax({
            url: BuildUrl(action, controller, area),
            type: 'GET',
            async: false,
            cache: false,
            data: params,
            success: function (msg) {
                if (fnSuccessCallBack != undefined) {
                    fnSuccessCallBack(msg);
                }
            },
            error: function (err, errStatus) {
                if (fnErrorCallBack == undefined) {
                    DefaultErrorHandler(err, errStatus)
                } else {
                    fnErrorCallBack(err, errStatus);
                }
            }
        });
    }

    function GetAsync(action, controller, area, params, fnSuccessCallBack, fnErrorCallBack) {
    	/// <summary>
    	/// Ajax Call - Get Async
    	/// </summary>
    	/// <param name="action"></param>
    	/// <param name="controller"></param>
    	/// <param name="area"></param>
    	/// <param name="params"></param>
    	/// <param name="fnSuccessCallBack"></param>
    	/// <param name="fnErrorCallBack"></param>
        if (fnSuccessCallBack == undefined) { throw "Success call back is not specified" }

        if (CheckInternetConnection()) {
            $.ajax({
                url: BuildUrl(action, controller, area),
                type: 'GET',
                async: true,
                cache: false,
                data: params,
                success: function (msg) {
                    if (fnSuccessCallBack != undefined) {
                        fnSuccessCallBack(msg);
                    }
                },
                error: function (err, errStatus) {
                    if (fnErrorCallBack == undefined) {
                        DefaultErrorHandler(err, errStatus)
                    } else {
                        fnErrorCallBack(err, errStatus);
                    }
                }
            });
        }
        else {
            var errorObject = new Object();
            errorObject.responseText = "Your session has beed expired."
            if (fnErrorCallBack == undefined) {
                DefaultErrorHandler(errorObject);
            }
            else {
                fnErrorCallBack(errorObject);
            }
        }
    }

    function CheckInternetConnection() {
    	/// <summary>
    	/// Checks the Internet Connection.
    	/// </summary>
    	/// <returns type=""></returns>
        try {            
            jQuery.ajaxSetup({ async: false });
            re = "";
            r = Math.round(Math.random() * 10000);
            $.get("/Content/img/win8-loader.GIF", { subins: r }, function (d) {
                re = true;
            }).error(function () {
                re = false;
            });
            return re;
        } catch (e) {

        }
        return false;
    }

    function Post(action, controller, area, params, fnSuccessCallBack, fnErrorCallBack) {
    	/// <summary>
    	/// Ajax Call - Post.
    	/// </summary>
    	/// <param name="action"></param>
    	/// <param name="controller"></param>
    	/// <param name="area"></param>
    	/// <param name="params"></param>
    	/// <param name="fnSuccessCallBack"></param>
        /// <param name="fnErrorCallBack"></param>
        if (fnSuccessCallBack == undefined) {
            Inforica.Logger.Log(ToString("HideValidationMessage"), "Success call back is not specified ");
        }
        try {
            Inforica.Logger.Log(ToString("Post"), "Creating Request");
            $.ajax({
                url: BuildUrl(action, controller, area),
                type: 'POST',
                async: false,
                cache: false,
                data: params,
                success: function (msg) {
                    if (fnSuccessCallBack != undefined) {
                        fnSuccessCallBack(msg);
                    }
                    Inforica.Logger.Log(ToString("Post"), "Request Completed");
                },
                error: function (err, errStatus) {
                    Inforica.Logger.Log(ToString("Post"), "Request Error");
                    if (fnErrorCallBack == undefined) {
                        DefaultErrorHandler(err, errStatus)
                    } else {
                        fnErrorCallBack(err, errStatus);
                    }
                }
            });
        } catch (e) {
            Inforica.Logger.Log(ToString("Post"), e);
        }
    }

    function PostAsync(action, controller, area, params, fnSuccessCallBack, fnErrorCallBack) {
    	/// <summary>
    	/// Ajax Call - Post Async.
    	/// </summary>
    	/// <param name="action"></param>
    	/// <param name="controller"></param>
    	/// <param name="area"></param>
    	/// <param name="params"></param>
    	/// <param name="fnSuccessCallBack"></param>
        /// <param name="fnErrorCallBack"></param>
        if (fnSuccessCallBack == undefined) {
            Inforica.Logger.Log(ToString("HideValidationMessage"), "Success call back is not specified ");
        }
        if (CheckInternetConnection()) {
            try {
                Inforica.Logger.Log(ToString("PostAsync"), "Creating Request");
                $.ajax({
                    url: BuildUrl(action, controller, area),
                    type: 'POST',
                    async: true,
                    cache: false,
                    data: params,
                    success: function (msg) {
                        if (fnSuccessCallBack != undefined) {
                            fnSuccessCallBack(msg);
                        }
                        Inforica.Logger.Log(ToString("PostAsync"), "Request Completed");
                    },
                    error: function (err, errStatus) {
                        Inforica.Logger.Log(ToString("PostAsync"), "Request Error");
                        if (fnErrorCallBack == undefined) {
                            DefaultErrorHandler(err, errStatus)
                        } else {
                            fnErrorCallBack(err, errStatus);
                        }
                    }
                });
            } catch (e) {
                Inforica.Logger.Log(ToString("Post"), e);
            }
        }
        else {
            var errorObject = new Object();
            errorObject.responseText = "Your session has beed expired."
            if (fnErrorCallBack == undefined) {
                DefaultErrorHandler(errorObject);
            }
            else {
                fnErrorCallBack(errorObject);
            }
        }
    }

    function PostAsyncUrl(url, params, fnSuccessCallBack, fnErrorCallBack) {
        /// <summary>
        /// Ajax Call - Post Async.
        /// </summary>
        /// <param name="action"></param>
        /// <param name="controller"></param>
        /// <param name="area"></param>
        /// <param name="params"></param>
        /// <param name="fnSuccessCallBack"></param>
        /// <param name="fnErrorCallBack"></param>
        if (fnSuccessCallBack == undefined) {
            Inforica.Logger.Log(ToString("HideValidationMessage"), "Success call back is not specified ");
        }
        if (CheckInternetConnection()) {
            try {
                Inforica.Logger.Log(ToString("PostAsync"), "Creating Request");
                $.ajax({
                    url: url,
                    type: 'POST',
                    async: true,
                    cache: false,
                    data: params,
                    success: function (msg) {
                        if (fnSuccessCallBack != undefined) {
                            fnSuccessCallBack(msg);
                        }
                        Inforica.Logger.Log(ToString("PostAsync"), "Request Completed");
                    },
                    error: function (err, errStatus) {
                        Inforica.Logger.Log(ToString("PostAsync"), "Request Error");
                        if (fnErrorCallBack == undefined) {
                            DefaultErrorHandler(err, errStatus)
                        } else {
                            fnErrorCallBack(err, errStatus);
                        }
                    }
                });
            } catch (e) {
                Inforica.Logger.Log(ToString("Post"), e);
            }
        }
        else {
            var errorObject = new Object();
            errorObject.responseText = "Your session has beed expired."
            if (fnErrorCallBack == undefined) {
                DefaultErrorHandler(errorObject);
            }
            else {
                fnErrorCallBack(errorObject);
            }
        }
    }

    function GetAsyncUrl(url, params, fnSuccessCallBack, fnErrorCallBack) {
        /// <summary>
        /// Ajax Call - Get Async.
        /// </summary>
        /// <param name="action"></param>
        /// <param name="controller"></param>
        /// <param name="area"></param>
        /// <param name="params"></param>
        /// <param name="fnSuccessCallBack"></param>
        /// <param name="fnErrorCallBack"></param>
        if (fnSuccessCallBack == undefined) {
            Inforica.Logger.Log(ToString("HideValidationMessage"), "Success call back is not specified ");
        }
        if (CheckInternetConnection()) {
            try {
                Inforica.Logger.Log(ToString("GetAsyncUrl"), "Creating Request");
                $.ajax({
                    url: url,
                    type: 'GET',
                    async: true,
                    cache: false,
                    data: params,
                    success: function (msg) {
                        if (fnSuccessCallBack != undefined) {
                            fnSuccessCallBack(msg);
                        }
                        Inforica.Logger.Log(ToString("GetAsyncUrl"), "Request Completed");
                    },
                    error: function (err, errStatus) {
                        Inforica.Logger.Log(ToString("GetAsyncUrl"), "Request Error");
                        if (fnErrorCallBack == undefined) {
                            DefaultErrorHandler(err, errStatus)
                        } else {
                            fnErrorCallBack(err, errStatus);
                        }
                    }
                });
            } catch (e) {
                Inforica.Logger.Log(ToString("Post"), e);
            }
        }
        else {
            var errorObject = new Object();
            errorObject.responseText = "Your session has beed expired."
            if (fnErrorCallBack == undefined) {
                DefaultErrorHandler(errorObject);
            }
            else {
                fnErrorCallBack(errorObject);
            }
        }
    }

    return {
        Get: Get,
        GetAsync: GetAsync,
        Post: Post,
        PostAsync: PostAsync,
        ConfigurePageLoader: ConfigurePageLoader,
        GetErrorDetails: GetErrorDetails,
        ShowGlobalProgress: ShowGlobalProgress,
        PostAsyncUrl: PostAsyncUrl,
        GetAsyncUrl: GetAsyncUrl
    };
};




