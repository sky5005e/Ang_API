﻿/**
 * Project: Inforica - Base Frame Work
 * Author: Sanghi Krishna Kanhiya
 * Contributors: Kiran Banda
 *
 * Dependencies: JQuery
 *
 *
 * License: Inforica India Private Limited
 *
 */


// Safely creating namespaces //
// Since we still have one global object, there’s still a possibility that we are overwriting another global object with the same name. Therefore, we need to build in some safety //

var Inforica = Inforica || {};

Inforica.App = new function () {
    var globalDirtyContainer = [];
    var confirmExit = function () {
        var len = globalDirtyContainer.length;
        if (len > 0) {
            return "You have attempted to leave this page.  If you have made any changes to the fields without clicking the Save button, your changes will be lost.  Are you sure you want to exit this page?";
        }
    };

    function PromptForDirtyFlag() {
        /// <summary>
        /// Raise a prompt to indicate that a form / container is dirty.
        /// </summary>
        /// <returns type=""></returns>
        return confirm("If you have made any changes to the fields without clicking the Save button, your changes will be lost.  Are you sure you want to exit this page?");
    }

    function MarkContainerAsDirty(containerName) {
        /// <summary>
        /// Explicitly mark a container / form as dirty.
        /// </summary>
        /// <param name="containerName">ID of the container to be marked as dirty. The container could be any DOM element. Jquery $(#..) query is used to reference the element.</param>
        $('#' + containerName).attr("isDirty", "true");
        if (globalDirtyContainer.indexOf(containerName) == -1) {
            globalDirtyContainer.push(containerName);
        }
    }

    function WatchElementsForChange(containerName, excludedcontainerName, fnCallBack, routedValues) {
        /// <summary>
        /// Watch elements for change and mark them as dirty accordingly.
        /// </summary>
        /// <param name="containerName">ID of the container to be watched</param>
        /// <param name="excludedcontainerName">Ignore list of container IDs that shouldn't be tracked.</param>
        /// <param name="fnCallBack">User defined callback function that will be invoked after marking the container as dirty. This is helpful to enable / disable form buttons.</param>
        /// <param name="routedValues">Context to be passed back to the fnCallback</param>
        if (excludedcontainerName == undefined) {
            $('#' + containerName + ' :input').live("change", function (e) {
                $('#' + containerName).attr("isDirty", "true");

                if (globalDirtyContainer.indexOf(containerName) == -1) {
                    globalDirtyContainer.push(containerName);
                }
                if (fnCallBack != null) { fnCallBack($(this), routedValues); }
            });
        }
        else {

            $('#' + containerName + ' :input:not(#' + excludedcontainerName + ' :input)').live("change", function (e) {
                $('#' + containerName).attr("isDirty", "true");
                if (globalDirtyContainer.indexOf(containerName) == -1) {
                    globalDirtyContainer.push(containerName);
                }
                if (fnCallBack != null) { fnCallBack($(this), routedValues); }
            });
        }
    }

    function WatchMyContainer(containerName, excludedcontainerName, fnCallBack, routedValues) {
        /// <summary>
        /// Watch a container for change and mark it as dirty accordingly.
        /// </summary>
        /// <param name="containerName">ID of the container to be watched</param>
        /// <param name="excludedcontainerName">Ignore list of container IDs that shouldn't be tracked.</param>
        /// <param name="fnCallBack">User defined callback function that will be invoked after marking the container as dirty. This is helpful to enable / disable form buttons.</param>
        /// <param name="routedValues">Context to be passed back to the fnCallback</param>
        var containerInsertIndex = globalDirtyContainer.indexOf(containerName);
        if (containerInsertIndex == -1) {
            WatchElementsForChange(containerName, excludedcontainerName, fnCallBack, routedValues);
        }
        else {
            Inforica.UI.Alert("Container Name should be unique across");
        }
    }
    function CleanMyContainer(containerName) {
        /// <summary>
        /// Clear the dirty flag on a container
        /// </summary>
        /// <param name="containerName">ID of the container</param>
        $('#' + containerName).attr("isDirty", "false");

        var containerIndex = globalDirtyContainer.indexOf(containerName);
        if (containerIndex > -1) {
            globalDirtyContainer.splice(containerIndex, 1);
        }

        //Clear messages
        $('#' + containerName).find(".form-group").each(function () {
            var formGroup = $(this);
            formGroup.removeClass("has-error");
            $("span.help-block", formGroup).last().remove();
        });
    }

    function IsMyContainerDirty(containerName) {
        /// <summary>
        /// Check to see if a container if dirty
        /// </summary>
        /// <param name="containerName">ID of the container</param>
        /// <returns type="">True if the container is dirty, false otherwise</returns>
        if ($('#' + containerName).attr("isDirty") == "true") {
            return true;
        }
        return false;
    }

    function CleanAllContainers() {
        /// <summary>
        /// Clear dirty flags on all the containers. It also clears off validation messages.
        /// </summary>
        globalDirtyContainer = [];


        $('[isDirty]').each(function () {
            $(this).attr("isDirty", "false");
        });

        //Clear messages
        $(".form-group").each(function () {
            var formGroup = $(this);
            formGroup.removeClass("has-error");
            $("span.help-block", formGroup).last().remove();
        });
    }
    function OpenInNewWindow(url) {
        /// <summary>
        /// Opens the given url in new window.
        /// </summary>
        /// <param name="url"></param>
        window.open(url, '_blank');
    }
    return {
        ConfirmOnExit: confirmExit,
        PromptForDirtyFlag: PromptForDirtyFlag,
        MarkContainerAsDirty: MarkContainerAsDirty,
        WatchElementsForChange: WatchElementsForChange,
        WatchMyContainer: WatchMyContainer,
        CleanMyContainer: CleanMyContainer,
        IsMyContainerDirty: IsMyContainerDirty,
        CleanAllContainers: CleanAllContainers,
        OpenInNewWindow: OpenInNewWindow
    }
};

Inforica.Logger = new function () {
    /// <summary>
    /// Inforica.Logger - A custom Jquery library for Logging.
    /// Logger can be used to Log the errors on console
    /// <method>Log</method>
    /// </summary>
    /// <returns type=""></returns>
    function Log(sourceMethod, message) {
        console.log(sourceMethod + ":" + message);
    }
    return {
        Log: Log
    };
};

Inforica.Wizard = new function () {

    var wizardSteps = [];

    function ChangeTabs(wizardSelector, index, previousButton, nextButton, beforeUnload) {
        var totalSteps = parseInt($(wizardSelector).attr("wizardSteps"));
        var activeStep = parseInt($(wizardSelector).attr("activeStep"));
        var nextElement = $(wizardSelector + "_" + index);
        if (!nextElement.parent('li').hasClass("ui-state-disabled")) {
            if (beforeUnload != undefined && beforeUnload($(wizardSelector).attr("activeStep")) == true) {

                var element = $(wizardSelector + "_" + index);
                var loadurl = $(element).attr('href');
                var targ = $(element).attr('data-target');

                $.get(loadurl, function (data) {
                    $(targ).html(data);
                    $(element).tab('show');
                });

                $(wizardSelector).attr("activeStep", index);

                HandleButtons(wizardSelector, previousButton, nextButton);
            }
        }

    }

    function DisableStep(wizardSelector, index) {
        $(wizardSelector + " li a").each(function (i) {
            var currentIndex = parseInt($(this).attr("wizardIndex"));
            if (isNaN(currentIndex)) {
                currentIndex = -1;
            }
            if (currentIndex == index) {
                $(this).addClass("btn disabled");
            }
        });
    }

    function CreateWizard(wizardSelector, previousButton, nextButton, beforeUnload) {

        var totalSteps;
        var leastStep = null;
        $(wizardSelector + " li a").each(function (i) {
            $(this).attr("wizardIndex", i);
            $(this).attr("id", wizardSelector.replace('#', '') + "_" + i);

            if (!$(this).parent('li').hasClass('ui-state-disabled')) {
                totalSteps = i;
                if (leastStep == null) {
                    leastStep = i;
                }
            }

            $(this).click(function () {
                ChangeTabs(wizardSelector, parseInt($(this).attr("wizardIndex")), previousButton, nextButton, beforeUnload);
                return false;
            });
        });

        $(wizardSelector).attr("wizardSteps", totalSteps);
        $(wizardSelector).attr("activeStep", leastStep);
        $(wizardSelector).attr("leastStep", leastStep);
        if (leastStep != null && leastStep > 0) {
            ChangeTabs(wizardSelector, parseInt($(this).attr("wizardIndex")), previousButton, nextButton, beforeUnload);
        }
        HandleButtons(wizardSelector, previousButton, nextButton);

        $(previousButton).click(function () {

            var activeStep = parseInt($(wizardSelector).attr("activeStep"));
            var steptoRun = activeStep - 1;

            var nextElement = $(wizardSelector + "_" + steptoRun);
            if (nextElement.parent('li').hasClass("ui-state-disabled")) {
                $(wizardSelector).attr("activeStep", steptoRun);
                $(previousButton).click();
            }
            else {
                ChangeTabs(wizardSelector, steptoRun, previousButton, nextButton, beforeUnload);
            }

        });

        $(nextButton).click(function () {
            var activeStep = parseInt($(wizardSelector).attr("activeStep"));
            var steptoRun = activeStep + 1;
            var totalSteps = $(wizardSelector).attr("wizardSteps");
            //ChangeTabs(wizardSelector, steptoRun, previousButton, nextButton, beforeUnload);
            var nextElement = $(wizardSelector + "_" + steptoRun);
            if (nextElement.parent('li').hasClass("ui-state-disabled")) {
                $(wizardSelector).attr("activeStep", steptoRun);
                $(nextButton).click();
            }
            else {
                if (steptoRun <= totalSteps) {
                    ChangeTabs(wizardSelector, steptoRun, previousButton, nextButton, beforeUnload);
                }
                else {
                    HandleButtons(wizardSelector, previousButton, nextButton);
                }
            }
        });

    }

    function HandleButtons(wizardSelector, previousButton, nextButton) {
        var totalSteps = $(wizardSelector).attr("wizardSteps");
        var activeStep = $(wizardSelector).attr("activeStep");
        var leastStep = $(wizardSelector).attr("leastStep");
        if (activeStep <= leastStep) {
            $(previousButton).attr("disabled", "disabled");
            $(nextButton).removeAttr("disabled");
        }
        else if (activeStep == totalSteps) {
            $(previousButton).removeAttr("disabled");
            $(nextButton).attr("disabled", "disabled");
        }
        else {
            $(previousButton).removeAttr("disabled");
            $(nextButton).removeAttr("disabled");
        }
    }

    return {
        CreateWizard: CreateWizard,
        DisableStep: DisableStep
    };
};

Inforica.KendoUtil = {};

Inforica.DateUtil = {};

Inforica.Constants = {};

Inforica.StringUtil = new function () {
    /// <summary>
    /// Inforica.StringUtil Library - A custom Jquery library for string functions.
    /// </summary>
    /// <method>Trim</method>
    /// <returns type=""></returns>

    function Trim(string) {
        /// <summary>
        /// Truncate white spaces in a given string
        /// </summary>
        /// <param name="string"></param>
        /// <returns type=""></returns>
        Inforica.Logger.Log(ToString("Trim"), "Trim - " + string);
        try {
            return $.Trim(string);
            Inforica.Logger.Log(ToString("Trim"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("Trim"), e.toString());
        }
    }
    function ToString(methodName) {
        /// <summary>
        /// Gives the Class Name appended before the method name.
        /// </summary>
        /// <param name="methodName"></param>
        /// <returns type=""></returns>
        return "Inforica.StringUtil." + methodName + " ";
    }
    return {
        Trim: Trim
    };
};

Inforica.RegularExpressionValidation = new function () {
    /// <summary>
    /// Inforica.RegularExpressionValidation Library - A custom AJAX library for Regular Expressions Validation
    /// </summary>
    /// <returns type=""></returns>

    function IsValidEmail(email) { }

    return { IsValidEmail: IsValidEmail };
};

Inforica.Ajax = {};

Inforica.FormUtil = new function () {
    /// <summary>
    /// Inforica.FormUtil Library - A custom Jquery library for Form Utilities.
    /// </summary>
    /// <method>SubmitOnEnter</method>
    /// <method>ResetSubmitOnEnter</method>
    /// <method>ClearForm</method>
    /// <returns type=""></returns>

    function SubmitOnEnter(formID, buttonID) {
        /// <summary>
        /// SubmitOnEnter
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="buttonID"></param>
        Inforica.Logger.Log(ToString("SubmitOnEnter"), "Submit on Enter");
        try {
            $('#' + formID + ' input').keypress(function (e) {
                if ((e.which && e.which == 13) || (e.keyCode && e.keyCode == 13)) {
                    $('#' + buttonID).click();
                    return false;
                }
                else {
                    return true;
                }
            });
            Inforica.Logger.Log(ToString("SubmitOnEnter"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("SubmitOnEnter"), e.toString());
        }
    }

    function ResetSubmitOnEnter(formID, buttonID) {
        /// <summary>
        /// Reset Submit On Enter
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="buttonID"></param>
        Inforica.Logger.Log(ToString("ResetSubmitOnEnter"), "Initlize Reset");
        try {
            Inforica.Logger.Log("Not Implemented Exception");
            Inforica.Logger.Log(ToString("ResetSubmitOnEnter"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("ResetSubmitOnEnter"), e.toString());
        }
    }

    function ClearForm(formID) {
        /// <summary>
        /// Clear Form
        /// </summary>
        /// <param name="formID"></param>
        Inforica.Logger.Log(ToString("ClearForm"), "Clear Form");
        try {
            var targetFormContainer = $('#' + formID);
            if (targetFormContainer.length > 0) {

                $('#' + formID + ' input[type="text"]').each(function () {
                    $(this).val('');
                });

                $('#' + formID + ' input[type="password"]').each(function () {
                    $(this).val('');
                });

                $('#' + formID + ' textarea').each(function () {
                    $(this).val('');
                });

                $('#' + formID + ' select').each(function () {
                    $(this).val('');
                });
            }
            Inforica.Logger.Log(ToString("ClearForm"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("ClearForm"), e.toString());
        }

    }

    function ToString(methodName) {
        /// <summary>
        /// Gives the Class Name appended before the method name.
        /// </summary>
        /// <param name="methodName"></param>
        /// <returns type=""></returns>
        return "Inforica.FormUtil." + methodName + " ";
    }

    return {
        SubmitOnEnter: SubmitOnEnter,
        ResetSubmitOnEnter: ResetSubmitOnEnter,
        ClearForm: ClearForm
    };
};

Inforica.ValidationEngine = {};

Inforica.UI = {};

Inforica.StatusUtil = {};
Inforica.NotificationUtil = {};
; (function (window) {
    /// <summary>
    /// 
    /// </summary>
    /// <param name="window"></param>
    window.onbeforeunload = Inforica.App.ConfirmOnExit;

})(window)