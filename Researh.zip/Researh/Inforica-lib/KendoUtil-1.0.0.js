﻿/**
 * Project: Inforica - Kendo Util Library
 * Author: Naga Phaneendra Nagubandi
 * Contributors: Kiran Banda, Sanghi Krishna Kanhiya
 *
 * Dependencies: JQuery, Kendo
 *
 * Utility to handle Kendo controls events.
 *
 * License: Inforica India Private Limited
 *
 */
Inforica.KendoUtil = new function () {

    var tooltipConstants = {
        Search: 0,
        View: 1,
        Edit: 2,
        Delete: 3,
        Download: 4,
        Upload: 5,
        Archive: 6,
        Update: 7,
        Cancel: 8,
        Add: 9,
        SendEmail: 10,
        Impersonate:11
    };



    /// <summary>
    /// Kendo Util
    /// </summary>
    /// <returns type=""></returns>
    function KendoAjaxRequestStart() {
        /// <summary>
        /// Kendo Ajax Request Start
        /// </summary>
        if (Inforica.Ajax) {
            Inforica.Ajax.ShowGlobalProgress(false);
        }
    }

    function KendoAjaxRequestComplete() {
        /// <summary>
        /// Kendo Ajax Request Complete
        /// </summary>
        if (Inforica.Ajax) {
            Inforica.Ajax.ShowGlobalProgress(true);
        }
    }

    /// <summary>
    /// Inforica.KendoUtil library - A custom Jquery library to handle Kendo controls events.
    /// </summary>
    /// <method>IsUserInputValidForChangeOnKendoCombo</method>
    /// <method>ValidateInputForKendoCombo</method>
    /// <method>KendoGridErrorHandler</method>
    /// <method>HandleDblClickOnGrid</method>
    /// <method>AdjustDropdownContainerWidth</method>
    /// <method>DefaultDataBoundToAdjustContainerWidth</method>
    /// <method>SetFocusOnField</method>
    /// <method>OnEditorDropDownChange</method>
    /// <returns type=""></returns>
    function IsUserInputValidForChangeOnKendoCombo(combo) {
        /// <summary>
        /// Validates the input entered into the kendo comb box.
        /// </summary>
        /// <param name="combo"></param>
        /// <returns type=""></returns>
        Inforica.Logger.Log(ToString("IsUserInputValidForChangeOnKendoCombo"), " Validates the input entered into the kendo comb box.");
        try {
            var isValidSelection = true;
            var inputLength = combo.text().length;
            if (combo.select() < 0) {
                if (inputLength == 0) {
                    return true;
                }
                combo.value('');
                combo.text('');
                combo.search('');

                return false;
            }
            else if (combo.value() == '') {
                combo.select(function (dataItem) {
                    dataItem.Text === combo.text();
                });
            }

            if (combo.value() == "Select") {
                combo.value("");
            }

            return isValidSelection;
            Inforica.Logger.Log(ToString("IsUserInputValidForChangeOnKendoCombo"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("IsUserInputValidForChangeOnKendoCombo"), e.toString());
        }
    }

    function _GetUniqueID() {
        return moment().format("X");
    }

    function HandleWindowClose(containerKey) {
        Inforica.Logger.Log(ToString("HandleWindowClose"), "Executing default handler for container : " + containerKey + " and dialogResult : " + document.dialogResult);
        if (document.dialogResult == null || document.dialogResult == "CANCEL") {
            document.dialogResult = null;

            if (Inforica.App.IsMyContainerDirty(containerKey)) {
                Inforica.Logger.Log(ToString("HandleWindowClose"), "Container - " + containerKey + " - is dirty");
                var prompt = Inforica.App.PromptForDirtyFlag();
                if (!prompt) {
                    return false;
                }
                Inforica.App.CleanMyContainer(containerKey);
            }
        }
        else if (document.dialogResult == "OK") {
            Inforica.App.CleanMyContainer(containerKey);
        }
        return true;
    }

    function ShowWindow(title, content, height, width, onCloseCallback) {
        var windowUniqueID = _GetUniqueID();
        Inforica.Logger.Log(ToString("ShowWindow"), "Creating Window with handle : kendoWindowReference_" + windowUniqueID);
        /// <summary>
        /// Shows Kendo Window
        /// </summary>
        /// <param name="title"></param>
        /// <param name="content"></param>
        /// <param name="height"></param>
        /// <param name="width"></param>
        /// <returns type=""></returns>
        var kendoWindowReference = $("<div id='kendoWindowReference_" + windowUniqueID + "' />").appendTo(document.body);
        kendoWindowReference.kendoWindow({
            title: title,
            modal: true,
            width: width,
            height: height,
            resizable: false,
            actions: ["Maximize", "Close"],
            visible: false,
            deactivate: function () {
                this.destroy();
            },
            close: function (e) {
                if (onCloseCallback && !onCloseCallback()) {
                    e.preventDefault();
                    return false;
                }
                return true;
            }
        });
        kendoWindowReference.data("kendoWindow").content(content).center().open();
        return kendoWindowReference;
    }

    function ShowWindowWithoutActions(title, content, height, width, onCloseCallback) {
        var windowUniqueID = _GetUniqueID();
        Inforica.Logger.Log(ToString("ShowWindowWithoutActions"), "Creating Window with handle : kendoWindowReference_" + windowUniqueID);
        /// <summary>
        /// Shows Kendo Window
        /// </summary>
        /// <param name="title"></param>
        /// <param name="content"></param>
        /// <param name="height"></param>
        /// <param name="width"></param>
        /// <returns type=""></returns>
        var kendoWindowReference = $("<div id='kendoWindowReference_" + windowUniqueID + "' />").appendTo(document.body);
        kendoWindowReference.kendoWindow({
            title: title,
            modal: true,
            width: width,
            height: height,
            resizable: false,
            visible: false,
            actions: [],
            deactivate: function () {
                this.destroy();
            },
            close: function (e) {
                if (onCloseCallback && !onCloseCallback()) {
                    e.preventDefault();
                    return false;
                }
                return true;
            }
        });
        kendoWindowReference.data("kendoWindow").content(content).center().open();
        return kendoWindowReference;
    }


    function ValidateInputForKendoCombo(e) {
        /// <summary>
        /// Validates the input for Kendo Combo.
        /// </summary>
        /// <param name="e"></param>
        /// <returns type=""></returns>
        Inforica.Logger.Log(ToString("ValidateInputForKendoCombo"), "Validates the input for Kendo Combo.");
        try {
            var combo = e.sender;
            if (!IsUserInputValidForChangeOnKendoCombo(combo)) {
                e.preventDefault();
                return false;
            }
            return true;
            Inforica.Logger.Log(ToString("ValidateInputForKendoCombo"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("ValidateInputForKendoCombo"), e.toString());
        }
    }

    function KendoGridErrorHandler(e) {
        /// <summary>
        /// Handles the Kendo Grid Errors.
        /// </summary>
        /// <param name="e"></param>
        Inforica.Logger.Log(ToString("KendoGridErrorHandler"), "Handles the Kendo Grid Errors.");
        try {
            if (e.errors) {
                var message = "Errors:\n";
                $.each(e.errors, function (key, value) {
                    if ('errors' in value) {
                        $.each(value.errors, function () {
                            message += this + "\n";
                        });
                    }
                });
                alert(message);
            }
            Inforica.Logger.Log(ToString("KendoGridErrorHandler"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("KendoGridErrorHandler"), e.toString());
        }
    }

    function HandleDblClickOnGrid($gridElement, buttonClass) {
        /// <summary>
        /// Handles the Double Click on a grid element.
        /// </summary>
        /// <param name="$gridElement"></param>
        /// <param name="buttonClass"></param>
        Inforica.Logger.Log(ToString("HandleDblClickOnGrid"), "Handles the Double Click on a grid element.");
        try {
            $gridElement.delegate("tbody>tr", "dblclick", function () {
                $(this).find(buttonClass).click();
            });
            Inforica.Logger.Log(ToString("HandleDblClickOnGrid"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("HandleDblClickOnGrid"), e.toString());
        }
    }

    function AdjustDropdownContainerWidth(combo, width) {
        /// <summary>
        /// Adjusts the Dropdown List Containers width given by user.
        /// </summary>
        /// Default width is 250
        /// <param name="combo"></param>
        /// <param name="width"></param>
        Inforica.Logger.Log(ToString("AdjustDropdownContainerWidth"), "Adjusts the Dropdown List Containers width.");
        try {
            if (combo != null) {
                if (typeof (width) != "undefined" && width != null) {
                    combo.list.width(width);
                }
                else {
                    combo.list.width(250);
                }
            }
            Inforica.Logger.Log(ToString("AdjustDropdownContainerWidth"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("AdjustDropdownContainerWidth"), e.toString());
        }
    }

    function DefaultDataBoundToAdjustContainerWidth(e) {
        /// <summary>
        /// Adjusts the Dropdown List Containers width to 250 by default.
        /// </summary>
        /// <param name="e"></param>
        this.AdjustDropdownContainerWidth(e.sender, 250);
    }

    function OnEditorDropDownChange(e) {
        /// <summary>
        /// Handles the editor dropdown change.
        /// </summary>
        /// <param name="e"></param>
        Inforica.Logger.Log(ToString("OnEditorDropDownChange"), "Handles the editor dropdown change.");
        try {
            var combo = e.sender;
            if (!IsUserInputValidForChangeOnKendoCombo(combo)) {
                e.preventDefault();
            }

            //get the edited field name
            var fieldName = combo.element.attr("id");
            //find the closest row
            var currentRow = combo.wrapper.closest("tr");
            //find the grid
            var grid = combo.wrapper.closest(".k-grid").data("kendoGrid");
            //get the current row dataItem
            var currentDataItem = grid.dataItem(currentRow);
            //manually set the current value of the DropDownList to the field
            var val = combo.value();

            if (isNaN(val)) {
                currentDataItem.set(fieldName, val);
            }
            else {
                currentDataItem.set(fieldName, parseInt(val));
            }
            Inforica.Logger.Log(ToString("OnEditorDropDownChange"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("OnEditorDropDownChange"), e.toString());
        }
    }

    function SetFocusOnField(combo, form) {
        /// <summary>
        /// Sets the cursor focus on given combo.
        /// </summary>
        /// <param name="combo"></param>
        /// <param name="form"></param>
        Inforica.Logger.Log(ToString("SetFocusOnField"), "Sets the cursor focus on given combo.");
        try {
            var comboChild = $("#" + combo).data("kendoComboBox");
            var comboChildInputField = $('input[name= "' + combo + '_input"]');
            if (form != null) {
                comboChild = form.find("#" + combo).data("kendoComboBox");
                comboChildInputField = form.find('input[name= "' + combo + '_input"]');
            }
            if (comboChild != null && comboChild.focus) {
                comboChild.focus();
            }
            else {
                Inforica.Logger.Log("Combobox is not ready yet!");
            }
            comboChildInputField.focus();
            comboChildInputField.select();
            Inforica.Logger.Log(ToString("SetFocusOnField"), "Success.");
        }
        catch (e) {
            Inforica.Logger.Log(ToString("SetFocusOnField"), e.toString());
        }
    }

    function SetIconAndToolTipOnGridAction(tooltipType, $element) {
        /// <summary>
        /// Set icon and initialize the kendo tooltip.
        /// </summary>
        /// <param name="tooltipType">Tooltip type enumeration - Eg: Search, View, Edit, Delete, Download, Upload, etc.</param>
        /// <param name="$element">Jquery object</param>

        switch (tooltipType) {

            case tooltipConstants.Search:
            case tooltipConstants.View:
                $element.html("<span class='fa fa-search'/>").kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
            case tooltipConstants.Edit:
                $element.html("<span class='fa fa-edit'/>").kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
            case tooltipConstants.Delete:
                $element.html("<span class='fa fa-trash-o'/>").kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
            case tooltipConstants.Download:
                $element.html("<span class='fa fa-download'/>").kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
            case tooltipConstants.Upload:
                $element.html("<span class='fa fa-upload'/>").kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
            case tooltipConstants.Archive:
                $element.html("<span class='fa fa-archive'/>").kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
            case tooltipConstants.Update:
                $element.html("<span class='fa fa-check'/>").kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
            case tooltipConstants.Cancel:
                $element.html("<span class='fa fa-times'/>").kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
            case tooltipConstants.Add:
                $element.kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
            case tooltipConstants.SendEmail:
                $element.html("<span class='fa fa-envelope-o'/>").kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
            case tooltipConstants.Impersonate:
                $element.html("<span class='fa fa-users'/>").kendoTooltip({
                    position: "top"
                }).data("kendoTooltip");
                break;
                
        }

    }

    function Tooltip($element) {
        /// <summary>
        /// Initialize the tooltip plugin
        /// </summary>
        /// <param name="$element">Jquery object</param>
        $element.kendoTooltip({
            position: "top"
        }).data("kendoTooltip");
    }

    function SetGridHeight() {
        /// <summary>
        /// Sets the Kendo Grid Height equals to the page height.
        /// </summary>
        var gridContentHeight = Inforica.UI.GetWindowHeight() - (
                                        $("#menu-horizontal").height() +
                                        $(".k-grid-header").height() +
                                        $(".k-grid-bottom").height() +
                                        $(".footer").height() +
                                        $(".ui-tabs .ui-tabs-nav").height() +
                                        $(".page-bar").height() +
                                        $(".page-title").height() +
                                        250
                                        );
        $(".k-grid-content").css("height", gridContentHeight + "px");
    }

    function ToString(methodName) {
        /// <summary>
        /// Gives the Class Name appended before the method name.
        /// </summary>
        /// <param name="methodName"></param>
        /// <returns type=""></returns>
        return "Inforica.KendoUtil." + methodName + " ";
    }

    function KendoDatePicker_StartDateChange(fromDatePickerId, toDatePickerId) {
        /// <summary>
        /// Function to handle change of KendoDatePicker representing the startdate to select a period.
        /// </summary>
        /// <param name="fromDatePickerId">Identifier for the start date picker</param>
        /// <param name="toDatePickerId">Identifier for the end date picker</param>
        var endPicker = $("#" + toDatePickerId).data("kendoDatePicker"),
            startDate = $("#" + fromDatePickerId).data("kendoDatePicker").value();

        if (startDate) {
            startDate = new Date(startDate);
            startDate.setDate(startDate.getDate() + 1);
            endPicker.min(startDate);
        }
    }

    function KendoDatePicker_EndDateChange(fromDatePickerId, toDatePickerId) {
        /// <summary>
        /// Function to handle change of KendoDatePicker representing the enddate to select a period.
        /// </summary>
        /// <param name="fromDatePickerId">Identifier for the start date picker</param>
        /// <param name="toDatePickerId">Identifier for the end date picker</param>
        var startPicker = $("#" + fromDatePickerId).data("kendoDatePicker"),
            endDate = $("#" + toDatePickerId).data("kendoDatePicker").value();

        if (endDate) {
            endDate = new Date(endDate);
            endDate.setDate(endDate.getDate() - 1);
            startPicker.max(endDate);
        }
    }

    function DateTimeFilter(control) {
        /// <summary>
        /// Function to add datetime picker for the specified control
        /// </summary>
        /// <param name="control"></param>
        $(control).kendoDateTimePicker();
    }

    function ClearAllTooltips() {
        Inforica.Logger.Log(ToString("ClearAllTooltips"), "Clearing all tooltips");
        $('div[role="tooltip"]').each(function () {
            var that = $(this);
            var tooltipContainer = that.parents(".k-animation-container");
            //tooltipContainer.remove();
            tooltipContainer.css("display", "none");
            tooltipContainer.css("overflow", "hidden");
            Inforica.Logger.Log(ToString("ClearAllTooltips"), "Removed tooltip");

        });
    }

    function StateProvinceRelatedToCountry(countryComboID, stateComboID) {
        Inforica.Logger.Log(ToString("StateProvinceRelatedToCountry"), "Getting the states for the country");
        var combo = $("#" + countryComboID).data('kendoComboBox');
        var comboChild = $("#" + stateComboID).data("kendoComboBox");

        if (!IsUserInputValidForChangeOnKendoCombo(combo)) {
            comboChild.select(0);
            comboChild.setDataSource([]);
            SetFocusOnField(countryComboID);
            return false;
        }
        else {
            if (combo.value() != '' && combo.value() != null) {
                Inforica.Logger.Log(ToString("StateProvinceRelatedToCountry"), "Getting the states for the country id " + combo.value());
                var postData = [];
                postData.push({ name: "countryId", value: combo.value() });
                Inforica.Ajax.Post("StateProvinceRelatedToCountry", "ReferenceData", "", postData,
                     function (msg) {
                         comboChild.setDataSource(msg);
                         comboChild.select(0);
                         SetFocusOnField(stateComboID);
                     });
            }
            else {
                comboChild.select(0);
                comboChild.setDataSource([]);
                SetFocusOnField(countryComboID);
            }
        }
    }

    function TriggerComboBoxChange(comboBoxID) {
        var combo = $("#" + comboBoxID).data('kendoComboBox');
        combo.trigger("change");
    }

    return {
        TooltipConstants: tooltipConstants,
        IsUserInputValidForChangeOnKendoCombo: IsUserInputValidForChangeOnKendoCombo,
        ValidateInputForKendoCombo: ValidateInputForKendoCombo,
        KendoGridErrorHandler: KendoGridErrorHandler,
        HandleDblClickOnGrid: HandleDblClickOnGrid,
        AdjustDropdownContainerWidth: AdjustDropdownContainerWidth,
        DefaultDataBoundToAdjustContainerWidth: DefaultDataBoundToAdjustContainerWidth,
        SetFocusOnField: SetFocusOnField,
        OnEditorDropDownChange: OnEditorDropDownChange,
        KendoAjaxRequestStart: KendoAjaxRequestStart,
        KendoAjaxRequestComplete: KendoAjaxRequestComplete,
        SetIconAndToolTipOnGridAction: SetIconAndToolTipOnGridAction,
        Tooltip: Tooltip,
        SetGridHeight: SetGridHeight,
        KendoDatePicker_StartDateChange: KendoDatePicker_StartDateChange,
        KendoDatePicker_EndDateChange: KendoDatePicker_EndDateChange,
        ShowWindow: ShowWindow,
        DateTimeFilter: DateTimeFilter,
        ClearAllTooltips: ClearAllTooltips,
        StateProvinceRelatedToCountry: StateProvinceRelatedToCountry,
        TriggerComboBoxChange: TriggerComboBoxChange,
        HandleWindowClose: HandleWindowClose,
        ShowWindowWithoutActions: ShowWindowWithoutActions
    };
};