﻿$(function () {
    if ($.connection != undefined) {
        $.connection.hub.start().done(function () {
            console.log("Hub Started");
        });

        $.connection.hub.logging = true;

        // Retrieve Hub Reference
        hub = $.connection.notificationHub;

        //Broad Cast Call Back Function
        hub.client.processBroadcastCallBack = function (message) {
            ShowNotifications(message);
        };
        hub.client.processBroadcastCallBackSuccess = function (message) {
            ShowNotifications(message);
        };


        //Error Call Back when User is not online or invalid user
        hub.client.showErrorMessageCallBack = function (message) {
            ShowNotifications(message);
        };

        //Send Message Call Back funtion
        hub.client.sendMessageCallBack = function (message, autoCloseDelay) {
            ShowNotifications(message, autoCloseDelay);
        };

        hub.client.sendMessageCallBackSuccess = function (message) {
            ShowNotifications(message);
        };


        $.connection.hub.disconnected(function () {

        });
    }

});

//Server Broad Cast
function ServerBroadCastMessage(message) {
    hub.server.broadcast(message);
}

function ServerSendMessage(whom, message) {
    hub.server.sendMessage(whom, message).done(function (response) {

    });
}

function ShowNotifications(message) {
    Inforica.NotificationUtil.ShowToasterNotification("info", message, "Wellness");
}




