﻿/**
 * Project: Inforica - Ajax Library
 * Author: Sanghi Krishna Kanhiya
 * Contributors: Kiran Banda
 *
 * Dependencies: JQuery, JQuery Validation Engine
 *
 * Jquery Validation Engine Wrapper
 *
 * License: Inforica India Private Limited
 *
 */

Inforica.ValidationEngine = new function () {
    /// <summary>
    /// Inforica.ValidationEngine Library- A custom Jquery library for Jquery Validation Engine Wrapper
    /// </summary>
    /// <returns type=""></returns>
    function Initialize(formID) {
        /// <summary>
        /// Initializing validation engine for give form ID
        /// </summary>
        /// <param name="formID"></param>
        Inforica.Logger.Log(ToString("Initialize"), "Initializing validation engine for give form ID " + formID);
        try {
            var $form = $('#' + formID);
            $form.validationEngine();

            $form.bind("jqv.field.result", function (event, field, errorFound, prompText) {
                var formGroup = field.parents(".form-group");
                if (errorFound) {
                    formGroup.addClass("has-error");
                    $("span.help-block", formGroup).last().remove();
                    formGroup.append('<span class="help-block">' + prompText + '</span>');
                }
                else {
                    formGroup.removeClass("has-error");
                    $("span.help-block", formGroup).last().remove();
                }
            });

            Inforica.Logger.Log(ToString("Initialize"), "Initialized");

        } catch (e) {
            Inforica.Logger.Log(ToString("Initialize"), e.toString());
        }
    }


    function ValidateKendoComboBoxes(formID) {
        /// <summary>
        /// Validate Kendo Combo Boxes
        /// </summary>
        /// <param name="formID"></param>
        /// <returns type=""></returns>
        var $form = $("#" + formID);
        var isValid = true;
        //Validate KendoComboBoxes dynamically.
        $form.find('span.required input:text').each(function () {

            var that = $(this);
            if (that.css("visibility") != "hidden" && that.css("display") != undefined && that.css("display") != "none") {

                var val = that.val();
                if ($.trim(val).length == 0 || $.trim(val) == "Select") {
                    ShowValidationMessage(that, "Please select a value.");
                    isValid = false;
                } else {
                    HideValidationMessage(that);
                }
            }
        });

        //Check to see if we have to deal with a kendo multi-select.
        $form.find('div.required input:text').each(function () {
            
            var that = $(this);
            if (that.css("visibility") != "hidden" && that.css("display") != undefined && that.css("display") != "none") {

                if (that.attr("role") == "listbox") {

                    var $selectedValueList = that.parent().find("ul > li");
                    if ($selectedValueList.length == 0) {
                        ShowValidationMessage(that, "Please select a value.");
                        isValid = false;
                    } else {
                        HideValidationMessage(that);
                    }
                }
            }
        });


        return isValid;
    }
    function IsFormValid(formID) {
        /// <summary>
        /// Validating form for give form ID
        /// </summary>
        /// <param name="formID"></param>
        /// <returns type=""></returns>
        Inforica.Logger.Log(ToString("IsFormValid"), "Validating form for give form ID " + formID);
        try {
            var isFormValid = true;
            if ($('#' + formID).validationEngine("validate") == false) {
                Inforica.Logger.Log(ToString("IsFormValid"), "Invalid Form");
                isFormValid = false;
            }

            if (!ValidateKendoComboBoxes(formID)) {
                isFormValid = false;
            }
            Inforica.Logger.Log(ToString("IsFormValid"), "Valid Form - " + isFormValid);
            return isFormValid;
        } catch (e) {
            Inforica.Logger.Log(ToString("IsFormValid"), e.toString());
            return false;
        }

    }

    function IsElementValid(elementID) {
        /// <summary>
        /// Validate Element for given ID
        /// </summary>
        /// <param name="elementID"></param>
        /// <returns type=""></returns>
        Inforica.Logger.Log(ToString("IsElementValid") + "Validating Element for given ID " + elementID);
        try {

        } catch (e) {
            Inforica.Logger.Log(ToString("IsElementValid"), e.toString());
            return false;
        }
        Inforica.Logger.Log(ToString("IsElementValid"), "Valid Element");
        return true;
    }

    function ShowValidationMessage($element, message) {
        /// <summary>
        /// Presents the validation message for the given element (a jquery selector)
        /// </summary>
        /// <param name="$element">Jquery object using a selector</param>
        /// <param name="message">Validation message</param>
        Inforica.Logger.Log(ToString("ShowValidationMessage") + "Showing Error Message for given ID " + $element.attr("id"));
        try {

            var formGroup = $element.parents(".form-group");

            formGroup.addClass("has-error");
            $("span.help-block", formGroup).last().remove();
            formGroup.append('<span class="help-block">' + message + '</span>');


        } catch (e) {
            Inforica.Logger.Log(ToString("ShowValidationMessage"), e.toString());
        }
    }

    function HideValidationMessage($element) {
        /// <summary>
        /// Hide Error Message for given ID 
        /// </summary>
        /// <param name="elementID"></param>
        Inforica.Logger.Log(ToString("HideValidationMessage"), "Hide Error Message for given ID " + $element.attr("id"));
        try {
            var formGroup = $element.parents(".form-group");
            formGroup.removeClass("has-error");
            $("span.help-block", formGroup).last().remove();

        } catch (e) {
            Inforica.Logger.Log(ToString("HideValidationMessage"), e.toString());
        }
    }

    function ToString(methodName) {
        return "Inforica.ValidationEngine." + methodName + " ";
    }

    return {
        Initialize: Initialize,
        IsFormValid: IsFormValid,
        IsElementValid: IsElementValid,
        ShowValidationMessage: ShowValidationMessage,
        HideValidationMessage: HideValidationMessage
    };
};