﻿using Microsoft.Practices.ServiceLocation;
using Repository.Pattern.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Mvc;
using Wellness.Areas.HRA;
using Wellness.Common;
using Wellness.Entities.ComplexModels;
using Wellness.Entities.CustomModels;
using Wellness.Entities.Models;
using Wellness.Services.Contracts;

namespace Wellness.Controllers {
    public class HRAController : BaseController {

        private readonly IHRAService _hraService;
        public IUsersService UserSrv;
        public IDietActivityService DASrv;

        public HRAController(IHRAService hraService, IUsersService userSrv, IDietActivityService daSrv) {
            _hraService = hraService;
            UserSrv = userSrv;
            DASrv = daSrv;
        }

        Data.Context.SEBWellnessContext db = new Data.Context.SEBWellnessContext();
        Wellness.Entities.CustomModels.HRAQuestionnaire HRA = new Wellness.Entities.CustomModels.HRAQuestionnaire();

        SqlDataAdapter daRiskReport = new SqlDataAdapter();
        SqlDataAdapter daRiskReportDetail = new SqlDataAdapter();
        SqlDataAdapter daReportSection = new SqlDataAdapter();
        SqlDataAdapter daQuestion = new SqlDataAdapter();
        SqlDataAdapter daAnswer = new SqlDataAdapter();
        SqlDataAdapter daLastQuestion = new SqlDataAdapter();
        SqlDataAdapter daLastSection = new SqlDataAdapter();
        SqlDataAdapter daUser = new SqlDataAdapter();
        SqlDataAdapter daUserInfo = new SqlDataAdapter();

        DataTable tblRiskReport = new DataTable("hra_risk_report");
        DataTable tblRiskReportDetail = new DataTable("hra_risk_report_detail");
        DataTable tblQuestion = new DataTable("hra_question");
        DataTable tblAnswer = new DataTable("hra_answer");
        DataTable tblUser = new DataTable("user");
        DataTable tblUserInfo = new DataTable("user_info");

        DataRow rowRiskReport;
        DataRow rowRiskReportDetail;
        DataRow rowUser;
        DataRow rowUserInfo;

        SqlCommandBuilder cbRiskReport;
        SqlCommandBuilder cbRiskReportDetail;

        SqlConnection cn;

        string strSQL;
        string dbConnectionString;

        int intReportNum;
        //int intStartingSectionNum;

        const int WEIGHT_QUESTION_NUM = 277;
        const int WAIST_QUESTION_NUM = 278;

        HRAUser CurrentUser;

        // GET: HRA/HRA
        public ActionResult Index(string latestHRADate) {
            ViewBag.LatestReportDate = latestHRADate;

            GetUserProfile(base.MembershipUserID);

            var questions = from q in db.hra_question
                            where (q.gender == CurrentUser.Gender || q.gender == "U")
                            && q.active == true
                            && q.age_min <= CurrentUser.Age
                            && q.age_max >= CurrentUser.Age
                            select q;

            var answers = from a in db.hra_answer
                          where questions.Any(q => q.question_num == a.question_num)
                          select a;

            var groups = from g in db.hra_question_group
                         where questions.Any(q => q.question_group_num == g.question_group_num)
                         select g;

            var sections = from s in db.hra_report_section
                           where questions.Any(q => q.active == true && q.report_section_num == s.report_section_num)
                           select s;

            HRA.Questions = questions.ToList();
            HRA.Answers = answers.ToList();
            HRA.QuestionGroups = groups.ToList();
            HRA.ReportSections = sections.OrderBy(m => m.sort_order).ToList();
            HRA.Settings = db.hra_setting.FirstOrDefault();
            HRA.Weights = new List<string>();
            HRA.Waists = new List<string>();
            HRA.QuestionSuppressed = db.hra_question_suppress.ToList();

            HRA.Weights.Add("Please select");
            for (int i = HRA.Settings.weight_min; i <= HRA.Settings.weight_max; i++) {
                HRA.Weights.Add(i.ToString());
            }

            HRA.Waists.Add("Please select");
            for (int i = HRA.Settings.waist_min; i <= HRA.Settings.waist_max; i++) {
                HRA.Waists.Add(i.ToString());
            }

            intReportNum = GetRiskReport(false);
            HRA.StartingSectionNum = GetLastReportSection(intReportNum);

            //fetch any existing responses from a previously started HRA by the user
            var responses = from r in db.hra_risk_report_detail
                            where (r.risk_report_num == intReportNum)
                            select r;
            HRA.RiskReportDetails = responses.ToList();

            ViewBag.CurrentUser = CurrentUser;

            return View("Index", HRA);
        }

        public JsonResult EvaluateRiskReport() {
            GetUserProfile(base.MembershipUserID);

            dbConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SEBWellness"].ConnectionString;
            cn = new SqlConnection(dbConnectionString);
            cn.Open();

            if (cn.State == System.Data.ConnectionState.Open) {
                //get user's latest non-completed HRA
                intReportNum = GetRiskReport(false);

                HRAEvaluation HRA = new HRAEvaluation(intReportNum);
                HRA.GenerateFeedback();

                cn.Close();
            }

            //Adding Points to User for taking HRA
            AddUserRewardPoints(UserSrv, (int)EntityTypes.HraRiskReport, intReportNum, StringConstants.TAKING_HRA, (int)RewardPointTypes.MWHealthRiskAssessment);

            return Json(intReportNum);
        }

        public JsonResult SaveResponses(HRAResponse[] Responses) {
            GetUserProfile(base.MembershipUserID);

            dbConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SEBWellness"].ConnectionString;
            cn = new SqlConnection(dbConnectionString);
            cn.Open();

            if (cn.State == System.Data.ConnectionState.Open) {
                //get user's latest non-completed HRA
                intReportNum = GetRiskReport(true);

                SaveSectionAnswers(Responses);

                cn.Close();
            }

            return null;
        }

        protected int GetRiskReport(bool CreateNew) {
            int intNewReportNum;

            //find latest non-completed risk report for user, if any
            strSQL = @" select      risk_report_num,
                                    user_id,
                                    bmi,
                                    dietary_score,
                                    waist,
                                    weight,
                                    mhrs_score,
                                    bio_age,
                                    completed,
                                    IsSyncRequired,
                                    LastSyncedDate,
                                    show_welcome_msg,
                                    IsDeleted,
                                    create_date
                        from        hra_risk_report 
                        where       user_id = '" + CurrentUser.ID + @"'
                        and         completed = 0 
                        order by    risk_report_num desc";
            daRiskReport = new SqlDataAdapter(strSQL, cn);
            tblRiskReport.Clear();
            daRiskReport.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReport.Fill(tblRiskReport);

            if (tblRiskReport == null || tblRiskReport.Rows.Count == 0) {
                if (CreateNew == true) {
                    intNewReportNum = CreateNewReport();
                }
                else {
                    intNewReportNum = 0;
                }
            }
            else {
                intNewReportNum = (int)tblRiskReport.Rows[0]["risk_report_num"];
            }

            return intNewReportNum;
        }

        protected int GetLastReportSection(int ReportNum) {
            DataTable tblLastQuestion = new DataTable();
            DataTable tblLastSection = new DataTable();
            object[] objPK2 = new object[2];
            int intLastSectionNum = 0;

            //get last section completed by user
            strSQL = @" select  risk_report_num,
                                question_num
                        from    hra_risk_report_detail
                        where   risk_report_num = " + ReportNum.ToString();
            daLastQuestion = new SqlDataAdapter(strSQL, cn);
            tblLastQuestion.Clear();
            daLastQuestion.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daLastQuestion.Fill(tblLastQuestion);

            if (tblLastQuestion.Rows.Count == 0) {
                intLastSectionNum = 0;
            }
            else {
                foreach (hra_question rowQuestion in HRA.Questions) {
                    objPK2[0] = ReportNum;
                    objPK2[1] = rowQuestion.question_num;

                    if (tblLastQuestion.Rows.Find(objPK2) == null) {
                        foreach (hra_report_section rowSection in HRA.ReportSections) {
                            if ((int)rowSection.report_section_num == rowQuestion.report_section_num) {
                                break;
                            }

                            intLastSectionNum += 1;
                        }

                        break;
                    }
                }
            }

            return intLastSectionNum;
        }

        protected int CreateNewReport() {
            int intNewReportNum;

            strSQL = @" select  risk_report_num,
                                user_id,
                                bmi,
                                dietary_score,
                                waist,
                                weight,
                                mhrs_score,
                                bio_age,
                                completed,
                                IsSyncRequired,
                                LastSyncedDate,
                                show_welcome_msg,
                                IsDeleted,
                                create_date
                        from    hra_risk_report
                        where   risk_report_num = 0";
            daRiskReport = new SqlDataAdapter(strSQL, cn);
            cbRiskReport = new SqlCommandBuilder(daRiskReport);
            tblRiskReport.Clear();
            daRiskReport.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReport.Fill(tblRiskReport);

            rowRiskReport = tblRiskReport.NewRow();
            rowRiskReport["user_id"] = CurrentUser.ID;
            rowRiskReport["bmi"] = 0;
            rowRiskReport["dietary_score"] = 0;
            rowRiskReport["mhrs_score"] = 100;
            rowRiskReport["waist"] = 0;
            rowRiskReport["weight"] = 0;
            rowRiskReport["bio_age"] = 0;
            rowRiskReport["completed"] = false;
            rowRiskReport["create_date"] = DateTime.UtcNow;
            tblRiskReport.Rows.Add(rowRiskReport);
            daRiskReport.Update(tblRiskReport);

            SqlCommand cmdPK = new SqlCommand("select @@identity", cn);

            intNewReportNum = Convert.ToInt32(cmdPK.ExecuteScalar());

            daRiskReport.Dispose();

            return intNewReportNum;
        }

        protected void SaveBodyMetrics(int QuestionNum, int Answer) {
            strSQL = @" select  risk_report_num,
                                user_id,
                                bmi,
                                dietary_score,
                                waist,
                                weight,
                                mhrs_score,
                                bio_age,
                                completed,
                                IsSyncRequired,
                                LastSyncedDate,
                                show_welcome_msg,
                                IsDeleted,
                                create_date
                        from    hra_risk_report
                        where   risk_report_num = " + intReportNum.ToString();
            daRiskReport = new SqlDataAdapter(strSQL, cn);
            cbRiskReport = new SqlCommandBuilder(daRiskReport);
            tblRiskReport.Clear();
            daRiskReport.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daRiskReport.Fill(tblRiskReport);

            switch (QuestionNum) {
                case WEIGHT_QUESTION_NUM:
                    if (tblRiskReport.Rows.Count > 0) {
                        tblRiskReport.Rows[0]["weight"] = Answer;
                        daRiskReport.Update(tblRiskReport);
                    }

                    break;
                case WAIST_QUESTION_NUM:
                    if (tblRiskReport.Rows.Count > 0) {
                        tblRiskReport.Rows[0]["waist"] = Answer;
                        daRiskReport.Update(tblRiskReport);
                    }

                    break;
            }
        }

        protected void SaveSectionAnswers(HRAResponse[] Response) {
            if (Response != null) {
                int intQuestionNum;
                int intAnswerNum;
                object[] objPK2 = new object[2];
                bool bolNewQuestion = false;
                bool bolUpdated = false;

                strSQL = @" select  risk_report_num,
                                    question_num,
                                    answer_num,
                                    create_date
                            from    hra_risk_report_detail
                            where   risk_report_num = " + intReportNum;
                daRiskReportDetail = new SqlDataAdapter(strSQL, cn);
                cbRiskReportDetail = new SqlCommandBuilder(daRiskReportDetail);
                tblRiskReportDetail.Clear();
                daRiskReportDetail.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                daRiskReportDetail.Fill(tblRiskReportDetail);

                for (int i = 0; i < Response.Length; i++) {
                    bolNewQuestion = false;
                    intQuestionNum = Response[i].QuestionNum;
                    intAnswerNum = Response[i].AnswerNum;

                    //attempt to find existing answer
                    objPK2[0] = intReportNum;
                    objPK2[1] = intQuestionNum;
                    rowRiskReportDetail = tblRiskReportDetail.Rows.Find(objPK2);

                    if (rowRiskReportDetail == null) {
                        bolNewQuestion = true;
                        rowRiskReportDetail = tblRiskReportDetail.NewRow();
                        rowRiskReportDetail["risk_report_num"] = intReportNum;
                        rowRiskReportDetail["question_num"] = intQuestionNum;
                        rowRiskReportDetail["create_date"] = DateTime.Now;
                    }

                    rowRiskReportDetail["answer_num"] = intAnswerNum;

                    if (bolNewQuestion == true) {
                        tblRiskReportDetail.Rows.Add(rowRiskReportDetail);
                    }

                    //update weight & waist on risk report
                    if (intQuestionNum == WEIGHT_QUESTION_NUM || intQuestionNum == WAIST_QUESTION_NUM) {
                        SaveBodyMetrics(intQuestionNum, intAnswerNum);
                    }

                    bolUpdated = true;
                }

                if (bolUpdated == true) {
                    daRiskReportDetail.Update(tblRiskReportDetail);
                    daRiskReportDetail.Dispose();
                }
            }
        }

        private void GetUserProfile(string UserId) {
            CurrentUser = new HRAUser();
            CurrentUser.ID = UserId;

            dbConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SEBWellness"].ConnectionString;
            cn = new SqlConnection(dbConnectionString);
            cn.Open();

            if (cn.State == System.Data.ConnectionState.Open) {
                if (UserId == null || UserId == "") {
                    return;
                }

                strSQL = @" select  Id,
                                    LastLogin,
                                    FirstName,
                                    LastName,
                                    Email,
                                    EmailConfirmed,
                                    PasswordHash,
                                    SecurityStamp,
                                    PhoneNumber,
                                    TwoFactorEnabled,
                                    LockoutEndDateUtc,
                                    LockoutEnabled,
                                    AccessFailedCount,
                                    UserName
                            from    AspNetUsers 
                            where   Id = '" + UserId + "'";

                daUser = new SqlDataAdapter(strSQL, cn);
                tblUser.Clear();
                daUser.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                daUser.Fill(tblUser);

                if (tblUser.Rows.Count > 0) {
                    rowUser = tblUser.Rows[0];

                    CurrentUser.ID = UserId;
                    CurrentUser.FirstName = rowUser["FirstName"].ToString();
                    CurrentUser.Surname = rowUser["LastName"].ToString();
                }

                daUser.Dispose();

                strSQL = @" select  ASPNetUserId,
                                    DateOfBirth,
                                    Height,
                                    Gender,
                                    ProfileImage,
                                    RegistrationDate
                            from    AspNetUsersInfo 
                            where   ASPNetUserId = '" + UserId + "'";

                daUserInfo = new SqlDataAdapter(strSQL, cn);
                tblUserInfo.Clear();
                daUserInfo.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                daUserInfo.Fill(tblUserInfo);

                if (tblUserInfo.Rows.Count > 0) {
                    rowUserInfo = tblUserInfo.Rows[0];

                    CurrentUser.Gender = rowUserInfo["Gender"].ToString();
                    CurrentUser.DOB = (DateTime)rowUserInfo["DateOfBirth"];
                    CurrentUser.Height = (int)rowUserInfo["Height"];
                }

                daUserInfo.Dispose();

                cn.Close();
            }
        }

        public ActionResult GetPotentialHealthIssuesByRiskReportId(int riskReportNumber) {
            List<PotentialHealthIssues> recHealthIssues = _hraService.GetRecommendedActivitiesByGoalId(ServiceLocator.Current.GetInstance<IRepositoryAsync<PotentialHealthIssues>>(), riskReportNumber);
            return Json(recHealthIssues, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetIdentifiedConditions(int RiskReportNum) {
            List<IdentifiedConditions> UserConditions = _hraService.GetConditionsByRiskReportNum(ServiceLocator.Current.GetInstance<IRepositoryAsync<IdentifiedConditions>>(), RiskReportNum);
            return Json(UserConditions, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetIdentifiedConditionsWithEmail(int RiskReportNum) {
            List<IdentifiedConditions> UserConditions = _hraService.GetConditionsWithEmailByRiskReportNum(ServiceLocator.Current.GetInstance<IRepositoryAsync<IdentifiedConditions>>(), RiskReportNum);
            return Json(UserConditions, JsonRequestBehavior.AllowGet);
        }

        public void ConfirmConsentViaEmail(int UserID) {
            int ReportNum;

            //get latest risk report for user


            ReportNum = 0;

            ConfirmConsent(ReportNum);
        }

        public JsonResult ConfirmConsent(int riskReportNumber) {
            dbConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SEBWellness"].ConnectionString;
            cn = new SqlConnection(dbConnectionString);
            cn.Open();

            if (cn.State == System.Data.ConnectionState.Open) {
                strSQL = @" select  risk_report_num,
                                    completed,
                                    IsSyncRequired,
                                    LastSyncedDate,
                                    create_date
                            from    hra_risk_report
                            where   risk_report_num = " + riskReportNumber.ToString();
                daRiskReport = new SqlDataAdapter(strSQL, cn);
                cbRiskReport = new SqlCommandBuilder(daRiskReport);
                tblRiskReport.Clear();
                daRiskReport.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                daRiskReport.Fill(tblRiskReport);

                if (tblRiskReport != null && tblRiskReport.Rows.Count > 0) {
                    tblRiskReport.Rows[0]["IsSyncRequired"] = true;
                    daRiskReport.Update(tblRiskReport);
                }

                cn.Close();
            }

            _hraService.emailsOpted(riskReportNumber);
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }
    }
}
