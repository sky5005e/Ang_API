﻿using Kendo.Mvc.UI;
using Microsoft.Practices.ServiceLocation;
using Microsoft.AspNet.Identity;
using Repository.Pattern.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using Wellness.ActionFilters;
using Wellness.Common;
using Wellness.Controllers;
using Wellness.Entities.ComplexModels;
using Wellness.Entities.Models;
using Wellness.Models;
using Wellness.Services.Contracts;
using Wellness.Entities.CustomModels;
using System.Web;
using System.IO;
using System.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Storage.Blob;
using System.Net.Http;
using System.Text;
using Wellness.Extensions;
using Wellness.Services.Common;
using System.Data;

namespace Wellness.Areas.ContentManagement.Controllers
{
    //[Authorize(Roles = ApplicationRole.ADMIN)]
    public class ContentManagementController : BaseController
    {

        #region Private Members
        private readonly IContentManagementService _contentManagementService;
        public IWalletService _walletSrv;
        public IUsersService _userService;
        public ICompanyService _companyService;
        public INotificationService _notificationService;
        public IDietActivityService _dietActivityService;
        private readonly IExcelService _excelService;
        #endregion

        #region Constructor
        public ContentManagementController(
            IContentManagementService contentManagementService,
            IWalletService walletService,
            IUsersService userService,
            ICompanyService companyService,
            INotificationService notificationService,
            IDietActivityService dietActivityService,
            IExcelService excelService)
        {
            _contentManagementService = contentManagementService;
            _walletSrv = walletService;
            _userService = userService;
            _companyService = companyService;
            _notificationService = notificationService;
            _excelService = excelService;
            _dietActivityService = dietActivityService;
        }
        #endregion

        //
        // GET: /ContentManagement/ContentManagement/
        public ActionResult Index()
        {
            return View();
        }

        #region Feedback Age
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        public ActionResult FeedbackAge()
        {
            return View();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult FeedbackAgeGB([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "Date";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new FeedBackAgeParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                userId = MembershipUserID
            };

            List<FeedBackAge> list = _contentManagementService.GetFeedbackAge(ServiceLocator.Current.GetInstance<IRepositoryAsync<FeedBackAge>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditFeedbackAge(int feedBackAgeNumber)
        {
            hra_feedback_age feedBackAge = _contentManagementService.GetFeedbackAgeByNumber(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_age>>(), feedBackAgeNumber);
            return View("FeedbackAgeEditor", feedBackAge);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult UpdateFeedbackAge(int feedBackAgeNumber, string mainFeedback, string summaryFeedBack, string mainFeedbackFrench, string summaryFeedBackFrench)
        {
            _contentManagementService.UpdateFeedbackAge(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_age>>(), feedBackAgeNumber, mainFeedback, summaryFeedBack, mainFeedbackFrench, summaryFeedBackFrench);
            return Json("Success");
        }

        #endregion

        #region Feedback Cluster
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        public ActionResult FeedbackCluster()
        {
            return View();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult FeedbackClusterGB([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "feedback_cluster_num";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new FeedbackClusterParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                userId = MembershipUserID
            };

            List<FeedbackCluster> list = _contentManagementService.GetFeedbackCluster(ServiceLocator.Current.GetInstance<IRepositoryAsync<FeedbackCluster>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditFeedbackCluster(int feedBackClusterNumber)
        {
            CMSFeedbackCluster cms = new CMSFeedbackCluster();

            cms.FeedbackCluster = _contentManagementService.GetFeedbackClusterByNumber(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster>>(), feedBackClusterNumber);
            cms.ValidActivities = _contentManagementService.GetActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>());
            cms.ValidConditions = _contentManagementService.GetConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>());
            cms.ValidEmailCampaigns = _contentManagementService.GetEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_email_campaign>>());
            cms.ValidGoals = _contentManagementService.GetGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>());
            cms.ValidLearnEarns = _contentManagementService.GetLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>());
            cms.ValidFeedbackSections = _contentManagementService.GetFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_section>>());
            cms.ReportSections = _contentManagementService.GetReportSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_report_section>>());
            cms.ValidTools = _contentManagementService.GetTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>());
            cms.ValidArticles = _contentManagementService.GetArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
            cms.ValidDownloads = _contentManagementService.GetDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
            cms.ValidVideos = _contentManagementService.GetVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());

            cms.Activities = _contentManagementService.GetFeedbackClusterActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_activity>>(), feedBackClusterNumber);
            cms.Conditions = _contentManagementService.GetFeedbackClusterConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_condition>>(), feedBackClusterNumber);
            cms.EmailCampaigns = _contentManagementService.GetFeedbackClusterEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_email>>(), feedBackClusterNumber);
            cms.Goals = _contentManagementService.GetFeedbackClusterGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_goal>>(), feedBackClusterNumber);
            cms.LearnEarns = _contentManagementService.GetFeedbackClusterLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_learn>>(), feedBackClusterNumber);
            cms.FeedbackSections = _contentManagementService.GetFeedbackClusterFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_section>>(), feedBackClusterNumber);
            cms.Matrix = _contentManagementService.GetFeedbackClusterMatrix(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_matrix>>(), feedBackClusterNumber);
            cms.Tools = _contentManagementService.GetFeedbackClusterTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_tool>>(), feedBackClusterNumber);
            cms.Articles = _contentManagementService.GetFeedbackClusterArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_article>>(), feedBackClusterNumber);
            cms.Downloads = _contentManagementService.GetFeedbackClusterDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_download>>(), feedBackClusterNumber);
            cms.Videos = _contentManagementService.GetFeedbackClusterVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster_video>>(), feedBackClusterNumber);

            cms.CriteriaQuestions = cms.Matrix.Count() == 0 ? string.Empty : string.Join(",", cms.Matrix.Select(m => m.question_num.ToString()));
            cms.CriteriaAnswers = cms.Matrix.Count() == 0 ? string.Empty : string.Join(",", cms.Matrix.Select(m => m.answer_num.ToString()));

            return View("FeedbackClusterEditor", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult UpdateFeedbackCluster(int feedBackClusterNumber, string mainFeedback, string summaryFeedBack, string description, string nutrition, string supplements, string otherConsiderations, string activities, string conditions, string emailCampaigns, string goals, string learnEarns, string feedbackSections, string questions, string answers, string tools, string articles, string downloads, string videos, string MHRS, string ageMin, string ageMax, string ageRestrictionIncluded, string matchAll, string matchCriteria, string matchCount)
        {
            _contentManagementService.UpdateFeedbackCluster(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_cluster>>(), feedBackClusterNumber, mainFeedback, summaryFeedBack, MembershipUserID, description, nutrition, supplements, otherConsiderations, activities, conditions, emailCampaigns, goals, learnEarns, feedbackSections, questions, answers, tools, articles, downloads, videos, MHRS, ageMin, ageMax, ageRestrictionIncluded, matchAll, matchCriteria, matchCount);
            return Json("Success");
        }

        #endregion

        #region Feedback Criteria
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        public ActionResult FeedbackCriteria()
        {
            return View();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult FeedbackCriteriaGB([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "feedback_criteria_num";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new FeedbackCriteriaParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                userId = MembershipUserID
            };

            //force sort order by feedback_criteria_num.
            //some strange issue causing records to not be sorted correctly from SP - prcGetFeedbackCriteria
            List<FeedbackCriteria> list = _contentManagementService.GetFeedbackCriteria(ServiceLocator.Current.GetInstance<IRepositoryAsync<FeedbackCriteria>>(), pageCriteria).OrderBy(m => m.feedback_criteria_num).ToList();

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditFeedbackCriteria(int feedbackCriteriaNumber)
        {
            CMSFeedbackCriteria cms = new CMSFeedbackCriteria();

            cms.FeedbackCriteria = _contentManagementService.GetFeedbackCriteriaByNumber(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria>>(), feedbackCriteriaNumber);
            cms.ValidActivities = _contentManagementService.GetActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>());
            cms.ValidConditions = _contentManagementService.GetConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>());
            cms.ValidEmailCampaigns = _contentManagementService.GetEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_email_campaign>>());
            cms.ValidGoals = _contentManagementService.GetGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>());
            cms.ValidLearnEarns = _contentManagementService.GetLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>());
            cms.ValidFeedbackSections = _contentManagementService.GetFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_section>>());
            cms.ReportSections = _contentManagementService.GetReportSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_report_section>>());
            cms.ValidTools = _contentManagementService.GetTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>());
            cms.ValidArticles = _contentManagementService.GetArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
            cms.ValidDownloads = _contentManagementService.GetDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
            cms.ValidVideos = _contentManagementService.GetVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());

            cms.Activities = _contentManagementService.GetFeedbackCriteriaActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria_activity>>(), feedbackCriteriaNumber);
            cms.Conditions = _contentManagementService.GetFeedbackCriteriaConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria_condition>>(), feedbackCriteriaNumber);
            cms.EmailCampaigns = _contentManagementService.GetFeedbackCriteriaEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria_email>>(), feedbackCriteriaNumber);
            cms.Goals = _contentManagementService.GetFeedbackCriteriaGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria_goal>>(), feedbackCriteriaNumber);
            cms.LearnEarns = _contentManagementService.GetFeedbackCriteriaLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria_learn>>(), feedbackCriteriaNumber);
            cms.FeedbackSections = _contentManagementService.GetFeedbackCriteriaFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria_section>>(), feedbackCriteriaNumber);
            cms.Tools = _contentManagementService.GetFeedbackCriteriaTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria_tool>>(), feedbackCriteriaNumber);
            cms.Articles = _contentManagementService.GetFeedbackCriteriaArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria_article>>(), feedbackCriteriaNumber);
            cms.Downloads = _contentManagementService.GetFeedbackCriteriaDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria_download>>(), feedbackCriteriaNumber);
            cms.Videos = _contentManagementService.GetFeedbackCriteriaVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria_video>>(), feedbackCriteriaNumber);
            cms.Matrix = new List<hra_feedback_criteria_matrix>();

            //cms.CriteriaQuestions = cms.Matrix.Count() == 0 ? string.Empty : string.Join(",", cms.Matrix.Select(m => m.question_num.ToString()));
            //cms.CriteriaAnswers = cms.Matrix.Count() == 0 ? string.Empty : string.Join(",", cms.Matrix.Select(m => m.answer_num.ToString()));

            cms.CriteriaQuestions = string.Empty;
            cms.CriteriaAnswers = string.Empty;

            return View("FeedbackCriteriaEditor", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult UpdateFeedbackCriteria(int feedBackCriteriaNumber, string mainFeedback, string summaryFeedBack, string description, string nutrition, string supplements, string otherConsiderations, string activities, string conditions, string emailCampaigns, string goals, string learnEarns, string feedbackSections, string questions, string answers, string tools, string articles, string downloads, string videos, string MHRS, string criteriaMin, string criteriaMax, string gender)
        {
            _contentManagementService.UpdateFeedbackCriteria(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_criteria>>(), feedBackCriteriaNumber, mainFeedback, summaryFeedBack, MembershipUserID, description, nutrition, supplements, otherConsiderations, activities, conditions, emailCampaigns, goals, learnEarns, feedbackSections, questions, answers, tools, articles, downloads, videos, MHRS, criteriaMin, criteriaMax, gender);
            return Json("Success");
        }
        #endregion

        #region Feedback Custom
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        public ActionResult FeedbackCustom()
        {
            return View();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult FeedbackCustomGB([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "feedback_custom_num";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new FeedbackCustomParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                userId = MembershipUserID
            };

            List<FeedbackCustom> list = _contentManagementService.GetFeedbackCustom(ServiceLocator.Current.GetInstance<IRepositoryAsync<FeedbackCustom>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditFeedbackCustom(int feedbackCustomNumber)
        {
            CMSFeedbackCustom cms = new CMSFeedbackCustom();

            cms.FeedbackCustom = _contentManagementService.GetFeedbackCustomByNumber(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom>>(), feedbackCustomNumber);
            cms.ValidActivities = _contentManagementService.GetActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>());
            cms.ValidConditions = _contentManagementService.GetConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>());
            cms.ValidEmailCampaigns = _contentManagementService.GetEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_email_campaign>>());
            cms.ValidGoals = _contentManagementService.GetGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>());
            cms.ValidLearnEarns = _contentManagementService.GetLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>());
            cms.ValidFeedbackSections = _contentManagementService.GetFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_section>>());
            cms.ReportSections = _contentManagementService.GetReportSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_report_section>>());
            cms.ValidTools = _contentManagementService.GetTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>());
            cms.ValidArticles = _contentManagementService.GetArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
            cms.ValidDownloads = _contentManagementService.GetDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
            cms.ValidVideos = _contentManagementService.GetVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());

            cms.Activities = _contentManagementService.GetFeedbackCustomActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom_activity>>(), feedbackCustomNumber);
            cms.Conditions = _contentManagementService.GetFeedbackCustomConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom_condition>>(), feedbackCustomNumber);
            cms.EmailCampaigns = _contentManagementService.GetFeedbackCustomEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom_email>>(), feedbackCustomNumber);
            cms.Goals = _contentManagementService.GetFeedbackCustomGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom_goal>>(), feedbackCustomNumber);
            cms.LearnEarns = _contentManagementService.GetFeedbackCustomLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom_learn>>(), feedbackCustomNumber);
            cms.FeedbackSections = _contentManagementService.GetFeedbackCustomFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom_section>>(), feedbackCustomNumber);
            cms.Tools = _contentManagementService.GetFeedbackCustomTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom_tool>>(), feedbackCustomNumber);
            cms.Articles = _contentManagementService.GetFeedbackCustomArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom_article>>(), feedbackCustomNumber);
            cms.Downloads = _contentManagementService.GetFeedbackCustomDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom_download>>(), feedbackCustomNumber);
            cms.Videos = _contentManagementService.GetFeedbackCustomVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom_video>>(), feedbackCustomNumber);
            cms.Matrix = new List<hra_feedback_custom_matrix>();

            //cms.CustomQuestions = cms.Matrix.Count() == 0 ? string.Empty : string.Join(",", cms.Matrix.Select(m => m.question_num.ToString()));
            //cms.CustomAnswers = cms.Matrix.Count() == 0 ? string.Empty : string.Join(",", cms.Matrix.Select(m => m.answer_num.ToString()));

            cms.CustomQuestions = string.Empty;
            cms.CustomAnswers = string.Empty;

            return View("FeedbackCustomEditor", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult UpdateFeedbackCustom(int feedBackCustomNumber, string mainFeedback, string summaryFeedBack, string description, string nutrition, string supplements, string otherConsiderations, string activities, string conditions, string emailCampaigns, string goals, string learnEarns, string feedbackSections, string questions, string answers, string tools, string articles, string downloads, string videos, string questionNum, string answerNum, string ageMin, string ageMax, string ageRestrictionIncluded)
        {
            _contentManagementService.UpdateFeedbackCustom(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_custom>>(), feedBackCustomNumber, mainFeedback, summaryFeedBack, MembershipUserID, description, nutrition, supplements, otherConsiderations, activities, conditions, emailCampaigns, goals, learnEarns, feedbackSections, questions, answers, tools, articles, downloads, videos, questionNum, answerNum, ageMin, ageMax, ageRestrictionIncluded);
            return Json("Success");
        }
        #endregion

        #region Feedback Standard
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        public ActionResult FeedbackStandard()
        {
            return View();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult FeedbackStandardGB([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "feedback_standard_num";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageStandard = new FeedbackStandardParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                userId = MembershipUserID
            };

            //force sort order by feedback_standard_num.
            //some strange issue causing records to not be sorted correctly from SP - prcGetFeedbackStandard
            List<FeedbackStandard> list = _contentManagementService.GetFeedbackStandard(ServiceLocator.Current.GetInstance<IRepositoryAsync<FeedbackStandard>>(), pageStandard).OrderBy(m => m.feedback_standard_num).ToList();

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditFeedbackStandard(int feedbackStandardNumber)
        {
            CMSFeedbackStandard cms = new CMSFeedbackStandard();

            cms.FeedbackStandard = _contentManagementService.GetFeedbackStandardByNumber(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard>>(), feedbackStandardNumber);
            cms.ValidActivities = _contentManagementService.GetActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>());
            cms.ValidConditions = _contentManagementService.GetConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>());
            cms.ValidEmailCampaigns = _contentManagementService.GetEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_email_campaign>>());
            cms.ValidGoals = _contentManagementService.GetGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>());
            cms.ValidLearnEarns = _contentManagementService.GetLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>());
            cms.ValidFeedbackSections = _contentManagementService.GetFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_section>>());
            cms.ReportSections = _contentManagementService.GetReportSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_report_section>>());
            cms.ValidTools = _contentManagementService.GetTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>());
            cms.ValidArticles = _contentManagementService.GetArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
            cms.ValidDownloads = _contentManagementService.GetDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
            cms.ValidVideos = _contentManagementService.GetVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());

            cms.Activities = _contentManagementService.GetFeedbackStandardActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard_activity>>(), feedbackStandardNumber);
            cms.Conditions = _contentManagementService.GetFeedbackStandardConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard_condition>>(), feedbackStandardNumber);
            cms.EmailCampaigns = _contentManagementService.GetFeedbackStandardEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard_email>>(), feedbackStandardNumber);
            cms.Goals = _contentManagementService.GetFeedbackStandardGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard_goal>>(), feedbackStandardNumber);
            cms.LearnEarns = _contentManagementService.GetFeedbackStandardLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard_learn>>(), feedbackStandardNumber);
            cms.FeedbackSections = _contentManagementService.GetFeedbackStandardFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard_section>>(), feedbackStandardNumber);
            cms.Tools = _contentManagementService.GetFeedbackStandardTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard_tool>>(), feedbackStandardNumber);
            cms.Articles = _contentManagementService.GetFeedbackStandardArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard_article>>(), feedbackStandardNumber);
            cms.Downloads = _contentManagementService.GetFeedbackStandardDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard_download>>(), feedbackStandardNumber);
            cms.Videos = _contentManagementService.GetFeedbackStandardVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard_video>>(), feedbackStandardNumber);
            cms.Matrix = new List<hra_feedback_standard_matrix>();

            //cms.StandardQuestions = cms.Matrix.Count() == 0 ? string.Empty : string.Join(",", cms.Matrix.Select(m => m.question_num.ToString()));
            //cms.StandardAnswers = cms.Matrix.Count() == 0 ? string.Empty : string.Join(",", cms.Matrix.Select(m => m.answer_num.ToString()));

            cms.StandardQuestions = string.Empty;
            cms.StandardAnswers = string.Empty;

            return View("FeedbackStandardEditor", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult UpdateFeedbackStandard(int feedBackStandardNumber, string mainFeedback, string summaryFeedBack, string description, string nutrition, string supplements, string otherConsiderations, string activities, string conditions, string emailCampaigns, string goals, string learnEarns, string feedbackSections, string questions, string answers, string tools, string articles, string downloads, string videos, string ageMin, string ageMax, string gender)
        {
            _contentManagementService.UpdateFeedbackStandard(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_standard>>(), feedBackStandardNumber, mainFeedback, summaryFeedBack, MembershipUserID, description, nutrition, supplements, otherConsiderations, activities, conditions, emailCampaigns, goals, learnEarns, feedbackSections, questions, answers, tools, articles, downloads, videos, ageMin, ageMax, gender);
            return Json("Success");
        }
        #endregion

        #region Learn And Earns
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult LearnAndEarnCategory()
        {
            return View();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult LearnAndEarns()
        {
            return View();
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult LearnAndEarnsCategoryGB([DataSourceRequest] DataSourceRequest request)
        {

            var gridUtil = new GridUtil();
            LearningModuleCategoriesSearchParam pageCriteria = new LearningModuleCategoriesSearchParam();
            if (request.Filters.Count > 0)
                pageCriteria.SearchText = Convert.ToString(((Kendo.Mvc.FilterDescriptor)(request.Filters.FirstOrDefault())).Value);

            List<LearningModuleCategories> list = _contentManagementService.GetLearningModuleCategories(ServiceLocator.Current.GetInstance<IRepositoryAsync<LearningModuleCategories>>(), pageCriteria);
            var result = new DataSourceResult
            {
                Data = list,
                Total = list.Count
            };

            return Json(result);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult LearnAndEarnsGB([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "Date";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            //var pageCriteria = new LearnAndEarnParams {
            //    StartInd = request.PageSize * (request.Page - 1) + 1,
            //    EndInd = request.PageSize * request.Page,
            //    PageSize = request.PageSize,
            //    SortOrder = sortOrder,
            //    SortColumn = sortColumn,
            //    WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
            //    userId = MembershipUserID
            //};

            //List<LearnAndEarn> list = _contentManagementService.GetLearnAndEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<LearnAndEarn>>(), pageCriteria);

            List<BLR_LEARNING> list = _contentManagementService.GetLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>());

            int totalRows = 0;
            if (list.Count > 0)
            {
                //totalRows = list[0].TotalRows.GetValueOrDefault();
                totalRows = list.Count();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditLearnAndEarnCategory(int CategoryId)
        {

            var pageCriteria = new LearningModuleCategoriesSearchParam();
            List<LearningModuleCategories> list = _contentManagementService.GetLearningModuleCategories(ServiceLocator.Current.GetInstance<IRepositoryAsync<LearningModuleCategories>>(), pageCriteria);
            BLR_LEARNING_CATEGORY blrLearingCat = new BLR_LEARNING_CATEGORY();
            if (CategoryId > 0)
            {
                var item = list.Find(q => q.ID == CategoryId);
                blrLearingCat.Id = item.ID;
                blrLearingCat.Name = item.Name;
            }
            return View(blrLearingCat);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditLearnAndEarn(int learnId)
        {
            BLR_LEARNING blrLearing = new BLR_LEARNING();

            if (learnId > 0)
            {
                blrLearing = _contentManagementService.GetLearnAndEarnById(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>(), learnId);
                return View("LearnAndEarnEditor", blrLearing);
            }
            else
            {
                var pageCriteria = new LearningModuleCategoriesSearchParam();
                List<LearningModuleCategories> list = _contentManagementService.GetLearningModuleCategories(ServiceLocator.Current.GetInstance<IRepositoryAsync<LearningModuleCategories>>(), pageCriteria);
                ViewData["CategoryList"] = list;
                return View("LearnAndEarnAdd", blrLearing);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult UpdateLearnAndEarnCategory(int categoryId, string name)
        {
            _contentManagementService.UpdateLearnAndEarnCategory(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING_CATEGORY>>(), categoryId, name, MembershipUserID);
            return Json("Success");
        }


        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult UpdateLearnAndEarns(int learnId, string name, string description, string title)
        {
            _contentManagementService.UpdateLearnAndEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>(), learnId, name, description, title, MembershipUserID);
            return Json("Success");
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult AddLearnAndEarns(string name, string description, string title, string category)
        {
            _contentManagementService.AddLearnAndEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>(), name, description, title, category, MembershipUserID);
            return Json("Success");
        }

        [HttpPost]
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult DeleteLearnAndEarn(int learnId)
        {
            OperationResult result = new OperationResult();
            _contentManagementService.DeletetLearnAndEarn(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>(), learnId);
            result.Data = new { Message = "Learn and earn deleted successfully." };
            return Json(result);
        }
        #endregion

        #region Learn And Earns Tab
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult LearnAndEarnTab()
        {
            return View();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult LearnAndEarnTabGB([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "Date";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new LearnAndEarnTabParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                userId = MembershipUserID
            };

            List<LearnAndEarnTab> list = _contentManagementService.GetLearnAndEarnTabs(ServiceLocator.Current.GetInstance<IRepositoryAsync<LearnAndEarnTab>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        [HttpPost]
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult DeleteLearnAndEarnTab(int learnTabId)
        {
            OperationResult result = new OperationResult();
            _contentManagementService.DeletetLearnAndEarnTab(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING_TAB>>(), learnTabId);
            result.Data = new { Message = "Learn and earn tab deleted successfully." };
            return Json(result);
        }


        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditLearnAndEarnTab(int learnTabId)
        {
            BLR_LEARNING_TAB blrLearingTab = new BLR_LEARNING_TAB();
            if (learnTabId > 0)
            {
                blrLearingTab = _contentManagementService.GetLearnAndEarnTabById(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING_TAB>>(), learnTabId);
                return View("LearnAndEarnTabEditor", blrLearingTab);
            }
            else
            {
                return View("LearnAndEarnTabAdd", blrLearingTab);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult UpdateLearnAndEarnTabs(int learnTabId, string title, string body)
        {
            _contentManagementService.UpdateLearnAndEarnTabs(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING_TAB>>(), learnTabId, title, body, MembershipUserID);
            return Json("Success");
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult AddLearnAndEarnTabs(int learnId, string title, string body)
        {
            _contentManagementService.AddLearnAndEarnTabs(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING_TAB>>(), learnId, title, body, MembershipUserID);
            return Json("Success");
        }
        #endregion

        #region Dr Maschino Research Reviews
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ResearchReviews(string id)
        {
            string _view = string.Empty;
            if (id == "Downloads")
                _view = "ResearchReviewsDownloads";
            else if (id == "Videos")
                _view = "ResearchReviewsVideos";
            else
                _view = "ResearchReviews";

            return View(_view);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult ResearchReviewsGB([DataSourceRequest] DataSourceRequest request)
        {

            var result = GetResearchReview(request, null);
            return Json(result);
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult ResearchReviewsArticlesGB([DataSourceRequest] DataSourceRequest request)
        {
            var result = GetResearchReview(request, "AR");
            return Json(result);
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult ResearchReviewsDownloadsGB([DataSourceRequest] DataSourceRequest request)
        {
            var result = GetResearchReview(request, "D");
            return Json(result);
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult ResearchReviewsVideosGB([DataSourceRequest] DataSourceRequest request)
        {
            var result = GetResearchReview(request, "V");
            return Json(result);
        }
        private DataSourceResult GetResearchReview([DataSourceRequest] DataSourceRequest request, string contentType)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "Date";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new ResearchReviewParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                userId = MembershipUserID,
                contentType = contentType
            };

            List<ResearchReviews> list = _contentManagementService.GetResearchReviews(ServiceLocator.Current.GetInstance<IRepositoryAsync<ResearchReviews>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };
            return result;
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditResearchReview(int campaignId)
        {

            BLR_campaign_details blrCampaignDetails = _contentManagementService.GetResearchReviewsById(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), campaignId);

            var pageCriteria = new ResearchConditionSearchParam();
            List<ResearchCondition> lstRC = _contentManagementService.GetCondtions(ServiceLocator.Current.GetInstance<IRepositoryAsync<ResearchCondition>>(), pageCriteria);
            List<SelectListItem> _LiList = new List<SelectListItem>();
            foreach (var item in lstRC)
            {
                SelectListItem Li = new SelectListItem();
                Li.Text = item.Title;
                Li.Value = item.id.ToString();
                _LiList.Add(Li);
            }
            ViewBag.Chklist = new SelectList(_LiList, "Value", "Text");
            var dcCriteria = new Drip_campaignSearchParam();

            List<Drip_campaign> lstDC = _contentManagementService.GetDripCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<Drip_campaign>>(), dcCriteria);
            List<SelectListItem> _LiDCList = new List<SelectListItem>();
            foreach (var item in lstDC)
            {
                SelectListItem Li = new SelectListItem();
                Li.Text = item.description;
                Li.Value = item.id.ToString();
                _LiDCList.Add(Li);
            }
            ViewBag.DripChklist = new SelectList(_LiDCList, "Value", "Text");

            return View("ResearchReviewEditor", blrCampaignDetails);
        }


        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult AddResearchReview()
        {
            BLR_campaign_details Researchreview = new BLR_campaign_details();

            var pageCriteria = new ResearchConditionSearchParam();
            List<ResearchCondition> lstRC = _contentManagementService.GetCondtions(ServiceLocator.Current.GetInstance<IRepositoryAsync<ResearchCondition>>(), pageCriteria);
            List<SelectListItem> _LiList = new List<SelectListItem>();
            foreach (var item in lstRC)
            {
                SelectListItem Li = new SelectListItem();
                Li.Text = item.Title;
                Li.Value = item.id.ToString();
                _LiList.Add(Li);
            }
            ViewBag.Chklist = new SelectList(_LiList, "Value", "Text");
            var dcCriteria = new Drip_campaignSearchParam();

            List<Drip_campaign> lstDC = _contentManagementService.GetDripCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<Drip_campaign>>(), dcCriteria);
            List<SelectListItem> _LiDCList = new List<SelectListItem>();
            foreach (var item in lstDC)
            {
                SelectListItem Li = new SelectListItem();
                Li.Text = item.description;
                Li.Value = item.id.ToString();
                _LiDCList.Add(Li);
            }
            ViewBag.DripChklist = new SelectList(_LiDCList, "Value", "Text");

            return View("AddResearchReview", Researchreview);
        }


        public ActionResult AddEditResearchReviewDownloads(int? id)
        {
            BLR_campaign_details Researchreview = new BLR_campaign_details();
            if (id > 0)
                Researchreview = _contentManagementService.GetResearchReviewsById(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), Convert.ToInt32(id));

            var pageCriteria = new ResearchConditionSearchParam();
            List<ResearchCondition> lstRC = _contentManagementService.GetCondtions(ServiceLocator.Current.GetInstance<IRepositoryAsync<ResearchCondition>>(), pageCriteria);
            List<SelectListItem> _LiList = new List<SelectListItem>();
            foreach (var item in lstRC)
            {
                SelectListItem Li = new SelectListItem();
                Li.Text = item.Title;
                Li.Value = item.id.ToString();
                _LiList.Add(Li);
            }
            ViewBag.Chklist = new SelectList(_LiList, "Value", "Text");

            return View("AddResearchReviewDownloads", Researchreview);
        }
        public ActionResult AddEditResearchReviewVideos(int? id)
        {
            BLR_campaign_details Researchreview = new BLR_campaign_details();
            if (id > 0)
                Researchreview = _contentManagementService.GetResearchReviewsById(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), Convert.ToInt32(id));

            var pageCriteria = new ResearchConditionSearchParam();
            List<ResearchCondition> lstRC = _contentManagementService.GetCondtions(ServiceLocator.Current.GetInstance<IRepositoryAsync<ResearchCondition>>(), pageCriteria);
            List<SelectListItem> _LiList = new List<SelectListItem>();
            foreach (var item in lstRC)
            {
                SelectListItem Li = new SelectListItem();
                Li.Text = item.Title;
                Li.Value = item.id.ToString();
                _LiList.Add(Li);
            }
            ViewBag.Chklist = new SelectList(_LiList, "Value", "Text");

            return View("AddResearchReviewVideos", Researchreview);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        [HttpPost]
        public string UploadsDocuments(string type)
        {
            string msg = string.Empty;
            string filename = string.Empty;
            string filePath = null;

            for (int i = 0; i < Request.Files.Count; i++)
            {
                var file = Request.Files[i];

                var fileName = Path.GetFileName(file.FileName);
                try
                {
                    if (type == "downloads")
                    {
                        //filename = Guid.NewGuid() + Path.GetExtension(file.FileName);
                        filePath = "https://meschinowellness.blob.core.windows.net/downloads/" + file.FileName;
                        //saving file to destinatinaion folder
                        SaveToDownloadContainer(file.InputStream, filePath);
                    }
                    else
                    {
                        // filename = "asset-" + Guid.NewGuid() + Path.GetExtension(file.FileName);
                        //filePath = Path.GetFullPath(file.FileName);
                        filePath = "https://meschinowellness.blob.core.windows.net/downloads/" + file.FileName;

                        // filePath = "https://mediasvc611wkrxkhq32k.blob.core.windows.net/" + filename;
                        //saving file to destinatinaion folder
                        SaveToDownloadContainer(file.InputStream, filePath);

                        //SaveToVideoContainer("C:\\Users\\Sky\\Desktop\\BigBuckBunny.mp4", file.FileName);
                    }
                    msg = filePath;

                }
                catch (Exception ex)
                {
                    msg = "Error occurs";
                    throw ex;
                }
            }

            return msg;
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult SaveResearchReviewDownloads(int campaignId, string title, string body, string conditions_id, string conditions_type, string content_url_extension, string publishingStatus, string processing, string approving, string url, string url_text, string articleType, bool loginNotRequired)
        {
            conditions_id = conditions_id.Replace("rc_", "");
            _contentManagementService.AddUpdateResearchReviews(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), campaignId, title, body, "D", conditions_id, conditions_type, "", "", content_url_extension, "", "", "", publishingStatus, processing, approving, url, url_text, "", "", articleType, loginNotRequired, MembershipUserID);
            return Json("Success");
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult SaveResearchReviewVideos(int campaignId, string title, string body, string conditions_id, string conditions_type, string content_url_extension, string publishingStatus, string processing, string approving, string video_url, string instructions, string articleType, bool loginNotRequired)
        {
            conditions_id = conditions_id.Replace("rc_", "");
            _contentManagementService.AddUpdateResearchReviews(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), campaignId, title, body, "V", conditions_id, conditions_type, "", "", content_url_extension, "", "", "", publishingStatus, processing, approving, "", title, video_url, instructions, articleType, loginNotRequired, MembershipUserID);
            return Json("Success");
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult SaveResearchReview(int campaignId, string title, string body, string conditions_id, string conditions_type, string dripcampign_id, string dripcampign_name, string content_url_extension, string meta_title, string meta_keyword, string meta_desc, string publishingStatus, string processing, string approving, string url, string url_text, string video_url, string instructions, string articleType, bool loginNotRequired)
        {
            conditions_id = conditions_id.Replace("rc_", "");
            dripcampign_id = dripcampign_id.Replace("dc_", "");
            _contentManagementService.AddUpdateResearchReviews(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), campaignId, title, body, "AR", conditions_id, conditions_type, dripcampign_id, dripcampign_name, content_url_extension, meta_title, meta_keyword, meta_desc, publishingStatus, processing, approving, url, url_text, video_url, instructions, articleType, loginNotRequired, MembershipUserID);
            return Json("Success");
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult UpdateResearchReview(int campaignId, string title, string body, string conditions_id, string conditions_type, string dripcampign_id, string dripcampign_name, string content_url_extension, string meta_title, string meta_keyword, string meta_desc, string publishingStatus, string processing, string approving, string url, string url_text, string video_url, string instructions, bool loginNotRequired)
        {
            conditions_id = conditions_id.Replace("rc_", "");
            dripcampign_id = dripcampign_id.Replace("dc_", "");
            _contentManagementService.UpdateResearchReviews(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), campaignId, title, body, conditions_id, conditions_type, dripcampign_id, dripcampign_name, content_url_extension, meta_title, meta_keyword, meta_desc, publishingStatus, processing, approving, url, url_text, video_url, instructions, loginNotRequired, MembershipUserID);
            return Json("Success");
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditMultipleResearchReview()
        {
            var dcCriteria = new Drip_campaignSearchParam();

            List<Drip_campaign> lstDC = _contentManagementService.GetDripCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<Drip_campaign>>(), dcCriteria);
            List<SelectListItem> _LiDCList = new List<SelectListItem>();
            foreach (var item in lstDC)
            {
                SelectListItem Li = new SelectListItem();
                Li.Text = item.description;
                Li.Value = item.id.ToString();
                _LiDCList.Add(Li);
            }
            ViewBag.DripChklist = new SelectList(_LiDCList, "Value", "Text");
            return View();
        }

        public ActionResult UpdateMassResearchReview(string campaignIds, string publishingStatus, string processing, string contentType, string categories, string featureContent, string dripcampign_id, string dripcampign_name, string approving)
        {
            _contentManagementService.UpdateMassResearchReviews(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), campaignIds, publishingStatus, processing, contentType, categories, featureContent, dripcampign_id, dripcampign_name, approving, MembershipUserID);
            return Json("Success");
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult DeleteResearchReview(int campaignId)
        {
            OperationResult result = new OperationResult();
            Boolean IsSuccess = _contentManagementService.DeleteResearchReviews(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), campaignId, MembershipUserID);
            if (IsSuccess)
                result.Data = new { Message = "Research Review deleted successfully." };
            else
                result.Data = new { Message = "This article has published status!!!" };

            return Json(result);
        }

        public ActionResult Notification(int id, string contentType)
        {
            ViewBag.Id = id;
            ViewBag.ContentType = contentType;

            ViewData["Companies"] = _userService.GetCompanies(ServiceLocator.Current.GetInstance<IRepositoryAsync<Company>>()).ToSelectListItem(x => x.CompanyId.ToString(), y => y.Name, "All", true);
            ViewData["Users"] = _companyService.GetCompanyUsersById(ServiceLocator.Current.GetInstance<IRepositoryAsync<CompanyUsersResult>>(), null).ToSelectListItem(x => x.UserId.ToString(), y => y.Email, "All", true);
            ViewData["Conditions"] = _userService.GetRiskReportConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>()).ToSelectListItem(x => x.condition_num.ToString(), y => y.description, "All", true);

            return View();
        }

        #endregion

        #region Recommended Apps and Wearables
        //*********************************************************************
        //Apps List
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult PhoneAppsList()
        {
            List<phone_app> apps = new List<phone_app>();
            apps = _contentManagementService.GetPhoneApps(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app>>());
            return View("PhoneAppsList", apps);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        [HttpPost]
        public ActionResult PhoneAppAddSave(CMSPhoneApp cms, HttpPostedFileBase file)
        {
            if (ModelState.IsValid)
            {
                string filename = string.Empty;
                string filePath = null;

                if (file != null)
                {
                    try
                    {
                        filename = Guid.NewGuid() + Path.GetExtension(file.FileName);
                        filePath = "/images/" + filename;
                        //saving file to destinatinaion folder
                        SaveFileToFileSystem(file.InputStream, filePath);
                        cms.PhoneApp.icon_path = filePath;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                _contentManagementService.PhoneAppAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app>>(), cms.PhoneApp);
                return PhoneAppsList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                return View("PhoneAppAdd", cms.PhoneApp);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult PhoneAppAddEdit()
        {
            CMSPhoneApp cms = new CMSPhoneApp();
            cms.PhoneApp = new phone_app();
            //cms.PhoneApp.phone_type_num = LoggerInUserPhoneTypeId;
            cms.PhoneTypeList = _contentManagementService.GetPhoneTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_type>>());

            return View("PhoneAppAdd", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult PhoneAppEdit(int? phone_app_num)
        {

            if (phone_app_num == null || phone_app_num == 0)
            {
                return PhoneAppsList();
            }
            else
            {
                CMSPhoneApp cms = new CMSPhoneApp();
                cms.PhoneApp = _contentManagementService.GetPhoneAppByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app>>(), phone_app_num.GetValueOrDefault());
                cms.PhoneTypeList = _contentManagementService.GetPhoneTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_type>>());
                cms.MetricTypeList = _contentManagementService.GetMetricTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type>>());

                cms.PhoneAppTypeList = _contentManagementService.GetPhoneApp_PhoneType(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app_type>>(), phone_app_num.GetValueOrDefault());

                cms.PhoneAppMetricTypeList = _contentManagementService.GetPhoneApp_MetricType(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app_metric>>(), phone_app_num.GetValueOrDefault());
                return View("PhoneAppEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        [HttpPost]
        public ActionResult PhoneAppSave(CMSPhoneApp cms, HttpPostedFileBase file, string[] SelectedMetricTypes, string[] SelectedPhoneTypes)
        {
            if (ModelState.IsValid)
            {
                string filename = string.Empty;
                string filePath = null;

                if (file != null)
                {
                    try
                    {
                        filename = Guid.NewGuid() + Path.GetExtension(file.FileName);
                        filePath = "/images/" + filename;
                        //saving file to destinatinaion folder
                        SaveFileToFileSystem(file.InputStream, filePath);
                        cms.PhoneApp.icon_path = filePath;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                _contentManagementService.PhoneAppUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app>>(), cms.PhoneApp);
                _contentManagementService.PhoneAppUpdateMetricTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app_metric>>(), cms.PhoneApp, SelectedMetricTypes);
                _contentManagementService.PhoneAppUpdatePhoneTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app_type>>(), cms.PhoneApp, SelectedPhoneTypes);

                //_contentManagementService.MetricSourceUpdateTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_source_type>>(), cms.MetricSource, SelectedTypes);

                return PhoneAppsList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                cms.PhoneTypeList = _contentManagementService.GetPhoneTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_type>>());
                cms.MetricTypeList = _contentManagementService.GetMetricTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type>>());
                cms.PhoneAppMetricTypeList = _contentManagementService.GetPhoneApp_MetricType(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app_metric>>(), cms.PhoneApp.phone_app_num);
                cms.PhoneAppTypeList = _contentManagementService.GetPhoneApp_PhoneType(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app_type>>(), cms.PhoneApp.phone_app_num);

                return View("PhoneAppEdit", cms.PhoneApp);
            }
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult PhoneAppDeleteConfirm(int phone_app_num)
        {
            phone_app app = _contentManagementService.GetPhoneAppByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app>>(), phone_app_num);

            return View("PhoneAppDelete", app);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult PhoneAppDelete(phone_app app)
        {
            _contentManagementService.PhoneAppDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app>>(), app);

            return PhoneAppsList();
        }

        #endregion

        #region Active Goals
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ActiveGoals()
        {
            return View();
        }

        //*********************************************************************
        //Risk Pages
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskPageList()
        {
            List<hra_risk_page> RiskPages = new List<hra_risk_page>();
            RiskPages = _contentManagementService.GetRiskPages(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page>>());

            return View("RiskPageList", RiskPages);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskPageAdd()
        {
            CMSRiskPage cms = new CMSRiskPage();
            cms.RiskPage = new hra_risk_page();
            cms.ValidRisks = _contentManagementService.GetRisks(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>());
            cms.RiskPageMeters = new List<hra_risk_page_meter>();

            return View("RiskPageAdd", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskPageEdit(int? RiskPageNum)
        {
            if (RiskPageNum == null || RiskPageNum == 0)
            {
                return RiskList();
            }
            else
            {
                CMSRiskPage cms = new CMSRiskPage();
                cms.RiskPage = _contentManagementService.GetRiskPageByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page>>(), (int)RiskPageNum);
                cms.ValidRisks = _contentManagementService.GetRisks(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>());
                cms.RiskPageMeters = _contentManagementService.GetRiskPageMeters(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page_meter>>(), cms.RiskPage.risk_page_num);

                if (cms.RiskPage != null)
                {
                    return View("RiskPageEdit", cms);
                }
                else
                {
                    return RiskList();
                }
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskPageSave(CMSRiskPage cms)
        {
            if (ModelState.IsValid)
            {
                if (cms.RiskPage.risk_page_num == 0)
                {
                    //create new risk page
                    cms.RiskPage = _contentManagementService.RiskPageAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page>>(), cms.RiskPage);
                }
                else
                {
                    _contentManagementService.RiskPageUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page>>(), cms.RiskPage);
                }

                cms.RiskPageMeters = _contentManagementService.GetRiskPageMeters(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page_meter>>(), cms.RiskPage.risk_page_num);

                string[] SelectedRisks = cms.SelectedRisks.Split(',');

                //delete any removed page meters
                foreach (hra_risk_page_meter item in cms.RiskPageMeters)
                {
                    if (item.risk_page_num == cms.RiskPage.risk_page_num)
                    {
                        bool found = Array.Exists(SelectedRisks, e => e.Equals(item.risk_num));

                        if (SelectedRisks.Contains(item.risk_num.ToString()) == false)
                        {
                            //delete risk from risk page
                            hra_risk_page_meter RiskPageMeter = _contentManagementService.GetRiskPageMeterByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page_meter>>(), item.risk_page_num, item.risk_num);
                            _contentManagementService.RiskPageMeterDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page_meter>>(), RiskPageMeter);
                        }
                    }
                }

                //add any new page meters
                foreach (string item in SelectedRisks)
                {
                    hra_risk_page_meter RiskPageMeter = _contentManagementService.GetRiskPageMeterByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page_meter>>(), cms.RiskPage.risk_page_num, Convert.ToInt32(item));

                    if (RiskPageMeter == null)
                    {
                        _contentManagementService.RiskPageMeterAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page_meter>>(), cms.RiskPage.risk_page_num, Convert.ToInt32(item));
                    }
                }

                return RiskPageList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                if (cms.RiskPage.risk_page_num == 0)
                {
                    return RiskPageAdd();
                }
                else
                {
                    return RiskPageEdit(cms.RiskPage.risk_page_num);
                }
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskPageDeleteConfirm(int RiskPageNum)
        {
            CMSRiskPage cms = new CMSRiskPage();
            cms.RiskPage = _contentManagementService.GetRiskPageByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page>>(), RiskPageNum);
            cms.ValidRisks = _contentManagementService.GetRisks(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>());
            cms.RiskPageMeters = _contentManagementService.GetRiskPageMeters(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page_meter>>(), cms.RiskPage.risk_page_num);

            return View("RiskPageDelete", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskPageDelete(hra_risk_page RiskPage)
        {
            _contentManagementService.RiskPageDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_page>>(), RiskPage);

            return RiskPageList();
        }

        //*********************************************************************
        //Risks
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskList()
        {
            List<hra_risk> Risks = new List<hra_risk>();
            Risks = _contentManagementService.GetRisks(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>());

            return View("RiskList", Risks);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskEdit(int? RiskNum)
        {
            if (RiskNum == null || RiskNum == 0)
            {
                return RiskList();
            }
            else
            {
                CMSRisk cms = new CMSRisk();

                cms.Risk = _contentManagementService.GetRiskByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>(), RiskNum.GetValueOrDefault());

                //get all questions & answers
                cms.Questions = _contentManagementService.GetHRAQuestions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_question>>());
                cms.Answers = _contentManagementService.GetHRAAnswers(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_answer>>());

                cms.MatrixRed = _contentManagementService.GetRiskMatrixByScore(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), RiskNum.Value, RiskScores.Red).OrderBy(m => m.feedback_risk_num).ToList();
                cms.MatrixYellow = _contentManagementService.GetRiskMatrixByScore(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), RiskNum.Value, RiskScores.Yellow).OrderBy(m => m.feedback_risk_num).ToList();
                cms.MatrixGreen = _contentManagementService.GetRiskMatrixByScore(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), RiskNum.Value, RiskScores.Green).OrderBy(m => m.feedback_risk_num).ToList();


                //get all valid items
                cms.ValidGoals = _contentManagementService.GetGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>());


                //get all goal specific items
                cms.GoalsRed = _contentManagementService.GetRiskGoalsByScore(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_goal>>(), RiskNum.GetValueOrDefault(), RiskScores.Red);
                cms.GoalsYellow = _contentManagementService.GetRiskGoalsByScore(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_goal>>(), RiskNum.GetValueOrDefault(), RiskScores.Yellow);
                cms.GoalsGreen = _contentManagementService.GetRiskGoalsByScore(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_goal>>(), RiskNum.GetValueOrDefault(), RiskScores.Green);

                cms.FeedbackRiskListRed = _contentManagementService.GetRiskFeedback(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), RiskNum.GetValueOrDefault(), RiskScores.Red).OrderBy(m => m.feedback_risk_num).ToList();
                cms.FeedbackRiskListYellow = _contentManagementService.GetRiskFeedback(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), RiskNum.GetValueOrDefault(), RiskScores.Yellow).OrderBy(m => m.feedback_risk_num).ToList();
                cms.FeedbackRiskListGreen = _contentManagementService.GetRiskFeedback(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), RiskNum.GetValueOrDefault(), RiskScores.Green).OrderBy(m => m.feedback_risk_num).ToList();

                cms.FeedbackSelectListRed = new List<SelectListItem>();
                cms.FeedbackSelectListYellow = new List<SelectListItem>();
                cms.FeedbackSelectListGreen = new List<SelectListItem>();

                cms.FeedbackTextRed = new List<string>();
                cms.FeedbackTextYellow = new List<string>();
                cms.FeedbackTextGreen = new List<string>();

                cms.CriteriaTextRed = new List<string>();
                cms.CriteriaTextYellow = new List<string>();
                cms.CriteriaTextGreen = new List<string>();

                SelectListItem newItem;

                foreach (var item in cms.FeedbackRiskListRed)
                {
                    newItem = new SelectListItem { Value = item.feedback_risk_num.ToString(), Text = "Criteria " + item.feedback_risk_num.ToString() };

                    cms.FeedbackSelectListRed.Add(newItem);

                    cms.FeedbackTextRed.Add(item.summary_feedback);

                    cms.FeedbackRiskMatrixListRed = _contentManagementService.GetRiskMatrix(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), item.feedback_risk_num);

                    if (cms.FeedbackRiskMatrixListRed.Count > 0)
                    {
                        foreach (var x in cms.FeedbackRiskMatrixListRed)
                        {
                            cms.CriteriaTextRed.Add(x.question_num.ToString() + " / " + x.answer_num.ToString());
                        }
                    }
                }

                foreach (var item in cms.FeedbackRiskListYellow)
                {
                    newItem = new SelectListItem { Value = item.feedback_risk_num.ToString(), Text = "Criteria " + item.feedback_risk_num.ToString() };

                    cms.FeedbackSelectListYellow.Add(newItem);

                    cms.FeedbackTextYellow.Add(item.summary_feedback);

                    cms.FeedbackRiskMatrixListYellow = _contentManagementService.GetRiskMatrix(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), item.feedback_risk_num);

                    if (cms.FeedbackRiskMatrixListYellow.Count > 0)
                    {
                        foreach (var x in cms.FeedbackRiskMatrixListYellow)
                        {
                            cms.CriteriaTextYellow.Add(x.question_num.ToString() + " / " + x.answer_num.ToString());
                        }
                    }
                }

                foreach (var item in cms.FeedbackRiskListGreen)
                {
                    newItem = new SelectListItem { Value = item.feedback_risk_num.ToString(), Text = "Criteria " + item.feedback_risk_num.ToString() };

                    cms.FeedbackSelectListGreen.Add(newItem);

                    cms.FeedbackTextGreen.Add(item.summary_feedback);

                    cms.FeedbackRiskMatrixListGreen = _contentManagementService.GetRiskMatrix(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), item.feedback_risk_num);

                    if (cms.FeedbackRiskMatrixListGreen.Count > 0)
                    {
                        foreach (var x in cms.FeedbackRiskMatrixListGreen)
                        {
                            cms.CriteriaTextGreen.Add(x.question_num.ToString() + " / " + x.answer_num.ToString());
                        }
                    }
                }

                return View("RiskEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskSave(CMSRisk cms, string[] SelectedGoalsRed, string[] SelectedGoalsYellow, string[] SelectedGoalsGreen)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.RiskUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>(), cms.Risk);
                _contentManagementService.RiskUpdateGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_goal>>(), cms.Risk, SelectedGoalsRed, RiskScores.Red);
                _contentManagementService.RiskUpdateGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_goal>>(), cms.Risk, SelectedGoalsYellow, RiskScores.Yellow);
                _contentManagementService.RiskUpdateGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_goal>>(), cms.Risk, SelectedGoalsGreen, RiskScores.Green);

                return RiskList();
            }
            else
            {
                var errors = ModelState.Values.SelectMany(m => m.Errors);

                //validation errors have occurred.  Return user to fix errors.
                return RiskEdit(cms.Risk.risk_num);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskAddEdit()
        {
            return View("RiskAdd");
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskAddSave(hra_risk Risk)
        {
            _contentManagementService.RiskAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>(), Risk);

            return RiskList();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskDeleteConfirm(int RiskNum)
        {
            hra_risk risk = _contentManagementService.GetRiskByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>(), RiskNum);

            return View("RiskDelete", risk);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskDelete(hra_risk Risk)
        {
            _contentManagementService.RiskDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>(), Risk);

            return RiskList();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public string GetUserFullName(string UserID)
        {
            Wellness.Services.SecurityModels.ApplicationUser UserInfo = UserManager.FindById(UserID);
            return UserInfo.FullName;
        }

        //*********************************************************************
        //Risk Criteria
        //*********************************************************************
        //public JsonResult SaveResponses(HRAResponse[] Responses) {

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskCriteriaAddEdit(int RiskNum, RiskScores RiskScore)
        {

            CMSRiskCriteria RiskCriteria = new CMSRiskCriteria();
            RiskCriteria.Risk = _contentManagementService.GetRiskByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>(), RiskNum);
            RiskCriteria.FeedbackRisk = new hra_feedback_risk();
            RiskCriteria.FeedbackRisk.risk_num = RiskNum;
            RiskCriteria.FeedbackRisk.risk_score = (int)RiskScore;
            RiskCriteria.RiskScoreText = RiskScore.ToString();

            RiskCriteria.ReportSections = _contentManagementService.GetReportSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_report_section>>()).OrderBy(m => m.description).ToList();
            RiskCriteria.Questions = new List<hra_question>();
            RiskCriteria.Answers = new List<hra_answer>();

            return View("RiskCriteriaAdd", RiskCriteria);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public JsonResult RiskCriteriaAddSave(int RiskNum, int RiskScore, string CriteriaQuestions, string CriteriaAnswers, string SummaryFeedback)
        {
            List<hra_feedback_risk_matrix> RiskMatrixList = new List<hra_feedback_risk_matrix>();
            hra_feedback_risk_matrix RiskMatrix;
            hra_feedback_risk FeedbackRisk = new hra_feedback_risk();

            FeedbackRisk.risk_num = RiskNum;
            FeedbackRisk.risk_score = RiskScore;
            FeedbackRisk.main_feedback = string.Empty;
            FeedbackRisk.summary_feedback = SummaryFeedback == null ? string.Empty : SummaryFeedback;

            _contentManagementService.RiskFeedbackAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), FeedbackRisk);

            if (CriteriaQuestions != null && CriteriaQuestions.Length > 0)
            {
                string[] Questions = CriteriaQuestions.Split(',');
                string[] Answers = CriteriaAnswers.Split(',');
                int QuestionNum = 0;
                int AnswerNum = 0;

                for (int i = 0; i < Questions.Length; i++)
                {
                    QuestionNum = Convert.ToInt32(Questions[i]);
                    AnswerNum = Convert.ToInt32(Answers[i]);

                    RiskMatrix = new hra_feedback_risk_matrix();
                    RiskMatrix.feedback_risk_num = FeedbackRisk.feedback_risk_num;
                    RiskMatrix.question_num = QuestionNum;
                    RiskMatrix.answer_num = AnswerNum;

                    RiskMatrixList.Add(RiskMatrix);
                }

                if (RiskMatrixList.Count > 0)
                {
                    _contentManagementService.RiskCriteriaAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), FeedbackRisk.feedback_risk_num, RiskMatrixList);
                }
            }

            //return RiskEdit(FeedbackRisk.risk_num);
            return null;
        }

        //public ActionResult RiskCriteriaAddSave(CMSRiskCriteria cms) {
        //    if (ModelState.IsValid) {
        //        List<hra_feedback_risk_matrix> RiskMatrixList = new List<hra_feedback_risk_matrix>();
        //        hra_feedback_risk_matrix RiskMatrix;
        //        hra_feedback_risk FeedbackRisk = new hra_feedback_risk();

        //        FeedbackRisk.risk_num = cms.FeedbackRisk.risk_num;
        //        FeedbackRisk.risk_score = cms.FeedbackRisk.risk_score;
        //        FeedbackRisk.main_feedback = string.Empty;
        //        FeedbackRisk.summary_feedback = cms.FeedbackRisk.summary_feedback == null ? string.Empty : cms.FeedbackRisk.summary_feedback;

        //        _contentManagementService.RiskFeedbackAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), FeedbackRisk);

        //        if (cms.CriteriaQuestions != null && cms.CriteriaQuestions.Length > 0) {
        //            string[] Questions = cms.CriteriaQuestions.Split(',');
        //            string[] Answers = cms.CriteriaAnswers.Split(',');
        //            int QuestionNum = 0;
        //            int AnswerNum = 0;

        //            for (int i = 0; i < Questions.Length; i++) {
        //                QuestionNum = Convert.ToInt32(Questions[i]);
        //                AnswerNum = Convert.ToInt32(Answers[i]);

        //                RiskMatrix = new hra_feedback_risk_matrix();
        //                RiskMatrix.feedback_risk_num = FeedbackRisk.feedback_risk_num;
        //                RiskMatrix.question_num = QuestionNum;
        //                RiskMatrix.answer_num = AnswerNum;

        //                RiskMatrixList.Add(RiskMatrix);
        //            }

        //            if (RiskMatrixList.Count > 0) {
        //                _contentManagementService.RiskCriteriaAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), FeedbackRisk.feedback_risk_num, RiskMatrixList);
        //            }
        //        }

        //        return RiskEdit(FeedbackRisk.risk_num);
        //    }
        //    else {
        //        switch (cms.FeedbackRisk.risk_score) {
        //            case 1:
        //                return RiskCriteriaAddEdit(cms.Risk.risk_num, RiskScores.Red);
        //            case 2:
        //                return RiskCriteriaAddEdit(cms.Risk.risk_num, RiskScores.Yellow);
        //            case 3:
        //                return RiskCriteriaAddEdit(cms.Risk.risk_num, RiskScores.Green);
        //            default:
        //                return RiskCriteriaAddEdit(cms.Risk.risk_num, RiskScores.Red);
        //        }
        //    }
        //}

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult RiskCriteriaEdit(int FeedbackRiskNum)
        {
            CMSRiskCriteria RiskCriteria = new CMSRiskCriteria();
            RiskCriteria.FeedbackRisk = _contentManagementService.GetRiskFeedbackByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), FeedbackRiskNum);
            RiskCriteria.Risk = _contentManagementService.GetRiskByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk>>(), RiskCriteria.FeedbackRisk.risk_num);
            RiskCriteria.FeedbackRisk.risk_num = RiskCriteria.Risk.risk_num;
            RiskCriteria.FeedbackRisk.risk_score = RiskCriteria.FeedbackRisk.risk_score;
            RiskCriteria.RiskScoreText = Enum.GetName(typeof(RiskScores), RiskCriteria.FeedbackRisk.risk_score);
            RiskCriteria.RiskMatrix = _contentManagementService.GetRiskMatrix(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), RiskCriteria.FeedbackRisk.feedback_risk_num).ToList();

            RiskCriteria.CriteriaQuestions = "";
            RiskCriteria.CriteriaAnswers = "";

            foreach (var item in RiskCriteria.RiskMatrix)
            {
                if (RiskCriteria.CriteriaQuestions == "")
                {
                    RiskCriteria.CriteriaQuestions = item.question_num.ToString();
                }
                else
                {
                    RiskCriteria.CriteriaQuestions += "," + item.question_num.ToString();
                }

                if (RiskCriteria.CriteriaAnswers == "")
                {
                    RiskCriteria.CriteriaAnswers = item.answer_num.ToString();
                }
                else
                {
                    RiskCriteria.CriteriaAnswers += "," + item.answer_num.ToString();
                }
            }


            RiskCriteria.ReportSections = _contentManagementService.GetReportSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_report_section>>()).OrderBy(m => m.description).ToList();
            RiskCriteria.Questions = new List<hra_question>();
            RiskCriteria.Answers = new List<hra_answer>();

            return View("RiskCriteriaEdit", RiskCriteria);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public JsonResult RiskCriteriaDelete(int DeleteFeedbackRiskNum)
        {
            DeleteRiskCriteriaParams spParams = new DeleteRiskCriteriaParams() { FeedbackRiskNum = DeleteFeedbackRiskNum };
            _contentManagementService.RiskCriteriaDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), spParams);

            return null;
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public JsonResult RiskCriteriaMatrixDelete(string DeleteFeedbackRiskNum)
        {
            string QuestionNum = "0";
            string AnswerNum = "0";

            _contentManagementService.RiskCriteriaMatrixDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), Convert.ToInt32(DeleteFeedbackRiskNum), Convert.ToInt32(QuestionNum), Convert.ToInt32(AnswerNum));

            return null;
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public JsonResult RiskCriteriaSave(int FeedbackRiskNum, int RiskNum, int RiskScore, string CriteriaQuestions, string CriteriaAnswers, string SummaryFeedback)
        {
            List<hra_feedback_risk_matrix> RiskMatrixList = new List<hra_feedback_risk_matrix>();
            hra_feedback_risk_matrix RiskMatrix;
            hra_feedback_risk FeedbackRisk = _contentManagementService.GetRiskFeedbackByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), FeedbackRiskNum);

            if (FeedbackRisk != null)
            {
                FeedbackRisk.summary_feedback = SummaryFeedback == null ? string.Empty : SummaryFeedback;
                _contentManagementService.RiskCriteriaUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk>>(), FeedbackRisk);

                //update risk criteria questions
                string[] Questions = null;
                string[] Answers = null;
                int QuestionNum = 0;
                int AnswerNum = 0;

                if (CriteriaQuestions != null)
                {
                    Questions = CriteriaQuestions.Split(',');
                    Answers = CriteriaAnswers.Split(',');

                    for (int i = 0; i < Questions.Length; i++)
                    {
                        QuestionNum = Convert.ToInt32(Questions[i]);
                        AnswerNum = Convert.ToInt32(Answers[i]);

                        RiskMatrix = new hra_feedback_risk_matrix();
                        RiskMatrix.feedback_risk_num = FeedbackRiskNum;
                        RiskMatrix.question_num = QuestionNum;
                        RiskMatrix.answer_num = AnswerNum;

                        RiskMatrixList.Add(RiskMatrix);
                    }
                }

                _contentManagementService.RiskCriteriaAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), FeedbackRiskNum, RiskMatrixList);
            }

            //return RiskEdit(cms.FeedbackRisk.risk_num);
            return null;
        }


        //    //if (cms.CriteriaQuestions != null && cms.CriteriaQuestions.Length > 0) {
        //    //    string[] Questions = cms.CriteriaQuestions.Substring(0, cms.CriteriaQuestions.Length - 1).Split(',');
        //    //    string[] Answers = cms.CriteriaAnswers.Substring(0, cms.CriteriaAnswers.Length - 1).Split(',');
        //    //    int QuestionNum = 0;
        //    //    int AnswerNum = 0;

        //    //    for (int i = 0; i < Questions.Length; i++) {
        //    //        QuestionNum = Convert.ToInt32(Questions[i]);
        //    //        AnswerNum = Convert.ToInt32(Answers[i]);

        //    //        RiskMatrix = new hra_feedback_risk_matrix();
        //    //        RiskMatrix.feedback_risk_num = cms.FeedbackRisk.feedback_risk_num;
        //    //        RiskMatrix.question_num = QuestionNum;
        //    //        RiskMatrix.answer_num = AnswerNum;

        //    //        RiskMatrixList.Add(RiskMatrix);
        //    //    }

        //    //    if (RiskMatrixList.Count > 0) {
        //    //        _contentManagementService.RiskCriteriaAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_risk_matrix>>(), RiskMatrixList);
        //    //    }

        //    //    return RiskEdit(cms.FeedbackRisk.risk_num);
        //    //}
        //    //else {
        //    //    //validation errors have occurred.  Return user to fix errors.
        //    //    var allErrors = ModelState.Values.SelectMany(x => x.Errors);

        //    //    return View("RiskCriteriaEdit", cms);
        //    //}
        //}

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public JsonResult GetQuestionsByReportSection(string[] SectionNum)
        {
            List<hra_question> listQuestions = _contentManagementService.GetQuestionsByReportSection(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_question>>(), Convert.ToInt32(SectionNum[0]));

            return Json(listQuestions);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public JsonResult GetQuestions()
        {
            List<hra_question> listQuestions = _contentManagementService.GetQuestions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_question>>());

            return Json(listQuestions);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public JsonResult GetAnswersByQuestion(string[] QuestionNum)
        {
            List<hra_answer> listAnswers = _contentManagementService.GetAnswersByQuestion(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_answer>>(), Convert.ToInt32(QuestionNum[0]));

            return Json(listAnswers);
        }

        //*********************************************************************
        //Exercises
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseList()
        {
            List<DMT_Exercises> Exercises = _contentManagementService.GetExercises(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>());
            return View("ExerciseList", Exercises);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseEdit(int? ExerciseNum)
        {
            if (ExerciseNum == null || ExerciseNum == 0)
            {
                return ExerciseList();
            }
            else
            {
                CMSExercise cms = new CMSExercise();
                cms.Exercise = _contentManagementService.GetExerciseByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>(), ExerciseNum.GetValueOrDefault());

                List<DMT_Exercises_metric> exerciseMetrics = _contentManagementService.GetExerciseMetricsByExerciseNum(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises_metric>>(), ExerciseNum.GetValueOrDefault());

                List<SelectListItem> newList = new List<SelectListItem>();
                SelectListItem newItem;
                string MetricDescription;
                uom uom;

                foreach (var metric in exerciseMetrics)
                {
                    uom = _contentManagementService.GetUOMByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>(), metric.uom_num);

                    MetricDescription = metric.description + " - ( " + metric.metric.ToString("###,##0.#####") + " " + uom.description + " )";
                    newItem = new SelectListItem { Value = metric.exercise_metric_num.ToString(), Text = MetricDescription };
                    newList.Add(newItem);
                }

                cms.ExerciseMetrics = newList;

                return View("ExerciseEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult ExerciseSave(CMSExercise cms)
        {
            var errors = ModelState.Values.SelectMany(v => v.Errors);

            if (ModelState.IsValid)
            {
                _contentManagementService.ExerciseUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>(), cms.Exercise);

                return RedirectToAction("ExerciseList");
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                //CMSExercise cms = new CMSExercise();
                //cms.Exercise = Exercise;

                List<DMT_Exercises_metric> exerciseMetrics = _contentManagementService.GetExerciseMetricsByExerciseNum(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises_metric>>(), cms.Exercise.id);

                List<SelectListItem> newList = new List<SelectListItem>();
                SelectListItem newItem;
                string MetricDescription;
                uom uom;

                foreach (var metric in exerciseMetrics)
                {
                    uom = _contentManagementService.GetUOMByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>(), metric.uom_num);

                    MetricDescription = metric.description + " - ( " + metric.metric.ToString("###,##0.#####") + " " + uom.description + " )";
                    newItem = new SelectListItem { Value = metric.exercise_metric_num.ToString(), Text = MetricDescription };
                    newList.Add(newItem);
                }

                cms.ExerciseMetrics = newList;

                return View("ExerciseEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseAddEdit()
        {
            CMSExercise cms = new CMSExercise();
            cms.Exercise = new DMT_Exercises();
            cms.ExerciseMetrics = new List<SelectListItem>();

            return View("ExerciseAdd", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseAddSave(CMSExercise cms)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.ExerciseAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>(), cms.Exercise);

                return RedirectToAction("ExerciseList");
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                return View("ExerciseAdd", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseDeleteConfirm(int ExerciseNum)
        {
            CMSExercise cms = new CMSExercise();
            cms.Exercise = _contentManagementService.GetExerciseByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>(), ExerciseNum);

            return View("ExerciseDelete", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseDelete(DMT_Exercises Exercise)
        {
            if (Exercise != null)
            {
                _contentManagementService.ExerciseMetricDeleteByExerciseNum(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises_metric>>(), Exercise.id);
                _contentManagementService.ExerciseDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>(), Exercise);
            }

            return RedirectToAction("ExerciseList");
        }

        //*********************************************************************
        //Exercise Metrics
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseMetricList()
        {
            //List<DMT_Exercises_metric> Exercises = _contentManagementService.GetExercises(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises_metric>>());
            //return View("ExerciseList", Exercises);
            return null;
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseMetricEdit(int ExerciseMetricNum)
        {
            if (ExerciseMetricNum == 0)
            {
                return ExerciseList();
            }
            else
            {
                CMSExerciseMetric cms = new CMSExerciseMetric();
                cms.ExerciseMetric = _contentManagementService.GetExerciseMetricByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises_metric>>(), ExerciseMetricNum);
                cms.Exercise = _contentManagementService.GetExerciseByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>(), cms.ExerciseMetric.exercise_num);
                cms.UOMList = _contentManagementService.GetUOMs(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>());

                return View("ExerciseMetricEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseMetricSave(CMSExerciseMetric cms)
        {
            //var errors = ModelState.Values.SelectMany(v => v.Errors);

            if (ModelState.IsValid)
            {
                _contentManagementService.ExerciseMetricUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises_metric>>(), cms.ExerciseMetric);

                return ExerciseEdit(cms.Exercise.id);
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                cms.UOMList = _contentManagementService.GetUOMs(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>());
                return View("ExerciseMetricEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseMetricAddEdit(int ExerciseNum)
        {
            CMSExerciseMetric cms = new CMSExerciseMetric();
            cms.Exercise = _contentManagementService.GetExerciseByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>(), ExerciseNum);

            if (cms.Exercise != null)
            {
                cms.ExerciseMetric = new DMT_Exercises_metric();
                cms.ExerciseMetric.exercise_num = ExerciseNum;
                cms.UOMList = _contentManagementService.GetUOMs(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>());

                return View("ExerciseMetricAdd", cms);
            }
            else
            {
                return ExerciseEdit(cms.Exercise.id);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseMetricAddSave(DMT_Exercises_metric ExerciseMetric)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.ExerciseMetricAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises_metric>>(), ExerciseMetric);

                return ExerciseEdit(ExerciseMetric.exercise_num);
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                CMSExerciseMetric cms = new CMSExerciseMetric();
                cms.Exercise = _contentManagementService.GetExerciseByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>(), ExerciseMetric.exercise_num);
                cms.UOMList = _contentManagementService.GetUOMs(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>());

                return View("ExerciseMetricAdd", ExerciseMetric.exercise_num);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseMetricDeleteConfirm(int ExerciseMetricNum)
        {
            CMSExerciseMetric cms = new CMSExerciseMetric();
            cms.ExerciseMetric = _contentManagementService.GetExerciseMetricByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises_metric>>(), ExerciseMetricNum);
            cms.Exercise = _contentManagementService.GetExerciseByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>(), cms.ExerciseMetric.exercise_num);
            cms.UOMList = _contentManagementService.GetUOMs(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>());

            return View("ExerciseMetricDelete", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ExerciseMetricDelete(DMT_Exercises_metric ExerciseMetric)
        {
            int ExerciseNum = ExerciseMetric.exercise_num;

            if (ExerciseMetric != null)
            {
                _contentManagementService.ExerciseMetricDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises_metric>>(), ExerciseMetric);
            }

            return ExerciseEdit(ExerciseNum);
        }

        //*********************************************************************
        //Goals
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult GoalList()
        {
            List<hra_goal> Goals = new List<hra_goal>();
            Goals = _contentManagementService.GetGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>());
            hra_risk_report hrr = _walletSrv.GetLatestRiskReportByUser(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_risk_report>>(), base.MembershipUserID);
            if (hrr != null)
                ViewBag.RiskReportNum = hrr.risk_report_num;

            return View("GoalList", Goals);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult GoalEdit(int? GoalNum)
        {
            if (GoalNum == null || GoalNum == 0)
            {
                return GoalList();
            }
            else
            {
                CMSGoal cms = new CMSGoal();

                cms.Goal = _contentManagementService.GetGoalByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>(), GoalNum.GetValueOrDefault());

                //get all valid items
                //cms.ValidActivities = _contentManagementService.GetActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>());
                cms.ValidDownloads = _contentManagementService.GetDownloadsByStatus(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), DownloadStatuses.Published);
                cms.ValidEmailCampaigns = _contentManagementService.GetEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_email_campaign>>());
                cms.ValidLearnEarns = _contentManagementService.GetLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>());
                cms.ValidTools = _contentManagementService.GetTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>());
                cms.ValidPhoneApps = _contentManagementService.GetPhoneApps(ServiceLocator.Current.GetInstance<IRepositoryAsync<phone_app>>());
                cms.ValidConditions = _contentManagementService.GetConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>());
                cms.ValidVideos = _contentManagementService.GetVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());

                //get all goal specific items
                //cms.Activities = _contentManagementService.GetGoalActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_activity>>(), GoalNum.GetValueOrDefault());
                cms.Downloads = _contentManagementService.GetGoalDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_download>>(), GoalNum.GetValueOrDefault());
                cms.EmailCampaigns = _contentManagementService.GetGoalEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_email>>(), GoalNum.GetValueOrDefault());
                cms.LearnEarns = _contentManagementService.GetGoalLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_learn>>(), GoalNum.GetValueOrDefault());
                cms.Tools = _contentManagementService.GetGoalTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_tool>>(), GoalNum.GetValueOrDefault());
                cms.PhoneApps = _contentManagementService.GetGoalPhoneApps(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_app>>(), GoalNum.GetValueOrDefault());
                cms.Conditions = _contentManagementService.GetGoalConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_condition>>(), GoalNum.GetValueOrDefault());
                cms.Videos = _contentManagementService.GetGoalVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_video>>(), GoalNum.GetValueOrDefault());

                return View("GoalEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult GoalSave(CMSGoal cms, string[] SelectedActivities, string[] SelectedDownloads, string[] SelectedEmailCampaigns, string[] SelectedLearnEarns, string[] SelectedPhoneApps, string[] SelectedTools, string[] SelectedConditions, string[] SelectedVideos)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.GoalUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>(), cms.Goal);
                //_contentManagementService.GoalUpdateActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_activity>>(), cms.Goal, SelectedActivities);
                _contentManagementService.GoalUpdateDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_download>>(), cms.Goal, SelectedDownloads);
                _contentManagementService.GoalUpdateEmailCampaigns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_email>>(), cms.Goal, SelectedEmailCampaigns);
                _contentManagementService.GoalUpdateLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_learn>>(), cms.Goal, SelectedLearnEarns);
                _contentManagementService.GoalUpdateTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_tool>>(), cms.Goal, SelectedTools);
                _contentManagementService.GoalUpdatePhoneApps(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_app>>(), cms.Goal, SelectedPhoneApps);
                _contentManagementService.GoalUpdateConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_condition>>(), cms.Goal, SelectedConditions);
                _contentManagementService.GoalUpdateVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal_video>>(), cms.Goal, SelectedVideos);

                return GoalList();
            }
            else
            {
                var errors = ModelState.Values.SelectMany(m => m.Errors);

                //validation errors have occurred.  Return user to fix errors.
                //return View("GoalEdit", cms);
                return GoalEdit(cms.Goal.goal_num);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult GoalAddEdit()
        {
            return View("GoalAdd");
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult GoalAddSave(hra_goal Goal)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.GoalAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>(), Goal);

                return GoalList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                return View("GoalAdd", Goal);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult GoalDeleteConfirm(int GoalNum)
        {
            hra_goal goal = _contentManagementService.GetGoalByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>(), GoalNum);

            return View("GoalDelete", goal);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult GoalDelete(hra_goal Goal)
        {
            _contentManagementService.GoalDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>(), Goal);

            return GoalList();
        }

        [NoCache]
        public ActionResult PreviewGoal(int goalId)
        {
            hra_goal goal = _contentManagementService.GetGoalByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>(), goalId);
            return PartialView("PreviewGoal", goal);
        }

        //Conditions
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ConditionList()
        {
            List<hra_condition> Conditions = new List<hra_condition>();
            Conditions = _contentManagementService.GetConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>());

            return View("ConditionList", Conditions);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ConditionEdit(int? ConditionNum)
        {
            if (ConditionNum == null || ConditionNum == 0)
            {
                return ConditionList();
            }
            else
            {
                CMSCondition cms = new CMSCondition();
                cms.Condition = _contentManagementService.GetConditionByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>(), ConditionNum.GetValueOrDefault());
                cms.Condition.FeedbackSectionList = _contentManagementService.GetFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_section>>());
                cms.ValidArticles = _contentManagementService.GetArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
                cms.ValidDownloads = _contentManagementService.GetDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
                cms.ValidLearnEarns = _contentManagementService.GetLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>());
                cms.ValidTools = _contentManagementService.GetTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>());
                cms.ValidVideos = _contentManagementService.GetVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());

                cms.Tools = _contentManagementService.GetConditionTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), ConditionNum.GetValueOrDefault());
                cms.Downloads = _contentManagementService.GetConditionDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<download_condition>>(), ConditionNum.GetValueOrDefault());
                cms.Videos = _contentManagementService.GetConditionVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<video_condition>>(), ConditionNum.GetValueOrDefault());
                cms.Articles = _contentManagementService.GetConditionArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<article_condition>>(), ConditionNum.GetValueOrDefault());
                cms.LearnEarns = _contentManagementService.GetConditionLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<learn_earn_condition>>(), ConditionNum.GetValueOrDefault());

                return View("ConditionEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ConditionSave(CMSCondition cms, string[] SelectedTools, string[] SelectedDownloads, string[] SelectedVideos, string[] SelectedArticles, string[] SelectedLearnEarns)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.ConditionUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>(), cms.Condition);
                _contentManagementService.ConditionUpdateTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), cms.Condition, SelectedTools);
                _contentManagementService.ConditionUpdateDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<download_condition>>(), cms.Condition, SelectedDownloads);
                _contentManagementService.ConditionUpdateVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<video_condition>>(), cms.Condition, SelectedVideos);
                _contentManagementService.ConditionUpdateArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<article_condition>>(), cms.Condition, SelectedArticles);
                _contentManagementService.ConditionUpdateLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<learn_earn_condition>>(), cms.Condition, SelectedLearnEarns);

                return ConditionList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                return View("ConditionEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ConditionAddEdit()
        {
            CMSCondition cms = new CMSCondition();
            cms.Condition = new hra_condition();
            cms.Condition.FeedbackSectionList = _contentManagementService.GetFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_section>>());
            cms.ValidArticles = _contentManagementService.GetArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
            cms.ValidDownloads = _contentManagementService.GetDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
            cms.ValidLearnEarns = _contentManagementService.GetLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>());
            cms.ValidTools = _contentManagementService.GetTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>());
            cms.ValidVideos = _contentManagementService.GetVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());

            cms.Tools = new List<hra_tool_condition>();
            cms.Downloads = new List<download_condition>();
            cms.Videos = new List<video_condition>();
            cms.Articles = new List<article_condition>();
            cms.LearnEarns = new List<learn_earn_condition>();

            return View("ConditionAdd", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ConditionAddSave(CMSCondition cms, string[] SelectedTools, string[] SelectedDownloads, string[] SelectedVideos, string[] SelectedArticles, string[] SelectedLearnEarns)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.ConditionAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>(), cms.Condition);
                _contentManagementService.ConditionUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>(), cms.Condition);
                _contentManagementService.ConditionUpdateTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), cms.Condition, SelectedTools);
                _contentManagementService.ConditionUpdateDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<download_condition>>(), cms.Condition, SelectedDownloads);
                _contentManagementService.ConditionUpdateVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<video_condition>>(), cms.Condition, SelectedVideos);
                _contentManagementService.ConditionUpdateArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<article_condition>>(), cms.Condition, SelectedArticles);
                _contentManagementService.ConditionUpdateLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<learn_earn_condition>>(), cms.Condition, SelectedLearnEarns);

                return ConditionList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                cms.Condition.FeedbackSectionList = _contentManagementService.GetFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_section>>());

                return View("ConditionAdd", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ConditionDeleteConfirm(int ConditionNum)
        {
            if (ConditionNum == 0)
            {
                return ConditionList();
            }
            else
            {
                CMSCondition cms = new CMSCondition();
                cms.Condition = _contentManagementService.GetConditionByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>(), ConditionNum);
                cms.Condition.FeedbackSectionList = _contentManagementService.GetFeedbackSections(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_feedback_section>>());
                cms.ValidArticles = _contentManagementService.GetArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
                cms.ValidDownloads = _contentManagementService.GetDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());
                cms.ValidLearnEarns = _contentManagementService.GetLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING>>());
                cms.ValidTools = _contentManagementService.GetTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>());
                cms.ValidVideos = _contentManagementService.GetVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());

                cms.Tools = _contentManagementService.GetConditionTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), ConditionNum);
                cms.Downloads = _contentManagementService.GetConditionDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<download_condition>>(), ConditionNum);
                cms.Videos = _contentManagementService.GetConditionVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<video_condition>>(), ConditionNum);
                cms.Articles = _contentManagementService.GetConditionArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<article_condition>>(), ConditionNum);
                cms.LearnEarns = _contentManagementService.GetConditionLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<learn_earn_condition>>(), ConditionNum);

                return View("ConditionDelete", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ConditionDelete(int ConditionNum)
        {
            if (ConditionNum != 0)
            {
                hra_condition condition = _contentManagementService.GetConditionByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>(), ConditionNum);

                if (condition != null)
                {
                    _contentManagementService.ConditionDeleteArticles(ServiceLocator.Current.GetInstance<IRepositoryAsync<article_condition>>(), ConditionNum);
                    _contentManagementService.ConditionDeleteDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<download_condition>>(), ConditionNum);
                    _contentManagementService.ConditionDeleteLearnEarns(ServiceLocator.Current.GetInstance<IRepositoryAsync<learn_earn_condition>>(), ConditionNum);
                    _contentManagementService.ConditionDeleteTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), ConditionNum);
                    _contentManagementService.ConditionDeleteVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<video_condition>>(), ConditionNum);
                    _contentManagementService.ConditionDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>(), condition);
                }
            }

            return ConditionList();
        }

        //*********************************************************************
        //Tools
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ToolList()
        {
            HealthActivitySearchParam searchParams = new HealthActivitySearchParam() { UserId = 1 };
            List<hra_tool> Tools = _contentManagementService.GetTools(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>());

            return View("ToolList", Tools);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ToolEdit(int? ToolNum)
        {
            if (ToolNum == null || ToolNum == 0)
            {
                return ToolList();
            }
            else
            {
                CMSTool cms = new CMSTool();
                cms.Tool = _contentManagementService.GetToolByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>(), ToolNum.GetValueOrDefault());
                cms.ValidConditions = _contentManagementService.GetConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>());
                cms.Conditions = _contentManagementService.GetToolConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), ToolNum.GetValueOrDefault());

                return View("ToolEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult ToolSave(CMSTool cms, string[] SelectedConditions)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.ToolUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>(), cms.Tool);
                _contentManagementService.ToolUpdateConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), cms.Tool, SelectedConditions);

                return ToolList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                CMSTool cmsValid = new CMSTool();
                cmsValid.Tool = cms.Tool;
                cmsValid.ValidConditions = _contentManagementService.GetConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>());
                cmsValid.Conditions = _contentManagementService.GetToolConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), cms.Tool.tool_num);

                return View("ToolEdit", cmsValid);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ToolAddEdit()
        {
            CMSTool cms = new CMSTool();
            cms.Tool = new hra_tool();
            cms.ValidConditions = _contentManagementService.GetConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>());
            cms.Conditions = new List<hra_tool_condition>();

            return View("ToolAdd", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ToolAddSave(CMSTool cms, string[] SelectedConditions)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.ToolAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>(), cms.Tool);
                _contentManagementService.ToolUpdateConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), cms.Tool, SelectedConditions);

                return ToolList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                return View("ToolAdd", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ToolDeleteConfirm(int ToolNum)
        {
            CMSTool cms = new CMSTool();
            cms.Tool = _contentManagementService.GetToolByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>(), ToolNum);
            cms.ValidConditions = _contentManagementService.GetConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_condition>>());
            cms.Conditions = _contentManagementService.GetToolConditions(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), ToolNum);

            return View("ToolDelete", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ToolDelete(CMSTool cms)
        {
            if (cms.Tool != null)
            {
                _contentManagementService.ToolConditionDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool_condition>>(), cms.Tool.tool_num);
                _contentManagementService.ToolDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_tool>>(), cms.Tool.tool_num);
            }

            return ToolList();
        }


        //*********************************************************************
        //Downloads
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult DownloadList()
        {
            List<BLR_campaign_details> Downloads = new List<BLR_campaign_details>();
            Downloads = _contentManagementService.GetDownloads(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>());

            return View("DownloadList", Downloads);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult DownloadEdit(int? DownloadNum)
        {
            if (DownloadNum == null || DownloadNum == 0)
            {
                return DownloadList();
            }
            else
            {
                BLR_campaign_details tool = _contentManagementService.GetDownloadByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), DownloadNum.GetValueOrDefault());

                return View("DownloadEdit", tool);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult DownloadSave(BLR_campaign_details Download)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.DownloadUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), Download);

                return DownloadList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                return View("DownloadEdit", Download);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult DownloadAddEdit()
        {
            BLR_campaign_details tool = new BLR_campaign_details();

            return View("DownloadAdd", tool);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult DownloadAddSave(BLR_campaign_details Download)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.DownloadAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), Download);

                return DownloadList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                return View("DownloadAdd", Download);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult DownloadDeleteConfirm(int DownloadNum)
        {
            BLR_campaign_details tool = _contentManagementService.GetDownloadByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), DownloadNum);

            return View("DownloadDelete", tool);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult DownloadDelete(BLR_campaign_details Download)
        {
            if (Download != null)
            {
                _contentManagementService.DownloadDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_campaign_details>>(), Download);
            }

            return DownloadList();
        }

        //*********************************************************************
        //Activities
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ActivityList()
        {
            List<hra_activity> Activities = new List<hra_activity>();
            Activities = _contentManagementService.GetActivities(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>());

            return View("ActivityList", Activities);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ActivityEdit(int? ActivityNum)
        {
            if (ActivityNum == null || ActivityNum == 0)
            {
                return ActivityList();
            }
            else
            {
                hra_activity activity = _contentManagementService.GetActivityByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>(), ActivityNum.GetValueOrDefault());

                return View("ActivityEdit", activity);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ActivitySave(hra_activity Activity)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.ActivityUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>(), Activity);

                return ActivityList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                return View("ActivityEdit", Activity);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ActivityAddEdit()
        {
            hra_activity activity = new hra_activity();

            return View("ActivityAdd", activity);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ActivityAddSave(hra_activity Activity)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.ActivityAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>(), Activity);

                return ActivityList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                return View("ActivityAdd", Activity);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ActivityDeleteConfirm(int ActivityNum)
        {
            hra_activity activity = _contentManagementService.GetActivityByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>(), ActivityNum);

            return View("ActivityDelete", activity);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ActivityDelete(hra_activity Activity)
        {
            if (Activity != null)
            {
                _contentManagementService.ActivityDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_activity>>(), Activity);
            }

            return ActivityList();
        }





        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult ActiveGoalsGB([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "Date";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new ActiveGoalParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                userId = MembershipUserID
            };

            List<ActiveGoals> list = _contentManagementService.GetActiveGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<ActiveGoals>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditActiveGoals(int goalNumber)
        {
            hra_goal blrActiveGoalDetails = _contentManagementService.GetActiveGoalsById(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>(), goalNumber);
            return View("ActiveGoalEditor", blrActiveGoalDetails);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult UpdateActiveGoals(int goalNumber, string description, string reason, string introduction, string about_Title, string about_Body, string setGoalHeadding, string setGoalSubHeadding, string diplayText, string toolDisplayMsg, string goalRule, string activeGoal, string goalValue)
        {
            _contentManagementService.UpdateActiveGoals(ServiceLocator.Current.GetInstance<IRepositoryAsync<hra_goal>>(), goalNumber, description, reason, introduction, about_Title, about_Body, setGoalHeadding, setGoalSubHeadding, diplayText, toolDisplayMsg, goalRule, activeGoal, goalValue, MembershipUserID);
            return Json("Success");
        }
        #endregion

        #region Learning Tab Quiz
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult LearningTabQuiz(int? id)
        {
            Session["learningTabId"] = id;
            return View();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult LearningTabQuizGB([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "Date";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new LearningTabQuizParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                userId = MembershipUserID,
                learningTabId = Convert.ToInt32(Session["learningTabId"] == null ? 0 : Session["learningTabId"])
            };

            List<LearningTabQuiz> list = _contentManagementService.GetLearningTabQuiz(ServiceLocator.Current.GetInstance<IRepositoryAsync<LearningTabQuiz>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ShowAddLearningTabQuiz()
        {
            LearningTabQuiz blrLearningTabQuiz = new LearningTabQuiz();

            return View("LearningTabQuizEditor", blrLearningTabQuiz);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult EditLearningTabQuiz(int learningTabQuizId)
        {
            LearningTabQuiz blrLearningTabQuiz = new LearningTabQuiz();
            List<LearningTabQuiz> listBrLearningTabQuiz = _contentManagementService.GetLearningTabQuizById(learningTabQuizId);

            if (listBrLearningTabQuiz.Count > 0)
            {
                blrLearningTabQuiz = listBrLearningTabQuiz[0];
            }
            return View("LearningTabQuizEditor", blrLearningTabQuiz);
        }

        public ActionResult Editing_Read([DataSourceRequest] DataSourceRequest request, List<LearningTabAnswer> list)
        {
            return Json(new DataSourceResult { Data = list });
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult AddEditLearningTabQuiz(int learningTabQuizId, string question, string list, string correctAnswer, string answerExplanation, int? learnTabId)
        {
            IList<LearningTabAnswer> lstAnswers = new JavaScriptSerializer().Deserialize<IList<LearningTabAnswer>>(list);
            _contentManagementService.AddEditLearningTabQuiz(learningTabQuizId, question, lstAnswers, correctAnswer, answerExplanation, learnTabId);
            return Json("Success");
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult ShowSearchLearnTab()
        {
            return PartialView("_SearchLearnTab");
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult LearnTabSearchGB([DataSourceRequest] DataSourceRequest request, string searchText = null)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "Date";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new LearnTabSearchParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                searchText = searchText
            };

            List<LearnTabSearch> list = _contentManagementService.GetLearnTabsBySearchText(ServiceLocator.Current.GetInstance<IRepositoryAsync<LearnTabSearch>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        [HttpPost]
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult DeleteLearningTabQuiz(int learningTabQuizId)
        {
            OperationResult result = new OperationResult();
            //_contentManagementService.DeletetLearnAndEarnTabQuiz(ServiceLocator.Current.GetInstance<IRepositoryAsync<BLR_LEARNING_TAB_QUIZ>>(), learningTabQuizId);
            var spParams = new LearnTabQuizParams
            {
                learningTabQuizId = learningTabQuizId
            };
            _contentManagementService.DeletetLearnAndEarnTabQuiz(ServiceLocator.Current.GetInstance<IRepositoryAsync<LearningTabQuiz>>(), spParams);
            result.Data = new { Message = "Learn and earn deleted successfully." };
            return Json(result);
        }

        #endregion

        #region Upload Documents
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UploadDocuments()
        {
            return View();
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        public ActionResult BlobsDocumentsGB([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            // Retrieve storage account from connection string.
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["DownloadStorageConnectionString"]);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.GetContainerReference("downloads");
            List<CMSBlobFile> list = new List<CMSBlobFile>();
            // Loop over items within the container and output the length and URI.
            foreach (IListBlobItem item in container.ListBlobs(null, false))
            {
                if (item.GetType() == typeof(CloudBlockBlob))
                {
                    CloudBlockBlob blob = (CloudBlockBlob)item;
                    // Console.WriteLine("Block blob of length {0}: {1}", blob.Properties.Length, blob.Uri);
                    CMSBlobFile file = new CMSBlobFile();
                    file.Name = blob.Name;
                    file.Url = Convert.ToString(blob.Uri);
                    file.Size = blob.Properties.Length;
                    list.Add(file);
                }
                //else if (item.GetType() == typeof(CloudPageBlob))
                //{
                //    CloudPageBlob pageBlob = (CloudPageBlob)item;

                //    //Console.WriteLine("Page blob of length {0}: {1}", pageBlob.Properties.Length, pageBlob.Uri);

                //}
                //else if (item.GetType() == typeof(CloudBlobDirectory))
                //{
                //    CloudBlobDirectory directory = (CloudBlobDirectory)item;

                //    //Console.WriteLine("Directory: {0}", directory.Uri);
                //}
            }
            string search = gridUtil.GetWhereClauseXml_Kendo(request.Filters);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list.Count;
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        [HttpPost]
        public ActionResult SaveDocuments(HttpPostedFileBase file)
        {
            if (ModelState.IsValid)
            {
                string filename = string.Empty;
                string filePath = null;

                if (file != null)
                {
                    try
                    {
                        //filename = Guid.NewGuid() + Path.GetExtension(file.FileName);
                        filePath = "https://meschinowellness.blob.core.windows.net/downloads/" + file.FileName;
                        //saving file to destinatinaion folder
                        SaveToDownloadContainer(file.InputStream, filePath);
                        ViewBag.Response = filePath;

                    }
                    catch (Exception ex)
                    {
                        ViewBag.Response = "Error occurs";
                        throw ex;
                    }
                }
                return View("UploadDocuments");
            }
            else
            {
                return View("UploadDocuments");
            }
        }
        #endregion

        //*********************************************************************
        //UOM Types
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMTypeList()
        {
            List<uom_type> UOMTypes = new List<uom_type>();
            UOMTypes = _contentManagementService.GetUOMTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom_type>>());

            return View("UOMTypeList", UOMTypes);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMTypeEdit(int? UOMTypeNum)
        {
            if (UOMTypeNum == null || UOMTypeNum == 0)
            {
                return UOMTypeList();
            }
            else
            {
                CMSUOMType cms = new CMSUOMType();

                cms.UOMType = _contentManagementService.GetUOMTypeByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom_type>>(), UOMTypeNum.GetValueOrDefault());

                return View("UOMTypeEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMTypeSave(CMSUOMType cms)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.UOMTypeUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom_type>>(), cms.UOMType);

                return UOMTypeList();
            }
            else
            {
                var errors = ModelState.Values.SelectMany(m => m.Errors);

                //validation errors have occurred.  Return user to fix errors.
                return UOMTypeEdit(cms.UOMType.uom_type_num);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMTypeAddEdit()
        {
            return View("UOMTypeAdd");
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMTypeAddSave(uom_type UOMType)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.UOMTypeAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom_type>>(), UOMType);

                return UOMTypeList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                CMSUOMType cms = new CMSUOMType();
                cms.UOMType = UOMType;

                return View("UOMTypeAdd", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMTypeDeleteConfirm(int UOMTypeNum)
        {
            CMSUOMType cms = new CMSUOMType();

            cms.UOMType = _contentManagementService.GetUOMTypeByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom_type>>(), UOMTypeNum);

            return View("UOMTypeDelete", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMTypeDelete(uom_type UOMType)
        {
            _contentManagementService.UOMTypeDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom_type>>(), UOMType);

            return UOMTypeList();
        }

        //*********************************************************************
        //UOMs
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMList()
        {
            List<uom> UOMs = new List<uom>();
            UOMs = _contentManagementService.GetUOMs(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>());

            return View("UOMList", UOMs);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMEdit(int? UOMNum)
        {
            if (UOMNum == null || UOMNum == 0)
            {
                return UOMList();
            }
            else
            {
                CMSUOM cms = new CMSUOM();

                cms.UOM = _contentManagementService.GetUOMByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>(), UOMNum.GetValueOrDefault());
                cms.UOMTypeList = _contentManagementService.GetUOMTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom_type>>());

                return View("UOMEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMSave(CMSUOM cms)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.UOMUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>(), cms.UOM);

                return UOMList();
            }
            else
            {
                var errors = ModelState.Values.SelectMany(m => m.Errors);

                //validation errors have occurred.  Return user to fix errors.
                return UOMEdit(cms.UOM.uom_num);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMAddEdit()
        {
            CMSUOM cms = new CMSUOM();

            cms.UOM = new uom();
            cms.UOMTypeList = _contentManagementService.GetUOMTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom_type>>());

            return View("UOMAdd", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMAddSave(uom UOM)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.UOMAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>(), UOM);

                return UOMList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                CMSUOM cms = new CMSUOM();
                cms.UOM = UOM;
                cms.UOMTypeList = _contentManagementService.GetUOMTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom_type>>());

                return View("UOMAdd", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMDeleteConfirm(int UOMNum)
        {
            CMSUOM cms = new CMSUOM();

            cms.UOM = _contentManagementService.GetUOMByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>(), UOMNum);
            cms.UOMTypeList = _contentManagementService.GetUOMTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom_type>>());

            return View("UOMDelete", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UOMDelete(uom UOM)
        {
            _contentManagementService.UOMDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>(), UOM);

            return UOMList();
        }


        //*********************************************************************
        //Metric Categories
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricCategoryList()
        {
            List<metric_category> MetricCategories = new List<metric_category>();
            MetricCategories = _contentManagementService.GetMetricCategories(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_category>>());

            return View("MetricCategoryList", MetricCategories);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricCategoryEdit(int? MetricCategoryNum)
        {
            if (MetricCategoryNum == null || MetricCategoryNum == 0)
            {
                return MetricCategoryList();
            }
            else
            {
                CMSMetricCategory cms = new CMSMetricCategory();

                cms.MetricCategory = _contentManagementService.GetMetricCategoryByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_category>>(), MetricCategoryNum.GetValueOrDefault());

                return View("MetricCategoryEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricCategorySave(CMSMetricCategory cms)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.MetricCategoryUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_category>>(), cms.MetricCategory);

                return MetricCategoryList();
            }
            else
            {
                var errors = ModelState.Values.SelectMany(m => m.Errors);

                //validation errors have occurred.  Return user to fix errors.
                return MetricCategoryEdit(cms.MetricCategory.metric_category_num);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricCategoryAddEdit()
        {
            CMSMetricCategory cms = new CMSMetricCategory();

            cms.MetricCategory = new metric_category();

            return View("MetricCategoryAdd", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricCategoryAddSave(metric_category MetricCategory)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.MetricCategoryAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_category>>(), MetricCategory);

                return MetricCategoryList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                CMSMetricCategory cms = new CMSMetricCategory();
                cms.MetricCategory = MetricCategory;

                return View("MetricCategoryAdd", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricCategoryDeleteConfirm(int MetricCategoryNum)
        {
            CMSMetricCategory cms = new CMSMetricCategory();

            cms.MetricCategory = _contentManagementService.GetMetricCategoryByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_category>>(), MetricCategoryNum);

            return View("MetricCategoryDelete", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricCategoryDelete(metric_category MetricCategory)
        {
            _contentManagementService.MetricCategoryDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_category>>(), MetricCategory);

            return MetricCategoryList();
        }

        //*********************************************************************
        //Metric Sources
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricSourceList()
        {
            List<metric_source> MetricSources = new List<metric_source>();
            MetricSources = _contentManagementService.GetMetricSources(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_source>>());

            return View("MetricSourceList", MetricSources);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricSourceEdit(int? MetricSourceNum)
        {
            if (MetricSourceNum == null || MetricSourceNum == 0)
            {
                return MetricSourceList();
            }
            else
            {
                CMSMetricSource cms = new CMSMetricSource();

                cms.MetricSource = _contentManagementService.GetMetricSourceByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_source>>(), MetricSourceNum.GetValueOrDefault());
                cms.ValidTypes = _contentManagementService.GetMetricTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type>>());
                cms.Types = _contentManagementService.GetMetricSource_Type(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_source_type>>(), MetricSourceNum.GetValueOrDefault());

                return View("MetricSourceEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricSourceSave(CMSMetricSource cms, string[] SelectedTypes)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.MetricSourceUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_source>>(), cms.MetricSource);
                _contentManagementService.MetricSourceUpdateTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_source_type>>(), cms.MetricSource, SelectedTypes);


                return MetricSourceList();
            }
            else
            {
                var errors = ModelState.Values.SelectMany(m => m.Errors);

                //validation errors have occurred.  Return user to fix errors.
                return MetricSourceEdit(cms.MetricSource.metric_source_num);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricSourceAddEdit()
        {
            CMSMetricSource cms = new CMSMetricSource();

            cms.MetricSource = new metric_source();

            return View("MetricSourceAdd", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricSourceAddSave(metric_source MetricSource)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.MetricSourceAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_source>>(), MetricSource);

                return MetricSourceList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                CMSMetricSource cms = new CMSMetricSource();
                cms.MetricSource = MetricSource;

                return View("MetricSourceAdd", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricSourceDeleteConfirm(int MetricSourceNum)
        {
            CMSMetricSource cms = new CMSMetricSource();

            cms.MetricSource = _contentManagementService.GetMetricSourceByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_source>>(), MetricSourceNum);
            cms.HasMatricSourceAlreadyInUse = _contentManagementService.HasMatricSourceBindWithAnotherObject(MetricSourceNum);
            return View("MetricSourceDelete", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricSourceDelete(metric_source MetricSource)
        {
            _contentManagementService.MetricSourceDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_source>>(), MetricSource);

            return MetricSourceList();
        }

        //*********************************************************************
        //Metric Intervals
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricIntervalList()
        {
            List<metric_interval> MetricIntervals = new List<metric_interval>();
            MetricIntervals = _contentManagementService.GetMetricIntervals(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_interval>>());

            return View("MetricIntervalList", MetricIntervals);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricIntervalEdit(int? MetricIntervalNum)
        {
            if (MetricIntervalNum == null || MetricIntervalNum == 0)
            {
                return MetricIntervalList();
            }
            else
            {
                CMSMetricInterval cms = new CMSMetricInterval();

                cms.MetricInterval = _contentManagementService.GetMetricIntervalByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_interval>>(), MetricIntervalNum.GetValueOrDefault());

                return View("MetricIntervalEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricIntervalSave(CMSMetricInterval cms)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.MetricIntervalUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_interval>>(), cms.MetricInterval);

                return MetricIntervalList();
            }
            else
            {
                var errors = ModelState.Values.SelectMany(m => m.Errors);

                //validation errors have occurred.  Return user to fix errors.
                return MetricIntervalEdit(cms.MetricInterval.metric_interval_num);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricIntervalAddEdit()
        {
            CMSMetricInterval cms = new CMSMetricInterval();

            cms.MetricInterval = new metric_interval();

            return View("MetricIntervalAdd", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricIntervalAddSave(metric_interval MetricInterval)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.MetricIntervalAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_interval>>(), MetricInterval);

                return MetricIntervalList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                CMSMetricInterval cms = new CMSMetricInterval();
                cms.MetricInterval = MetricInterval;

                return View("MetricIntervalAdd", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricIntervalDeleteConfirm(int MetricIntervalNum)
        {
            CMSMetricInterval cms = new CMSMetricInterval();

            cms.MetricInterval = _contentManagementService.GetMetricIntervalByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_interval>>(), MetricIntervalNum);

            return View("MetricIntervalDelete", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricIntervalDelete(metric_interval MetricInterval)
        {
            _contentManagementService.MetricIntervalDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_interval>>(), MetricInterval);

            return MetricIntervalList();
        }

        //*********************************************************************
        //Metric Types
        //*********************************************************************
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricTypeList()
        {
            List<metric_type> MetricTypes = new List<metric_type>();
            MetricTypes = _contentManagementService.GetMetricTypes(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type>>());

            return View("MetricTypeList", MetricTypes);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricTypeEdit(int? MetricTypeNum)
        {
            if (MetricTypeNum == null || MetricTypeNum == 0)
            {
                return MetricTypeList();
            }
            else
            {
                CMSMetricType cms = new CMSMetricType();

                cms.MetricType = _contentManagementService.GetMetricTypeByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type>>(), MetricTypeNum.GetValueOrDefault());
                cms.MetricCategoryList = _contentManagementService.GetMetricCategories(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_category>>());
                cms.MetricIntervalList = _contentManagementService.GetMetricIntervals(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_interval>>());
                cms.UOMList = _contentManagementService.GetUOMs(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>());

                cms.ValidExercises = _contentManagementService.GetExercises(ServiceLocator.Current.GetInstance<IRepositoryAsync<DMT_Exercises>>());
                cms.Exercises = _contentManagementService.GetMetricType_Exercises(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type_exercise>>(), MetricTypeNum.GetValueOrDefault());

                return View("MetricTypeEdit", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricTypeSave(CMSMetricType cms, string[] SelectedExercises)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.MetricTypeUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type>>(), cms.MetricType);
                _contentManagementService.MetricTypeUpdateExercises(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type_exercise>>(), cms.MetricType, SelectedExercises);

                return MetricTypeList();
            }
            else
            {
                var errors = ModelState.Values.SelectMany(m => m.Errors);

                //validation errors have occurred.  Return user to fix errors.
                return MetricTypeEdit(cms.MetricType.metric_type_num);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricTypeAddEdit()
        {
            CMSMetricType cms = new CMSMetricType();

            cms.MetricType = new metric_type();
            cms.MetricCategoryList = _contentManagementService.GetMetricCategories(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_category>>());
            cms.MetricIntervalList = _contentManagementService.GetMetricIntervals(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_interval>>());
            cms.UOMList = _contentManagementService.GetUOMs(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>());

            return View("MetricTypeAdd", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricTypeAddSave(metric_type MetricType)
        {
            if (ModelState.IsValid)
            {
                _contentManagementService.MetricTypeAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type>>(), MetricType);

                return MetricTypeList();
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                CMSMetricType cms = new CMSMetricType();
                cms.MetricType = MetricType;
                cms.MetricCategoryList = _contentManagementService.GetMetricCategories(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_category>>());
                cms.MetricIntervalList = _contentManagementService.GetMetricIntervals(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_interval>>());
                cms.UOMList = _contentManagementService.GetUOMs(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>());

                return View("MetricTypeAdd", cms);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricTypeDeleteConfirm(int MetricTypeNum)
        {
            CMSMetricType cms = new CMSMetricType();

            cms.MetricType = _contentManagementService.GetMetricTypeByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type>>(), MetricTypeNum);
            cms.MetricCategoryList = _contentManagementService.GetMetricCategories(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_category>>());
            cms.MetricIntervalList = _contentManagementService.GetMetricIntervals(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_interval>>());
            cms.UOMList = _contentManagementService.GetUOMs(ServiceLocator.Current.GetInstance<IRepositoryAsync<uom>>());

            return View("MetricTypeDelete", cms);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult MetricTypeDelete(metric_type MetricType)
        {
            _contentManagementService.MetricTypeDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<metric_type>>(), MetricType);

            return MetricTypeList();
        }


        #region Network Providers
        public ActionResult NetworkProvider()
        {
            return View();
        }

        [NoCache]
        public ActionResult NetworkProviderGB([Kendo.Mvc.UI.DataSourceRequest] Kendo.Mvc.UI.DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "NetworkProviderName";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new NetworkProviderResultParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                UserId = MembershipUserID
            };

            List<NetworkProviderResult> list = _contentManagementService.GetNetworkProviders(ServiceLocator.Current.GetInstance<IRepositoryAsync<NetworkProviderResult>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows;
            }

            var result = new Kendo.Mvc.UI.DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }

        public ActionResult ShowAddEditNetworkProvider(int? providerId)
        {
            NetworkProvider list = new NetworkProvider();

            if (providerId != null)
            {
                list = _contentManagementService.GetNetworkProviderById(ServiceLocator.Current.GetInstance<IRepositoryAsync<NetworkProvider>>(), (int)providerId);
            }

            return PartialView("_AddEditNetworkProvider", list);
        }

        public ActionResult DeleteNetworkProvider(int providerId)
        {
            OperationResult result = new OperationResult();
            _contentManagementService.DeleteNetworkProvider(ServiceLocator.Current.GetInstance<IRepositoryAsync<NetworkProvider>>(), providerId);

            result.Data = new { Message = "Network Provider deleted successfully." };
            return Json(result);
        }

        public ActionResult AddEditNetworkProvider(NetworkProvider data)
        {
            OperationResult result = new OperationResult();
            _contentManagementService.AddEditNetworkProvider(ServiceLocator.Current.GetInstance<IRepositoryAsync<NetworkProvider>>(), data, MembershipUserID);
            result.Data = new { Message = "Network Provider added successfully." };
            return Json(result);
        }
        #endregion

        #region Food Nutritions
        [NoCache]
        public ActionResult _GetFoodNutritionsList([DataSourceRequest] DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "name";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var searchParam = new FoodSearchParamDefault
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
            };

            List<FoodDetails> list = _dietActivityService.GetFoodNutritionsListForGrid(ServiceLocator.Current.GetInstance<IRepositoryAsync<FoodDetails>>(), searchParam);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows.GetValueOrDefault();
            }

            var result = new DataSourceResult
            {
                Data = list,
                Total = totalRows
            };
            return Json(result);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult UploadFoodNutritions()
        {
            return View(new BulkUploadFoodNutritionsModel());
        }
        [HttpGet]
        public ActionResult SaveBulkUploadFoodNutritions()
        {
            return RedirectToAction("UploadFoodNutritions");
        }

        [HttpPost]
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult SaveBulkUploadFoodNutritions(BulkUploadFoodNutritionsModel model)
        {
            string alert = "<div class='alert alert-danger'>{0}</div>";

            if (ModelState.IsValid)
            {
                if (model.UploadFile != null)
                {
                    StringBuilder strError = new StringBuilder();

                    string location = Server.MapPath("~/Files/BulkUploadFoods/");
                    bool isValidFile = true;
                    string excelConnectionString = string.Empty;
                    //string fileLocation = location + Guid.NewGuid() + "_" + file.FileName;
                    string fileLocation = location + Guid.NewGuid() + "." + Path.GetExtension(model.UploadFile.FileName);

                    if (!System.IO.Directory.Exists(location))
                    {
                        System.IO.Directory.CreateDirectory(location);
                    }

                    // Delete old unwanted bulk upload files.
                    DeleteOldFiles(location);

                    if (_excelService.IsValidFile(model.UploadFile.FileName, fileLocation, out excelConnectionString))
                    {
                        if (System.IO.File.Exists(fileLocation))
                        {
                            System.IO.File.Delete(fileLocation);
                        }

                        model.UploadFile.SaveAs(fileLocation);

                        Dictionary<string, string> dic = new Dictionary<string, string>();
                        string msg = _dietActivityService.ValidateFileHeaders(model.UploadFile, excelConnectionString, out dic);

                        if (!string.IsNullOrEmpty(msg)) { strError.AppendLine(string.Format(alert, msg)); isValidFile = false; }
                        if (dic != null && dic.Count > 0)
                        {
                            isValidFile = false;
                            foreach (KeyValuePair<string, string> k in dic)
                            {
                                strError.AppendLine(string.Format(alert, k.Value));
                            }
                        }
                    }
                    else
                    {
                        strError.AppendLine(string.Format(alert, model.UploadFile.FileName + " is not a valid file."));
                        isValidFile = false;
                    }

                    if (isValidFile)
                    {
                        DataSet dsFinalResult = new DataSet();
                        Dictionary<string, string> dic = _dietActivityService.ProcessFoodFile(model.UploadFile, fileLocation, excelConnectionString, out dsFinalResult);

                        DataTable dtFailedRecords = new DataTable();
                        DataTable dtSuccessRecords = new DataTable();
                        if (dsFinalResult != null && dsFinalResult.Tables.Count > 0)
                        {
                            dtFailedRecords = dsFinalResult.Tables["failed"];
                            dtSuccessRecords = dsFinalResult.Tables["success"];
                        }
                        model.dtFailedRecords = dtFailedRecords;
                        model.dtSuccessRecords = dtSuccessRecords;
                        model.hasUploadDone = true;
                    }
                    else
                    {
                        //TempData["ErrorMessage"] = strError.ToString();
                        model.ErrorMessage = strError.ToString();
                    }
                }
            }
            else
            {
                StringBuilder sbError = new StringBuilder();
                foreach (ModelState modelState in ViewData.ModelState.Values)
                {
                    foreach (ModelError error in modelState.Errors)
                    {
                        sbError.Append(error.ErrorMessage + "<br>");
                    }
                }
                model.ErrorMessage = string.Format(alert, sbError.ToString());
            }
            return View("UploadFoodNutritions", model);
        }

        [HttpGet]
        public FileResult FoodSampleDownload()
        {
            string fileName = "FoodNutritionsFormat.xlsx";
            string fullPath = Path.Combine(Server.MapPath("~/Files/BulkUploadFormat/"), fileName);
            return File(fullPath, "application/vnd.ms-excel", fileName);
        }
        [NoCache]
        public ActionResult ShowAddEditFoodNutritions(int? id)
        {
            FoodNutritionsModel model;
            if (id.HasValue)
            {
                var dbFood = _dietActivityService.GetFoodNutritionsByID(id.Value);
                model = new FoodNutritionsModel
                {
                    id = id.Value,
                    name = dbFood.name,
                    FoodServing = dbFood.serving_size,
                    FoodCalorie = dbFood.calories,
                    FoodFat = dbFood.total_fat,
                    FoodCholesterol = dbFood.cholesterol,
                    FoodCarbs = dbFood.total_carbohydrate,
                    FoodProtein = dbFood.protein
                };
            }
            else
            {
                model = new FoodNutritionsModel();
            }

            return PartialView("_AddEditFoodNutritions", model);
        }

        [HttpPost]
        public ActionResult AddEditFoodNutrition(FoodNutritionsModel model)
        {
            try
            {
                var foodDetail = _dietActivityService.GetFoodNutritions(model.name);
                if (foodDetail != null && foodDetail.id != model.id)
                {
                    return Json(new OperationResult() { Status = OperationStatus.SUCCESS, Data = new { Message = "This Food already exists." } });
                }

                FoodDetailsInsertUpdate foodNutritions = new FoodDetailsInsertUpdate
                {
                    id = model.id,
                    calories = model.FoodCalorie,
                    cholesterol = model.FoodCholesterol,
                    name = model.name,
                    protein = model.FoodProtein,
                    serving_size = model.FoodServing,
                    total_carbohydrate = model.FoodCarbs,
                    total_fat = model.FoodFat,
                    action = model.id > 0 ? "UPDATE" : "ADD",

                };
                _contentManagementService.AddEditFoodNutritions(foodNutritions);

                //if (userService.IsOnboardCertificateDateOfBirthExists(userProfile.Email, userProfile.DateofBirth.Value, userProfile.ID, userProfile.FirstName))
                //{
                //    throw new Exception(ErrorMessageConstants.CERTIFICATE_DATEOFBIRTH_ALREADY_EXISTS);
                //}

                //if (!string.IsNullOrEmpty(userProfile.Email) && userService.IsOnboardUserEmailExists(userProfile.Email, userProfile.ID))
                //{
                //    throw new Exception(ErrorMessageConstants.EMAIL_ALREADY_EXISTS);
                //}

                //string parentUserId = IsBillable ? null : ParentUserId;
                //userProfile.CompanyId = userProfile.CompanyId.HasValue ? userProfile.CompanyId.Value : LoggerInUserCompanyId;

                //userService.AddEditUserProfile(userProfile, MembershipUserID, IsBillable, parentUserId, CompanyName);

                return Json(new OperationResult() { Status = OperationStatus.SUCCESS, Data = new { Message = "Successfully Saved" } });
            }
            catch (Exception ex)
            {
                return Json(new OperationResult() { Status = OperationStatus.ERROR, ErrorMessage = ex.InnerException != null ? ex.InnerException.Message : ex.Message });
            }
        }
        public ActionResult DeleteFoodNutritions(string ID)
        {
            try
            {
                OperationResult result = new OperationResult();
                int id = 0;
                int.TryParse(ID, out id);
                _contentManagementService.DeleteFoodNutritions(id);

                result.Data = new { Message = "Food Nutrition deleted successfully." };
                return Json(result);
            }
            catch (Exception ex)
            {
                OperationResult result = new OperationResult();
                result.Data = new { Message = ex.Message.ToString() };
                return Json(result);
            }
        }

        private void DeleteOldFiles(string location)
        {
            if (System.IO.Directory.Exists(location))
            {
                DirectoryInfo info = new DirectoryInfo(location);
                FileInfo[] files = info.GetFiles().Where(o => o.CreationTime <= DateTime.Now.AddDays(-1)).ToArray();
                foreach (FileInfo file in files)
                {
                    file.Delete();
                }
            }
        }

        public ActionResult NutritionManager()
        {
            return View();
        }
        [NoCache]
        public ActionResult NutritionManagerGB([Kendo.Mvc.UI.DataSourceRequest] Kendo.Mvc.UI.DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "SpecificHealthRisk";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new NutritionManagerResultParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                UserId = MembershipUserID
            };

            List<NutritionManagerResult> list = _contentManagementService.GetNutritionManagerInfos(ServiceLocator.Current.GetInstance<IRepositoryAsync<NutritionManagerResult>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows;
            }

            var result = new Kendo.Mvc.UI.DataSourceResult
            {
                Data = list,
                Total = totalRows
            };
            Session["requestInfo"] = null;
            return Json(result);
        }
        public ActionResult NutritionManagerVideo()
        {
            return View();
        }

        [NoCache]
        public ActionResult NutritionManagerVideosGB([Kendo.Mvc.UI.DataSourceRequest] Kendo.Mvc.UI.DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "SubHeading";
            string sortOrder = "ASC";

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }

            var pageCriteria = new NutritionManagerVideoResultParams
            {
                StartInd = request.PageSize * (request.Page - 1) + 1,
                EndInd = request.PageSize * request.Page,
                PageSize = request.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(request.Filters),
                UserId = MembershipUserID
            };

            List<NutritionManagerVideoResult> list = _contentManagementService.GetNutritionManagerVideos(ServiceLocator.Current.GetInstance<IRepositoryAsync<NutritionManagerVideoResult>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows;
            }

            var result = new Kendo.Mvc.UI.DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }
        public ActionResult DeleteNutritionManagerVideo(string name)
        {
            OperationResult result = new OperationResult();
            result.Data = new { Message = "Video removed successfully." };
            return Json(result);

        }
        public ActionResult AddNMVideo(int? id)
        {
            CMSNutritionManager cms = new CMSNutritionManager();
            if (id != null)
            {
                var list = _contentManagementService.GetNMFoodDetails(ServiceLocator.Current.GetInstance<IRepositoryAsync<NM_FoodList>>(), Convert.ToInt32(id));
                cms.FoodItem = list.Where(q => q.Id == id).FirstOrDefault();
                cms.SubFoodItems = list.Where(q => q.MainFoodItemId == id).ToList();
            }

            if (cms.FoodItem == null)
                cms.FoodItem = new NM_FoodList();
            if (cms.SubFoodItems == null)
                cms.SubFoodItems = new List<NM_FoodList>();

            ViewData["VideoList"] = GetNMBlobFileList();
            return View(cms);
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult NutritionManagerAddSave(CMSNutritionManager cms)
        {
            if (ModelState.IsValid)
            {
                string specificHealthRisk = string.Empty;
                if (Session["SpecificHealthRisk"] != null)
                    specificHealthRisk = Session["SpecificHealthRisk"].ToString();
                _contentManagementService.AddUpdateNMFoods(ServiceLocator.Current.GetInstance<IRepositoryAsync<NM_FoodList>>(), cms, specificHealthRisk, base.MembershipUserID);
                return RedirectToAction("FoodManagement", "ContentManagement", new { id = Session["SpecificHealthRisk"].ToString() });
            }
            else
            {
                var errors = ModelState.Values.SelectMany(m => m.Errors);

                return AddNMVideo(cms.FoodItem.Id);
            }
        }
        public ActionResult FoodManagement(string id, bool isClear = false)
        {
            Session["SpecificHealthRisk"] = id;
            ViewBag.SubPage = id;
            if (isClear)
                Session["requestInfo"] = null;
            return View();
        }
        [NoCache]
        public ActionResult FoodManagementsGB([Kendo.Mvc.UI.DataSourceRequest] Kendo.Mvc.UI.DataSourceRequest request)
        {
            var gridUtil = new GridUtil();
            string sortColumn = "SubHeading";
            string sortOrder = "ASC";
            Kendo.Mvc.UI.DataSourceRequest filterRequest = null;

            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }
            if (Session["requestInfo"] == null)
            {
                Session["requestInfo"] = request;
                filterRequest = request;
            }
            else
            {
                filterRequest = (Kendo.Mvc.UI.DataSourceRequest)Session["requestInfo"];
                if (request.Filters.Count > 0 && filterRequest != request)
                {
                    filterRequest = request;
                    Session["requestInfo"] = filterRequest;
                }
            }

            var pageCriteria = new NMFoodItemsResultParams
            {
                StartInd = filterRequest.PageSize * (filterRequest.Page - 1) + 1,
                EndInd = filterRequest.PageSize * filterRequest.Page,
                PageSize = filterRequest.PageSize,
                SortOrder = sortOrder,
                SortColumn = sortColumn,
                WhereClauseXML = gridUtil.GetWhereClauseXml_Kendo(filterRequest.Filters),
                UserId = MembershipUserID,
                SpecificHealthRisk = Convert.ToString(Session["SpecificHealthRisk"])
            };

            List<NMFoodItemsResult> list = _contentManagementService.GetNutritionManagerFoodItems(ServiceLocator.Current.GetInstance<IRepositoryAsync<NMFoodItemsResult>>(), pageCriteria);

            int totalRows = 0;
            if (list.Count > 0)
            {
                totalRows = list[0].TotalRows;
            }

            var result = new Kendo.Mvc.UI.DataSourceResult
            {
                Data = list,
                Total = totalRows
            };

            return Json(result);
        }
        public ActionResult AddVideo()
        {
            ViewData["BlobVideoList"] = GetNMBlobFileList();
            return View();
        }
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [NoCache]
        [HttpPost]
        public string UploadsNMVideos(string fileName)
        {
            string msg = string.Empty;
            string filename = string.Empty;
            string filePath = null;
            for (int i = 0; i < Request.Files.Count; i++)
            {
                var file = Request.Files[i];
                var title = fileName + Path.GetExtension(file.FileName);
                try
                {
                    filePath = "https://meschinowellness.blob.core.windows.net/nutritionmanagervideos/" + title;
                    //saving file to destinatinaion folder
                    SaveToDownloadContainer(file.InputStream, filePath);
                    msg = filePath;
                }
                catch (Exception ex)
                {
                    msg = "Error occurs";
                    throw ex;
                }
            }

            return msg;
        }

        #endregion

        #region Checcklist
        //Checcklist Categorys
        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult CheckList()
        {
            List<ChecklistCategory> ChecklistCategorys = new List<ChecklistCategory>();
            ChecklistCategorys = _contentManagementService.GetCheckListCategorys(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistCategory>>());

            return View("CheckList", ChecklistCategorys);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult SubCategoryList(long Id)
        {
            if (Id == 0)
            {
                return CheckList();
            }
            else
            {
                List<ChecklistSubCategory> ChecklistSubCategorys = new List<ChecklistSubCategory>();
                ChecklistSubCategorys = _contentManagementService.GetCheckListSubCategorys(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistSubCategory>>(), Id);

                return View("SubCategoryList", ChecklistSubCategorys);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult SubCategoryEdit(long? Id)
        {
            if (Id == null || Id == 0)
            {
                return SubCategoryList((long)CheckListCategory.Drinks);
            }
            else
            {
                ChecklistSubCategory subCategory = _contentManagementService.GetChecklistSubCategoryByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistSubCategory>>(), Id.GetValueOrDefault());
                subCategory.ChecklistCategoryList = _contentManagementService.GetCheckListCategorys(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistCategory>>());

                var WeeklyGoallist = new SelectList(new[] 
                       {
                           new { WeeklyGoalID = 1, WeeklyGoal = 1 },
                           new { WeeklyGoalID = 2, WeeklyGoal = 2 },
                           new { WeeklyGoalID = 3, WeeklyGoal = 3 },
                           new { WeeklyGoalID = 4, WeeklyGoal = 4 },
                           new { WeeklyGoalID = 5, WeeklyGoal = 5 },
                           new { WeeklyGoalID = 6, WeeklyGoal = 6 },
                           new { WeeklyGoalID = 7, WeeklyGoal = 7 },
                       },
                           "WeeklyGoalID", "WeeklyGoal", subCategory.WeeklyGoal);

                ViewData["WeeklyGoallist"] = WeeklyGoallist;
                ViewData["VideoList"] = GetNMBlobFileList();

                return View("SubCategoryEdit", subCategory);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult SubCategorySave(ChecklistSubCategory subCategory)
        {
            bool result = _contentManagementService.CheckIsSubCategoryNameMatchINChecklist(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistSubCategory>>(), subCategory.CategoryId, subCategory.Name, subCategory.Id);

            if (ModelState.IsValid && !result)
            {
                _contentManagementService.ChecklistSubCategoryUpdate(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistSubCategory>>(), subCategory);

                return SubCategoryList(subCategory.CategoryId);
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                ViewBag.IsSubCategoryNameMatch = true;
                subCategory.ChecklistCategoryList = _contentManagementService.GetCheckListCategorys(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistCategory>>());

                var WeeklyGoallist = new SelectList(new[] 
                       {
                           new { WeeklyGoalID = 1, WeeklyGoal = 1 },
                           new { WeeklyGoalID = 2, WeeklyGoal = 2 },
                           new { WeeklyGoalID = 3, WeeklyGoal = 3 },
                           new { WeeklyGoalID = 4, WeeklyGoal = 4 },
                           new { WeeklyGoalID = 5, WeeklyGoal = 5 },
                           new { WeeklyGoalID = 6, WeeklyGoal = 6 },
                           new { WeeklyGoalID = 7, WeeklyGoal = 7 },
                       },
                           "WeeklyGoalID", "WeeklyGoal", subCategory.WeeklyGoal);

                ViewData["WeeklyGoallist"] = WeeklyGoallist;
                ViewData["VideoList"] = GetNMBlobFileList();
                return View("SubCategoryEdit", subCategory);
            }
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult SubCategoryAdd()
        {
            ChecklistSubCategory subCategory = new ChecklistSubCategory();
            subCategory.ChecklistCategoryList = _contentManagementService.GetCheckListCategorys(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistCategory>>());

            var WeeklyGoallist = new SelectList(new[] 
                       {
                           new { WeeklyGoalID = 1, WeeklyGoal = 1 },
                           new { WeeklyGoalID = 2, WeeklyGoal = 2 },
                           new { WeeklyGoalID = 3, WeeklyGoal = 3 },
                           new { WeeklyGoalID = 4, WeeklyGoal = 4 },
                           new { WeeklyGoalID = 5, WeeklyGoal = 5 },
                           new { WeeklyGoalID = 6, WeeklyGoal = 6 },
                           new { WeeklyGoalID = 7, WeeklyGoal = 7 },
                       },
                       "WeeklyGoalID", "WeeklyGoal", 1);

            ViewData["WeeklyGoallist"] = WeeklyGoallist;
            ViewData["VideoList"] = GetNMBlobFileList();
            return View("SubCategoryAdd", subCategory);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        [ValidateInput(false)]
        public ActionResult SubCategoryAddSave(ChecklistSubCategory subCategory)
        {
            bool result = _contentManagementService.CheckIsSubCategoryNameMatchINChecklist(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistSubCategory>>(), subCategory.CategoryId, subCategory.Name, subCategory.Id);

            if (ModelState.IsValid && !result)
            {
                _contentManagementService.ChecklistSubCategoryAdd(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistSubCategory>>(), subCategory);

                return SubCategoryList(subCategory.CategoryId);
            }
            else
            {
                //validation errors have occurred.  Return user to fix errors.
                ViewBag.IsSubCategoryNameMatch = true;
                subCategory.ChecklistCategoryList = _contentManagementService.GetCheckListCategorys(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistCategory>>());

                var WeeklyGoallist = new SelectList(new[] 
                       {
                           new { WeeklyGoalID = 1, WeeklyGoal = 1 },
                           new { WeeklyGoalID = 2, WeeklyGoal = 2 },
                           new { WeeklyGoalID = 3, WeeklyGoal = 3 },
                           new { WeeklyGoalID = 4, WeeklyGoal = 4 },
                           new { WeeklyGoalID = 5, WeeklyGoal = 5 },
                           new { WeeklyGoalID = 6, WeeklyGoal = 6 },
                           new { WeeklyGoalID = 7, WeeklyGoal = 7 },
                       },
                           "WeeklyGoalID", "WeeklyGoal", 1);

                ViewData["WeeklyGoallist"] = WeeklyGoallist;
                ViewData["VideoList"] = GetNMBlobFileList();
                return View("SubCategoryAdd", subCategory);
            }

        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        public ActionResult SubCategoryDeleteConfirm(long? Id)
        {
            ChecklistSubCategory subCategory = _contentManagementService.GetChecklistSubCategoryByID(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistSubCategory>>(), Id.GetValueOrDefault());

            return View("SubCategoryDelete", subCategory);
        }

        [Authorize(Roles = ApplicationRole.ADMIN + "," + ApplicationRole.CONTENTMANAGEMENT + "," + ApplicationRole.SYSADMIN)]
        //[ValidateInput(false)]
        public ActionResult SubCategoryDelete(ChecklistSubCategory subCategory)
        {
            if (subCategory != null)
            {
                _contentManagementService.ChecklistSubCategoryDelete(ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistSubCategory>>(), ServiceLocator.Current.GetInstance<IRepositoryAsync<ChecklistGoal>>(), ServiceLocator.Current.GetInstance<IRepositoryAsync<DailyChecklist>>(), subCategory);
            }

            return SubCategoryList(subCategory.CategoryId);
        }
        #endregion
    }
}