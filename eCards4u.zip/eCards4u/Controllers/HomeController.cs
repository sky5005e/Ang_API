﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using PdfSharp.Pdf.IO;
using PdfSharp.Pdf.Advanced;
using PdfToImage;
using System.Configuration;
using System.Net.Mail;



namespace GreetingCards.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Test()
        {
            return View();
        }
        public ActionResult Index()
        {

            return View();
        }
        public string Upload(HttpPostedFileBase fileData)
        {

            var filename = this.Server.MapPath("~/uploads/" + fileData.FileName);

            fileData.SaveAs(filename);
            string res = "../../Uploads/" + fileData.FileName;
            return res;
        }
        public string UploadPdf(HttpPostedFileBase fileData)
        {
            var filename = this.Server.MapPath("~/uploads/" + fileData.FileName);

            fileData.SaveAs(filename);
            string file = DateTime.Now.Ticks.ToString();
            string res = "../../Uploads/" + file + ".jpeg";
            
           
            PdfToImage.PDFConvert pp = new PDFConvert();
            pp.OutputFormat = "jpeg"; //format
            pp.JPEGQuality = 100; //100% quality
            pp.ResolutionX = 300; //dpi
            pp.ResolutionY = 300;
            pp.FirstPageToConvert = 1; //pages you want
            
            pp.LastPageToConvert = 1;
            
            pp.Convert(filename, this.Server.MapPath("~/uploads/" + file + ".jpeg" ));
            return res;
           
        }

        public ActionResult DownloadImg()
        {
            string fileNameWitPath = Session["File"].ToString();
            string filename = Session["fileName"].ToString();
            if (Session["Type"].ToString() == "Pdf")
            {

                string file = DateTime.Now.Ticks.ToString() + ".pdf";
                string source = fileNameWitPath;
                string destinaton = Server.MapPath("~/uploads/" + file);

                PdfDocument doc = new PdfDocument();
                doc.Pages.Add(new PdfPage());
                XGraphics xgr = XGraphics.FromPdfPage(doc.Pages[0]);
                XImage img = XImage.FromFile(source);

                xgr.DrawImage(img, 0, 0);
                doc.Save(destinaton);
                doc.Close();
                fileNameWitPath = destinaton;
            }
            return File(fileNameWitPath, "image/png", Path.GetFileName(fileNameWitPath));

           


        }
        public ActionResult Email()
        {
            string fileNameWitPath = Session["File"].ToString();
            string filename =  Session["fileName"].ToString();
            try
            {
                var fromAddress = "surendar.yadav@indianic.com";// your email address.
                // any address where the email will be sending
                var toAddress = Session["toAddress"].ToString();// To whom you want to send ur email
                //Password of your gmail address
                string fromPassword = "Surendar!2345";// ur email password
                // Passing the values and make a email formate to display
                string subject = "Warm Wishes";
                string body = string.Empty;
                body += "Delicious and delightful, a gift basket from Warm Wishes is the perfect gift for family, friends, coworkers, favorite customers or vendors.";
                body += "Whether you prefer something whimsical or something elegant, your gift basket from Warm Wishes will stand out from the crowd. <br/><br/>";

                //Set Conformation Button
                string buttonText = "<br/><br/>";
                buttonText += "<table style='font-size: 12px; font-family: Arial, Helvetica, sans-serif; line-height: 17px;color: #666' width='100%' border='0'>";
                buttonText += "<tr>";
                buttonText += "<td>";
                //buttonText += "<a href='" + ConfigurationSettings.AppSettings["siteurl"] + "admin/CommunicationCenter/DelMyShoppingCart.aspx?DateTimeSpan=" + DateTime.Now + "&UserinfoID=" + 1092 + "'><img src='" + ConfigurationSettings.AppSettings["siteurl"] + "Images/dlt_items_btn.png' alt='Delete items' border='0'/></a>";
                buttonText += "<td>";
                buttonText += "</tr>";
                buttonText += "</table>";
                body += buttonText;

                body += "<br/><br/> Thanks & Regards";

                SendEmail(fromAddress, fromPassword, toAddress, subject, body, true, fileNameWitPath,filename);
            }
            catch (Exception ex)
            {

            }
            return View();
        }
       
        public JsonResult DownloadImage(string imagedata)
        {
            string path = this.Server.MapPath("~/uploads/");
            string file = DateTime.Now.Ticks.ToString() + ".png";
            string fileNameWitPath = path + file;

            using (FileStream fs = new FileStream(fileNameWitPath, FileMode.Create))
            {
                using (BinaryWriter bw = new BinaryWriter(fs))
                {
                    //string imagedata = Request.QueryString["id"].ToString();
                    byte[] data = Convert.FromBase64String(imagedata);
                    bw.Write(data);
                    bw.Close();
                }
            }


            string res = "../../Uploads/" + file;
            Session["File"] = fileNameWitPath;
            Session["fileName"] = file;
            return Json(new { Success = true, Result = res }, JsonRequestBehavior.AllowGet);
        }

        public string GetTemplates()
        {
            string[] filePaths = Directory.GetFiles(this.Server.MapPath("~/Templates/"));
            string numToRemove = "D:\\Nilam\\GreetingCards\\GreetingCards\\Templates\\Thumbs.db";
            filePaths = filePaths.Where(val => val != numToRemove).ToArray();
            string res = "<table>";
            for (int i = 0; i <= filePaths.Length - 1; i=i+5)
            {
                res += "<tr>";
                try {
                    for (int j = 0; j <= 4; j++)
                    {
                        string[] fileary = filePaths[i+j].Split('\\');
                        string filename = fileary[fileary.Length - 1];
                        res += "<td>" + "<img src='../../Templates/" + filename + "' onclick='GetImage(this.src);' height=100 width=100 /></td><td style='width:15px'></td>";
                    }
                }
                catch {
                    break;
                }
                res += "</tr>";
            }
            return res;
        }

        public JsonResult SetType(string DType)
        {
            Session["Type"] = DType;

            return Json(new { Success = true }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SettoAddress(string toAddress)
        {
            Session["toAddress"] = toAddress;

            return Json(new { Success = true }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult TextStyle()
        {
            return View();
        }
        public ActionResult TextUI()
        {
            
            Session["Type"] = "Image";

            return View();
        }

       
        public static void SendEmail(String FromAddress, String Password, String ToAddress, string subject, string message, bool isHtml,string Path, string filename)
        {
            var mail = new MailMessage();
            var mailclient = new SmtpClient();


            //
            // Set the to and from addresses.
            // The from address must be your GMail account
            mail.From = new MailAddress(FromAddress);
            mail.To.Add(new MailAddress(ToAddress));
            mail.Headers.Add("Disposition-Notification-To", "skysurendar@gmail.com");

            mail.ReplyTo = new MailAddress("skysurendar@gmail.com");
            mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

            mailclient.DeliveryMethod = SmtpDeliveryMethod.Network;

            mail.Headers.Add("Return-Path", "skysurendar@gmail.com");
            mail.Headers.Add("Disposition-Notification-To", "<skysurendar@gmail.com>");
            // Define the message
            mail.Subject = subject;
            mail.IsBodyHtml = isHtml;
            mail.Body = message;

            // Create a new Smpt Client using Google's servers
            // var mailclient = new SmtpClient();
            mailclient.Host = "smtp.gmail.com";//ForGmail
            mailclient.Port = 25; //ForGmail

            mailclient.EnableSsl = true;//ForGmail
            //mailclient.EnableSsl = false;
            mailclient.UseDefaultCredentials = true;

            Attachment objAttach = new Attachment(Path);
            System.Net.Mime.ContentDisposition obj = objAttach.ContentDisposition;
            obj.FileName = DateTime.Now.ToString()+filename;
            mail.Attachments.Add(objAttach);
            // Specify your authentication details
            mailclient.Credentials = new System.Net.NetworkCredential(FromAddress, Password);//ForGmail

            try
            {
                //IMail em = mail.s;
                mailclient.Send(mail);
            }
            catch (SmtpFailedRecipientsException ex)
            {
                for (int i = 0; i < ex.InnerExceptions.Length; i++)
                {
                    SmtpStatusCode status = ex.InnerExceptions[i].StatusCode;
                    if (status == SmtpStatusCode.MailboxBusy || status == SmtpStatusCode.MailboxUnavailable)
                    {
                        // Console.WriteLine("Delivery failed - retrying in 5 seconds.");
                        System.Threading.Thread.Sleep(5000);
                        mailclient.Send(mail);
                    }
                    else
                    {
                        //  Console.WriteLine("Failed to deliver message to {0}", ex.InnerExceptions[i].FailedRecipient);
                        throw ex;
                    }
                }
            }
            catch (Exception ex)
            {
                //  Console.WriteLine("Exception caught in RetryIfBusy(): {0}",ex.ToString());
                throw ex;
            }


        }
        
    }
}
