// Allow touch/swipe events on bootstrap carousel
$(".carousel").on("touchstart", function(event){
    var touchX = event.originalEvent.touches[0].pageX;
$(this).one("touchmove", function(event){
    var xCoord = event.originalEvent.touches[0].pageX;
    if( Math.floor(touchX - xCoord) > 5 ){
        $(".carousel").carousel('next');
    }
    else if( Math.floor(touchX - xCoord) < -5 ){
        $(".carousel").carousel('prev');
    }
});
$(".carousel").on("touchend", function(){
        $(this).off("touchmove");
});
});

$('.panel-title a').on('click', function(){
    $(this).toggleClass('open');
});

$('.compass-faq').on('click', function(){
    $('body').toggleClass('no-overflow-mob');
    $('.center-wrapper').toggleClass('right-aside-open');
   $('.right-aside').toggleClass('open');
   var h = $(".center-wrapper").height();
   $(".right-aside").height(h);
});
$('.dash-nav li').on('mouseenter', function(){
    debugger;
    $(this).closest('.dash-nav').addClass('overflow');
});

$('.dash-nav li').on('mouseleave', function(){
    debugger;
    $(this).closest('.dash-nav').removeClass('overflow');
});

$(function() {
    var h = $(".center-wrapper").height();
    $(".right-aside").height(h);
  });

        
   
