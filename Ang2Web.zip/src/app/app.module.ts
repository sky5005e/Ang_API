import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { FormsModule }   from '@angular/forms';
import {CommonService} from './_services/commonservice';
import{routing} from './app.routing';
import { HttpModule } from '@angular/http';
import {HomeComponent} from './home.component';
import { Ng2DatetimePickerModule } from 'ng2-datetime-picker';
import {NgxPaginationModule} from 'ngx-pagination';
import { LoginComponent } from './login/login.component';
import { AuthGuardService} from './_services/auth-guard.service';
import {AuthService} from './_services/auth.service';
import { LogoutComponent } from './logout/logout.component';
import { RecaptchaModule } from 'ng2-recaptcha';
import { ChooseLoginComponent } from './login/choose-login/choose-login.component';
import { ResgisteruserComponent } from './login/resgisteruser/resgisteruser.component';
import { UnresgisteruserComponent } from './login/unresgisteruser/unresgisteruser.component';
import {DatePickerModule} from 'angular-io-datepicker';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    LogoutComponent,
    ChooseLoginComponent,
    ResgisteruserComponent,
    UnresgisteruserComponent,
 
  ],
  imports: [
    BrowserModule,FormsModule,routing,
    HttpModule ,Ng2DatetimePickerModule,
    NgxPaginationModule,DatePickerModule,
    RecaptchaModule.forRoot(),

  ],
  providers: [CommonService,AuthGuardService,AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
