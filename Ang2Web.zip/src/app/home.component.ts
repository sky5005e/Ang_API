import { Component } from "@angular/core";

@Component({
   templateUrl:'./home.component.html',
     styleUrls:[
              ]

  
})

export class HomeComponent {
}