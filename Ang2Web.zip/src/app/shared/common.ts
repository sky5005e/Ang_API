export class Common
{
   public static FormatTimeIn12Hours (time,ShowSeconds=true) {
        try
        {
        if(time==null || time==undefined)
        {
            return "";
        }
        else{
         time.slice(1);
         var FinalTime="";
         time = time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];
         if (time.length > 1) { // If time format correct
             var time2=time[0].split(':');
             if(parseInt(time2[0])==0 && parseInt(time2[1])==0 && parseInt(time2[2])==0)
             {
             return "";
             }
             FinalTime=(time2[0] % 12 || 12).toString()+":"+time2[1].toString();
             if(ShowSeconds==true)
             FinalTime=FinalTime +":"+time2[2].toString();
             FinalTime=FinalTime+" "+(time2[0] < 12 ? ' AM' : ' PM').toString();
             return FinalTime;
         }
         else
         {
             return time.join (''); // return adjusted time or original string
         }
         
      }
     }
     catch(ex)
     {
     return "";
     }
     
   }
}