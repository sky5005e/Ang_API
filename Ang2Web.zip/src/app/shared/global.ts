export class Global
{
    public static BaseUrl: string = 'http://localhost:52092/api/';
    public static ImageUrl: string = 'http://localhost:52092/';
    public static LoginUrl: string = 'http://localhost/Compass.Portal.Security.API/api/';

}