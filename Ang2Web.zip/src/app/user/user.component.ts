import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
    selector: 'app-site',
    templateUrl:'./user.component.html',
    //  styleUrls:['../../assets/css/bootstrap.min.css',              
    //            '../../assets/css/compass.css',
    //            '../../assets/css/ie10-viewport-bug-workaround.css',
    //            '../../assets/css/icomoon.css'  
    //           ]

})


export class UserComponent implements OnInit {

    constructor(private Route:Router) { }

    ngOnInit() {
       
    }

}
