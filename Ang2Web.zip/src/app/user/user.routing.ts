import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { UserComponent } from './user.component';
import { AuthGuardService } from '../_services/auth-guard.service';

export const routes: Routes = [
    {
        path: '',
        component: UserComponent,
        children: [         

     

        {
            path:"Support",
            loadChildren:'./usersupport/usersupport.module#UserSupportModule'
        },

        ]
    }
];
export const routing: ModuleWithProviders = RouterModule.forChild(routes);