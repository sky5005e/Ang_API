
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-site',
    template:`<router-outlet></router-outlet>`
    
})
export class SupportComponent implements OnInit {
    constructor() { }
    ngOnInit() {
    }

}

