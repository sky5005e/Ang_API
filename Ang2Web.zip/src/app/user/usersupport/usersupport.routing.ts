import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import {SupportComponent} from './usersupport.component';
import { AddComponent } from './add/add.component';
import {SupportreferenceComponent} from './supportreference/supportreference.component';
export const routes: Routes = [
    {
        path: '',
        component: SupportComponent,
        children: [
         
            {
                path: 'Add',
                component: AddComponent
            },
          {
                path: 'SupportReference',
                component: SupportreferenceComponent
            },

          


        ]
    }
];
export const routing = RouterModule.forChild(routes);