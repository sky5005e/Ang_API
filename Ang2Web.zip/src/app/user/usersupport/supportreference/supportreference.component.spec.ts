import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportreferenceComponent } from './supportreference.component';

describe('SupportreferenceComponent', () => {
  let component: SupportreferenceComponent;
  let fixture: ComponentFixture<SupportreferenceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupportreferenceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupportreferenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
