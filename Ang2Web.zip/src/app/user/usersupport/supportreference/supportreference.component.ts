import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supportreference',
  templateUrl: './supportreference.component.html',
  styleUrls: ['./supportreference.component.css']
})
export class SupportreferenceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
