import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { CommonService } from "../../../_services/CommonService";
import { Global } from "../../../Shared/global";
import {UserSupportInput} from "../models/UserSuppportInput";
import {ProjectDetail} from "../models/ProjectDetail";
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css'], 
  providers:[CommonService]
})
export class AddComponent implements OnInit {
  FirstStep:Boolean=false;
  SecondStep:Boolean=true;
  ThirdStep:Boolean=true;
  Input=new UserSupportInput();
  ProjectDetail=new ProjectDetail();
 constructor(private Service:CommonService){}
   ngOnInit(){
  this.ProjectRefrence();

   }
    ProjectRefrence()
   {
     this.Service.get(Global.BaseUrl+"ProjectRefrence/RefrenceList").subscribe((res)=>this.Input.ProductSector=res);
   }
 ApplicationName(ProjectRefrenceId:number)
 {
   debugger;
   this.Service.get(Global.BaseUrl+"ProjectRefrence/ProjectDetail/"+ProjectRefrenceId).subscribe((res)=>this.Input.ApplicationList=res)
  debugger;
 }


ShowSecondDiv()
{
  
  this.GetClientLevel();
  
}
 ShowThirdDiv()
 {
   this.SecondStep=!this.SecondStep;
   this.ThirdStep=!this.ThirdStep;
 }
 
 HideSecondDiv()
 {
   this.FirstStep=false;
   this.SecondStep=true;
 }

  
  GetSelectedProject(ProjectId)
  {
   this.ProjectDetail.ProjectId=ProjectId;
   this.Input.ProjectId=ProjectId;
    var lights = document.getElementsByClassName("SelectedProjectActive");
     while (lights.length)
    lights[0].classList.remove("SelectedProjectActive");
    document.getElementById(ProjectId).className += "SelectedProjectActive";
  }

  GetProjectDetail()
  {
    this.Service.post(Global.BaseUrl+"UserSupport/ProjectDetail",this.ProjectDetail).subscribe((res)=>{
      this.ProjectDetail=res,
      this.ProjectDetail.LogoUrl=Global.ImageUrl+this.ProjectDetail.LogoUrl
    });
  }
  GetClientLevel()
  {
    this.Service.get(Global.BaseUrl+"Support/Level").subscribe((res)=>{this.Input.LevelList=res,
  this.FirstStep=!this.FirstStep;
  this.SecondStep=!this.SecondStep;})
  }

  AddSupport()
  {
    debugger;
    this.Input.IsUserGeneratedSupport=true;
  //   this.Service.post(Global.BaseUrl+"Support/AddSupportByUser",this.Input).subscribe((res)=>
  //   {this.Input.TokenNumber=res,
     
  //     this.ShowThirdDiv()
  //   }
  //   );
  this.ShowThirdDiv();
   }
  
   

  
}
