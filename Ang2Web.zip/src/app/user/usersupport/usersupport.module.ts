import {NgModule} from "@angular/core";
import { APP_BASE_HREF } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {routing} from './usersupport.routing';
import {AddComponent} from './add/add.component';
import {NgxPaginationModule} from 'ngx-pagination';
import {SupportComponent} from './usersupport.component';
import { Ng2DatetimePickerModule } from 'ng2-datetime-picker';
import { RecaptchaModule } from 'ng2-recaptcha';
import { SupportreferenceComponent } from './supportreference/supportreference.component';
import {DatePickerModule} from 'angular-io-datepicker';

@NgModule({
   imports:[HttpModule,
    RouterModule,
    FormsModule,
    routing,
    CommonModule,
    NgxPaginationModule,
    Ng2DatetimePickerModule,
    RecaptchaModule,
    DatePickerModule
 
],
   declarations:[SupportComponent,AddComponent, SupportreferenceComponent] 
})
export class UserSupportModule{}