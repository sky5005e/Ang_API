export class UserSupportInput
{
    public ProjectId:number;
    public ProductSector:[any];
    public LocationList:[any];
    public ApplicationList:[any];
    public ImageUrl:string;
    public LocationId:number;
    public Level:number;
    public LevelList:[any];
    public ContactName:string;
    public PhoneNumber:string;
    public EmailAddress:string;
    public AlternativeContactName:string;
    public AlternativePhoneNumber:string;
    public AlternativeEmailAddress:string;
    public DateOfIssue:Date;
    public TimeOfIssue:string;
    public Issue:string;
    public StepToReproduce:string;
    public TokenNumber:string;
    public IsUserGeneratedSupport:boolean;
    public ProjectRefernceId:number;
}