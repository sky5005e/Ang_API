export class ProjectDetail
{
        public  ProjectId :number;

        public  LogoUrl :string;

        public  LocationList :[any]
}