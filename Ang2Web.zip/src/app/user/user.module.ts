import { NgModule } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { routing } from './user.routing';
import { UserComponent } from './user.component';
@NgModule({
    imports: [CommonModule, routing, FormsModule, ReactiveFormsModule, HttpModule,RouterModule],
    declarations: [UserComponent],
    providers:[]
})

export class UserModule { }