import { Component } from '@angular/core';
import * as $ from 'jquery';
@Component({
   selector: 'user-app',
   templateUrl:'./app.component.html'
  

                
  
})
export class AppComponent  {
  title = 'app';
  
}
