export class Paging 
{
   public PageNumber:Number;
   public  RecordPerPage:10;
}