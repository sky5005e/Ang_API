import { Project } from "../model/Project";
import {ProjectDetail} from "../model/ProjectDetail";
import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { CommonService } from "../../../_services/commonservice";
import { Global } from "../../../Shared/global";
import { BrowserModule } from '@angular/platform-browser';
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html'

})
export class DetailComponent implements OnInit {
    ProjectId: number;
    Project = new Project();
    ProjectStatus = [];
    Status = [];
     IsSiteDivOn: boolean = true;
     IsSupportDivOn: boolean = false;
     CommentsOn: boolean = false;
     AssociatedDivOn: boolean = false;        
     AuditDivOn: boolean = false;
     ShowMasterRefrence : boolean = false;
    ProjectDetail=new ProjectDetail();
    ProjectSupportList:[any];
    ProjectSiteList:[any];
    constructor(private Route: Router, private ProjectService: CommonService, private ActivatedRoute: ActivatedRoute) { }
    ngOnInit(): void
    {
        this.ProjectId = this.ActivatedRoute.snapshot.params['id'];
        this.GetDropDown();
        this.GetProjectSite();
        
    }

    Get(): void
    {
    this.ProjectService.get(Global.BaseUrl + "Project/Get/" + this.ProjectId).subscribe((res) => {this.ProjectDetail = res,
    this.Project.ProjectName=this.ProjectDetail.ProjectName;
    this.Project.Status=this.ProjectDetail.Status;
    this.Project.ProjectStatus=this.ProjectDetail.ProjectStatus;
    this.Project.ProjectReference=this.ProjectDetail.ProjectReference;
    this.Project.IndustrySector=this.ProjectDetail.IndustrySector;
    this.Project.LocationId=this.ProjectDetail.LocationId;
    this.Project.MainContactId=this.ProjectDetail.MainContactId;
    this.Project.ProjectManager=this.ProjectDetail.ProjectManager;
    this.Project.StartDate=this.ProjectDetail.StartDate;
    this.Project.CloseDate=this.ProjectDetail.CloseDate;
    this.Project.CurrentVersion=this.ProjectDetail.CurrentVersion;
    this.Project.RemoteAccess=this.ProjectDetail.RemoteAccess;
    this.Project.RemoteAccessContactCode=this.ProjectDetail.RemoteAccessContactCode;
    this.Project.RemoteAccessDate=this.ProjectDetail.RemoteAccessDate;
     if(this.Project.MainContactId)
        {
         this.ShowMasterRefrence=true; 

        }
   });
        
    }

    Put(): void
    {
        this.ProjectService.put(Global.BaseUrl + "Project/Put", this.Project).subscribe((res) => { this.Route.navigate(['ProjectList'])});
       ;
    }

    GetStatus() {
        this.ProjectService.get(Global.BaseUrl + "Project/GetStatus").subscribe((Res) => {this.Status = Res,this.GetProjectStatus()});
    }
    GetProjectStatus() {
        this.ProjectService.get(Global.BaseUrl + "Project/ProjectStatus").subscribe((Res) => {this.ProjectStatus = Res,this.Get()});
    }
    GetAuditTrail() {
        this.ProjectService.get(Global.BaseUrl + "Project/AuditDetail/" + this.ProjectId).subscribe((res) => this.Project.AuditDetailList = res);
    }
    ProjectList()
    {
        this.Route.navigate(['/Admin/Project/List']);
    }
     ShowSitesDiv()
    {
        if (!this.IsSiteDivOn)
        {
            this.IsSiteDivOn = !this.IsSiteDivOn;
            this.IsSupportDivOn = false;
            this.CommentsOn  = false;
            this.AssociatedDivOn  = false;
            this.AuditDivOn  = false;  
            this.GetProjectSite();
        }
    }
    ShowSupportDiv()
    {
        if (!this.IsSupportDivOn){
            this.IsSiteDivOn = false;
            this.IsSupportDivOn = !this.IsSupportDivOn;
            this.CommentsOn = false;
            this.AssociatedDivOn = false;
            this.AuditDivOn = false; 
            this.GetSupportList();
        }
        
    }
    ShowCommentsDiv()
    {
        if (!this.CommentsOn)
        {
            this.IsSiteDivOn = false;
            this.IsSupportDivOn = false;
            this.CommentsOn = !this.CommentsOn;
            this.AssociatedDivOn = false;
            this.AuditDivOn = false; 
        }     
    }

    ShowAssociatedFilesDiv()
    {
        if (!this.AssociatedDivOn)
        {
            this.IsSiteDivOn = false;
            this.IsSupportDivOn = false;
            this.CommentsOn = false;
            this.AssociatedDivOn = !this.AssociatedDivOn;
            this.AuditDivOn = false; 
        }   

    }

    ShowAuditTrialDiv()
    {
        if (!this.AuditDivOn)
        {
            this.IsSiteDivOn = false;
            this.IsSupportDivOn = false;
            this.CommentsOn = false;
            this.AssociatedDivOn = false;
            this.AuditDivOn = !this.AuditDivOn;
            this.GetAuditTrail();
        }  
    }
 AddSite()
 {
     this.Route.navigate(['Admin/ProjectSite/Add',this.ProjectId]);
 }
GetContact(Id: number)
    {
        this.ProjectService.get(Global.BaseUrl + "Project/ContactList/" + Id).subscribe((res) => this.Project.ContactList = res);
    }
 GetDropDown()
    {
        this.ProjectService.get(Global.BaseUrl + "Project/DropDown").subscribe((res) => {this.Project = res,this.GetStatus()});
    }
 AddProjectSupport()
 {     
     this.Route.navigate(['/Admin/Project/AddProjectSupport/',this.ProjectId]);
 }
    GetSupportList()
    {
        this.ProjectService.get(Global.BaseUrl+"Project/ProjectSupportDetail/"+this.ProjectId).subscribe((res)=>this.ProjectSupportList=res);
    }
     ShowMasterRefrenceDiv(e) {
        if (e.target.checked) {
            this.ShowMasterRefrence = !this.ShowMasterRefrence;
            this.GetProjecMasterRefrence();

        }
        else {
            this.ShowMasterRefrence = false;
        }
     }
     GetProjecMasterRefrence()
    {
        this.ProjectService.get(Global.BaseUrl + "Support/Project").subscribe((res) => this.Project.MasterRefrence = res);
           
    }

    GetProjectSite()
    {
     this.ProjectService.get(Global.BaseUrl+"ProjectSite/ProjectSite/"+this.ProjectId).subscribe((res)=>this.ProjectSiteList=res);
    }

}