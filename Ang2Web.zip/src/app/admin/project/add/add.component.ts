import { Component, OnInit } from '@angular/core';
import { Project } from "../model/Project";
import { CommonService } from "../../../_services/commonservice";
import { Routes, RouterModule, Router } from '@angular/router';
import { Global } from "../../../Shared/global";
import { BrowserModule } from '@angular/platform-browser';
import { Headers, RequestOptions } from "@angular/http";
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html'

})
export class AddComponent implements OnInit {

constructor(private Route: Router, private Service: CommonService) { }
    Project = new Project();
    ProjectStatus=[];
    Status = [];
     IsSiteDivOn: boolean = true;
     IsSupportDivOn: boolean = false;
     CommentsOn: boolean = false;
     AssociatedDivOn: boolean = false;        
     AuditDivOn: boolean = false;
     ShowMasterRefrence : boolean = false;
     file: File;
  ngOnInit() {
     
        this.GetStatus();
        this.GetProjectStatus();
  }
    ShowSitesDiv()
    {
        if (!this.IsSiteDivOn)
        {
            this.IsSiteDivOn = !this.IsSiteDivOn;
            this.IsSupportDivOn = false;
            this.CommentsOn  = false;
            this.AssociatedDivOn  = false;
            this.AuditDivOn  = false;  
        }
    }
    ShowSupportDiv()
    {
        if (!this.IsSupportDivOn){
            this.IsSiteDivOn = false;
            this.IsSupportDivOn = !this.IsSupportDivOn;
            this.CommentsOn = false;
            this.AssociatedDivOn = false;
            this.AuditDivOn = false; 
        }
        
    }
    ShowCommentsDiv()
    {
        if (!this.CommentsOn)
        {
            this.IsSiteDivOn = false;
            this.IsSupportDivOn = false;
            this.CommentsOn = !this.CommentsOn;
            this.AssociatedDivOn = false;
            this.AuditDivOn = false; 
        }     
    }

    ShowAssociatedFilesDiv()
    {
        if (!this.AssociatedDivOn)
        {
            this.IsSiteDivOn = false;
            this.IsSupportDivOn = false;
            this.CommentsOn = false;
            this.AssociatedDivOn = !this.AssociatedDivOn;
            this.AuditDivOn = false; 
        }   

    }

    ShowAuditTrialDiv()
    {
        if (!this.AuditDivOn)
        {
            this.IsSiteDivOn = false;
            this.IsSupportDivOn = false;
            this.CommentsOn = false;
            this.AssociatedDivOn = false;
            this.AuditDivOn = !this.AuditDivOn;
            this.GetAuditTrail();
        }  
    }
 
    SaveProject(): void
    {
        let formData: FormData = new FormData();
        formData.append("model", JSON.stringify(this.Project));
        if (this.file != null)
            formData.append("file", this.file, this.file.name);
        let headers = new Headers();
        let options = new RequestOptions({ headers: headers });
        this.Service.PostImage(Global.BaseUrl + "Project/NewProjectWithFile", formData, options)
            .subscribe((res) => { this.Route.navigate(['/Admin/Project/List'])});

        
    }

    GetStatus()
    {
        this.Service.get(Global.BaseUrl + "Project/GetStatus").subscribe((Res) => { this.Status = Res, this.GetDropDown() });
    }
    GetProjectStatus()
    {
        this.Service.get(Global.BaseUrl + "Project/ProjectStatus").subscribe((Res) => this.ProjectStatus = Res);
    }

    GetDropDown()
    {
        this.Service.get(Global.BaseUrl + "Project/DropDown").subscribe((res) => {this.Project = res,this.GetProjectRefrence()});
    }
    GetAuditTrail() {
        this.Service.get(Global.BaseUrl + "Project/AuditDetail/0").subscribe((res) => this.Project.AuditDetailList = res);
    }

    ShowMasterRefrenceDiv(e) {
        if (e.target.checked) {
            this.ShowMasterRefrence = !this.ShowMasterRefrence;
            this.GetProjecMasterRefrence();

        }
        else {
            this.ShowMasterRefrence = false;
        }
     }

    GetProjecMasterRefrence()
    {
        this.Service.get(Global.BaseUrl + "Support/Project").subscribe((res) => this.Project.MasterRefrence = res);
           
    }
    fileChange(event:any)
    {
        let fileList: FileList = event.target.files;
        if (fileList.length>0)
        {
            this.file = fileList[0];
        }
    }

    AddAssociatedFile(Id: number)
    {
        this.Route.navigate(['/NewAssociatedFile', Id])
    }

    GetContact(Id: number)
    {
        this.Service.get(Global.BaseUrl + "Project/ContactList/" + Id).subscribe((res) => this.Project.ContactList = res);
    }

    AddSite()
    {        
        this.Route.navigate(['/Admin/ProjectSite/Add', 1]);
    }
    AddSupport()
    {
        this.Route.navigate(['/Admin/Support/Add']);
    }

    GetProjectRefrence()
    {
        debugger;
        this.Service.get(Global.BaseUrl+"Project/ProjectRefrence").subscribe((res)=>this.Project.ProjectReferenceList=res);
       
    }
}
