import { Component, OnInit } from "@angular/core";
import { Routes,  Router } from "@angular/router";
import { Project} from "../model/Project";
import { ProjectFilter } from "../model/ProjectFilter";
import { CommonService } from "../../../_services/CommonService";
import { Global } from "../../../Shared/global";
import {Paging} from '../../../Common/Paging';
@Component({
  selector: 'app-list',
  providers:[CommonService],
  templateUrl: './list.component.html'

})
export class ListComponent implements OnInit {

   constructor(private Route: Router, private ProjectService: CommonService) { }
    Project= new Project();
    ProjectObject = new Project();
    ProjectFilter = new ProjectFilter();
    Paging =new Paging();
    ngOnInit(): void
    {
        this.GetList();
    }

    GetList(PageNumber:Number=0): void
    {
        this.Paging.PageNumber=PageNumber;
        this.ProjectService.post(Global.BaseUrl + "Project/ProjectList",this.Paging).subscribe((res) => { this.Project = res, this.GetFilterDropDown() });
    }
    EditProject(id: number):void
    {
        this.Route.navigate(['Admin/Project/Detail', id]);
    }

    DeleteProject(id: number): void
    {
        this.ProjectService.delete(Global.BaseUrl + "Project/Delete" + id).subscribe((res) => this.Project = res);
        window.location.reload();
    }
    SearchProject(): void
    {
        this.ProjectService.get(Global.BaseUrl + "Project/ProjectDetail/" + this.ProjectObject.ProjectId).subscribe((res) => this.Project = res);
    }
    CancelSearch(): void
    {
        this.ProjectObject.ProjectId = null;
    }
    ProjectFilters(): void
    {
        this.ProjectService.post(Global.BaseUrl + "Project/Filter", this.ProjectFilter).subscribe((res) => this.Project = res);
    }

    GetFilterDropDown()
    {
        this.ProjectService.get(Global.BaseUrl + "Project/FilterDropDown").subscribe((res) => this.ProjectFilter = res);
    }
    ResetProjectFilters()
    {
        this.ProjectFilter.SelectedLocation = '';
        this.ProjectFilter.SelectedSector = '';
        this.ProjectFilter.SelectedStatus = null;
        this.ProjectFilter.Title = null;
    }
    SingleProjectDetail(Id:Number)
    {
        this.Route.navigate(['/Admin/Project/Detail',Id])
    }
}
