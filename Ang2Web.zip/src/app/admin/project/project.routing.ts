import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import {ProjectComponent} from './project.component';
import {ListComponent } from './list/list.component';
import {AddComponent} from './add/add.component';
import { DetailComponent } from './detail/detail.component';
import {AddprojectsupportComponent} from './addprojectsupport/addprojectsupport.component'
export const routes: Routes = [
    {
        path: '',
        component: ProjectComponent,
        children: [

            {
                path: 'Add',
                component: AddComponent
            },
          
{
                path: 'List',
                component: ListComponent
            },
            {
                path:'Detail/:id',
                component:DetailComponent
            },
            {
                path:'AddProjectSupport/:id',
                component:AddprojectsupportComponent
            },

        ]
    }
];
export const routing: ModuleWithProviders = RouterModule.forChild(routes);