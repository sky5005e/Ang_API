﻿export class Project
{
  
    public ProjectId: number;
    public Status: string;
    public ProjectStatus: string
    public ProjectReference:number;    
    public ProjectMasterReference: string;    
    public IndustrySector: string;    
    public ProjectName: string;   
    public LocationId: string;
    public MainContactId: number;    
    public ProjectManager: string; 
    public StartDate: Date;
    public CloseDate: Date;
    public CurrentVersion: string;    
    public Comments: string;   
    public RemoteAccess: string;    
    public RemoteAccessContactCode: string;
    public RemoteAccessDate?: Date;
    public LocationList: [any];
    public ProjectManagerList: [any];
    public IndustrySectorList: [any];
    public AuditDetailList: [any];
    public MasterRefrence: [any];
    public ContactList: [any];
    public StatusList: [any];
    public List:[any];
    public TotalRecord:number;
    public ProjectReferenceList:[any];
    public LogoUrl:string;
    
}