export class  SingleProjectDetail
{
public  ProjectId :number;
public  CurrentVersion :string;       
public  ProjectReference :string;     
public  ProductName :string;
public  LocationName :string;
public  Phone :string;
public LocationId:number;
}