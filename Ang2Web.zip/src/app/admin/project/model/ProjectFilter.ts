﻿export class ProjectFilter
{
    public SelectedStatus: number;
    public SelectedLocation: string;
    public SelectedSector: string;
    public Title: string;
    public StatusList: [any];
    public IndustrySectorList: [any];
    public LocationList: [any];
    
}