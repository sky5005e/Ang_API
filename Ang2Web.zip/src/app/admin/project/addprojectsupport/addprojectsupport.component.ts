import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute} from '@angular/router';
import {CommonService} from '../../../_services/commonservice';
import {Global}from '../../../shared/global';
import {Support} from '../../support/model/Support';
import {SingleProjectDetail} from '../model/SingleProjectDetail';
import {Headers,Response,RequestOptions} from "@angular/http";
@Component({
  selector: 'app-addprojectsupport',
  templateUrl: './addprojectsupport.component.html'
})
export class AddprojectsupportComponent implements OnInit {
     ProjectId:number;
     IsProgressOn: boolean = true;
     IsResolutionOn: boolean = false;
     IsAssociatedFileOn: boolean = false;
     IsAuditTrialOn: boolean = false;            
    location: Location;
    fileList: FileList;
    file: File;
    displayDate :string = new Date().toLocaleString();
    Model = new Support();
    ProjectDetail=new SingleProjectDetail();

  constructor(private Router:Router,private ActivatedRoute:ActivatedRoute,private Service:CommonService) { }

  ngOnInit() {
    this.ProjectId=this.ActivatedRoute.snapshot.params['id'];
    this.GetAllocated();
  }
  ShowProgressDiv()
    {
        if (this.IsProgressOn)
        { 
            this.IsProgressOn = this.IsProgressOn;
            this.IsResolutionOn = false;
            this.IsAssociatedFileOn = false;
            this.IsAuditTrialOn = false;
        }
        else{
            this.IsProgressOn = !this.IsProgressOn;
            this.IsResolutionOn = false;
            this.IsAssociatedFileOn = false;
            this.IsAuditTrialOn = false;
        }
      
    }
    ShowResolutionDiv()
    {
        this.IsProgressOn = false;
        this.IsResolutionOn = !this.IsResolutionOn;
        this.IsAssociatedFileOn = false;
        this.IsAuditTrialOn = false;
        this.GetSupportType();
    }
    ShowAssociatedFileDiv()
    {
        this.IsProgressOn = false;
        this.IsResolutionOn = false;
        this.IsAssociatedFileOn = !this.IsResolutionOn;
        this.IsAuditTrialOn = false;
    }
    ShowAuditTrialDiv()
    {
        this.IsProgressOn = false;
        this.IsResolutionOn = false;
        this.IsAssociatedFileOn = false;
        this.IsAuditTrialOn = !this.IsAssociatedFileOn;
        this.GetAuditDetail();
    }
    Line()
    {
        this.Model.SupportAction = this.Model.SupportAction != null ? this.Model.SupportAction + "\n" + this.displayDate : this.displayDate;
       
    }
    Chasedphone()
    {
        var text = "-Chased the client via the phone.";
        this.Model.SupportAction = this.Model.SupportAction != null ? this.Model.SupportAction + "\n" + this.displayDate + text : this.displayDate + text;
    }
    ChasedEmail()
    {
        var text = " -Chased the client via email.";
        this.Model.SupportAction = this.Model.SupportAction != null ? this.Model.SupportAction + "\n" + this.displayDate + text : this.displayDate + text;
    }
    Project(): void
    {
        this.Service.get(Global.BaseUrl + "Support/Project").subscribe((res) => this.Model.Project = res);
    }
    Level(): void
    {
        this.Service.get(Global.BaseUrl + "Support/Level").subscribe((res) => {this.Model.Level = res,this.Getstatus()})
    }
    GetProjectVersion(Id: number)
    {
        if (Id==0)
        {
            this.Model.Version = null;
            this.Model.Phone = null;
            this.Model.Product = null;
        }
        else {
            for (let i = 0; i < this.Model.Project.length; i++) {
                if (this.Model.Project[i].ProjectId == Id) {
                    this.Model.Version = this.Model.Project[i].Version;
                    this.Model.Phone = this.Model.Project[i].Phone;
                    this.Model.LocationId = this.Model.Project[i].LocationId;
                }
            }
            this.GetProductName(Id);
        }
    }
    GetProductName(Id:number):void
    {
        this.Service.get(Global.BaseUrl + "Product/Name/" + Id).subscribe((res) => this.Model.Product = res);
    }
    AddHour()
    {
        this.Model.ManHoursActual = this.Model.ManHoursActual == null ? 0.25 : this.Model.ManHoursActual + 0.25;
    }
          GetSupportType()
    {
        this.Service.get(Global.BaseUrl + "Support/SupportType").subscribe((res) => this.Model.SupportTypeList = res);
    }
    GetAuditDetail()
    {
        this.Service.get(Global.BaseUrl + "Support/AuditDetail/"+this.ProjectId).subscribe((res) => this.Model.AuditDetailList = res);
    }
     GetSupportSubType(Id:number)
    {
        if(Id!=0)
            {
        this.Service.get(Global.BaseUrl + "Support/SupportSubType/" + Id).subscribe((res) => this.Model.SupportSubTypeList = res);
    }
    else
        {
        this.Model.SupportSubTypeList=null;
        }
    }
   GetFaq()
    {
        this.Router.navigate(['/Admin/Support/Faq/List']);
    }  
  GetProjectDetail()
    {
        this.Service.get(Global.BaseUrl+"/Project/SingleProjectDetail/"+this.ProjectId).subscribe((res)=>
        {
            
            this.ProjectDetail=res,
            this.Model.ProjectId=this.ProjectId,
            this.Model.Product=this.ProjectDetail.ProductName;
            this.Model.LocationId=this.ProjectDetail.LocationId;
             this.Model.Version=this.ProjectDetail.CurrentVersion;
             this.Model.Phone=this.ProjectDetail.Phone;             
             
        });

    }
    GetAllocated()
    {      
        this.Service.get(Global.BaseUrl + "Operator/Name").subscribe((res) =>
        {
            this.Model.AllocatedList = res,
            this.Model.TakenByList = res,
         this.GetProjectDetail();
          this.Level();   
        });      
        
    }
    Getstatus()
    {
        this.Service.get(Global.BaseUrl +"Support/GetStatus").subscribe((res) => this.Model.StatusList = res);
    }
    fileChange(event: any): void {
        debugger;
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            this.file = fileList[0];
           
        }
    }
 Save() {
            
            let formData: FormData = new FormData();
            formData.append("model", JSON.stringify(this.Model));
            if (this.file)
                formData.append('uploadFile', this.file, this.file.name);
            let headers = new Headers();
            let options = new RequestOptions({ headers: headers });
            this.Service.PostImage(Global.BaseUrl + "Support/UploadFile", formData, options)
                .subscribe((res) => { this.Router.navigate(['Admin/Project/Detail',this.ProjectId]) });
           
        
      
    }
            TextAppend()
            {
                
            }

}
