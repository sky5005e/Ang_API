
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-site',
    templateUrl: './project.component.html',
    
})
export class ProjectComponent implements OnInit {
    constructor() { }
    ngOnInit() {
    }

}

