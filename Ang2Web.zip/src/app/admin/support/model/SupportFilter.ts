﻿export class SupportFilter
{
    public SelectedCallStatus: string;
    public SelectedAllocated: string;
    public SelectedDateAfter: Date;
    public SelectedDateBefore: Date;
    public SelectedIndustrySector: string;
    public SelectedLevel: string;
    public SelectedTakenFrom: string;
    public SelectedClosedAfter: Date;
    public SelectedClosedBefore: Date;
    public SelectedResponseibilty: string;

}