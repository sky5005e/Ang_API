﻿
export class SupportList
{

     SupportList:[any];
     TotalRecord:number;
    
}