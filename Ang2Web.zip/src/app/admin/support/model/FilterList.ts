﻿export class Filter
{
    ProjectName: [filterItem];
    CallStatus = [];
    AllocatedTo = [];
    IndustrySector = [];
    DateAfter = [];
    DateBefore = [];
    Level = [];
    TakenFrom = [];
    ClosedAfter = [];
    ClosedBefore = [];
    Responseibilty = [];
   
}

export class filterItem
{
    public Text: string;
    public Value: string;
}
