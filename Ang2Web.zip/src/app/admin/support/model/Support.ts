﻿
export class Support {
    public SupportId: number;
    public SupportStatus: string;
    public Status: string;
    public ProjectId: number;
    public Version: string;
    public AllocatedTo: string;
    public TakenBy: string;
    public LocationId: number;
    public TakenFrom: string;
    public DateTaken: Date;
    public TimeTaken: Date;
    public Phone: string;
    public DateResolved: Date;
    public TimeResolved: Date;
    public Details: string;
    public AreaAffected: string;
    public Resolution: string;
    public ManHoursActual: number;
    public SupportLevel: string;
    public SupportAction: string;
    public SupportTypeCode: string;
    public ClosedBy: string;
    public SupportSubTypeCode: string;
    public CallResponsibility: string;
    public CurrentlyOpenBy: string;
    public HicomOnly: boolean;
    public FixDate: Date;
    public FixBy: string;
    public FixTime: Date;
    public ClientLevel: string;
    public LevelReported: string;
    public DateEscalated: Date;
    public TimeEscalated: Date;
    public DateOpened: Date;
    public TimeOpened: Date;
    public ResponseHours: number;
    public TakenFromEmail: string;
    public TFSPBI: number;
    public TimeToOpen: number;
    public TimeToEscalate: number;
    public TimeToFix: number;
    public TimeToFirstResponce: number;
    public TFSVersion: string;
    public TFSRelease: Date;
    public TFSAdded: Date;
    public SupportTypeId: number;
    public SupportSubTypeId: number;
    public FirstResponseDate: Date;
    public FirstResponseTime: Date;
    public Product: string;
    public StatusList: [any];
    public SupportTypeList: [any];
    public SupportSubTypeList: [any];
    public LocationList: [any];
    public Project: [any];
    public Level: [any];
    public AllocatedList: [any]; 
    public TakenByList: [any];
    public AuditDetailList: [any];
   public StrTimeOpened:string
 public StrFirstResponseTime:string;
 public StrTimeEscalated:string;
 public StrTimeResolved:string;
 public StrFixTime:string;
}


