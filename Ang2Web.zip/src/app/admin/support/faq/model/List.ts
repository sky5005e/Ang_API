﻿export class List
{
    public FaqId: number;
    public Title: string;
    public Cause: string;
 
}