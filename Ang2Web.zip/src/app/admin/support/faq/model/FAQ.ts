﻿export class FAQ
{
    public FAQId: number;
    public Status: string;
    public Type: string;
    public InSystem: string;
    public ErrorNumber: number;
    public Title: string;
    public PartOfSystemAffected: string;
    public Cause: string;
    public Resolution: string;
    public TimesUsed: number;
    public SupportSubType: string;
    public Priority: string;
    public ClientPriority: string;
    public FAQEmailSubject: string;
    public FAQEmailBody: string;
    public LinkedFilePath: string;
    public SupportTypeList: [any];
    public SubSupportTypeList: [any];
    public PriorityLevelList: [any]
}