import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonService } from '../../../../_services/commonservice';
import { Global } from '../../../../Shared/global';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { List } from '../model/List';
import {Paging} from '../../../../Common/Paging';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html'

})
export class ListComponent implements OnInit {
 Faqs: List[] = [];
    Paging =new  Paging ();
  constructor(private Service: CommonService, private Router: Router) { }

  ngOnInit() {
      debugger;
      this.GetFaqList();
  }

 GetFaqList()
    {
        this.Service.get(Global.BaseUrl + "Faq/FaqList").subscribe((res) => this.Faqs = res);
    }
    ViewFaq(Id:number)
    {
        this.Router.navigate(['Admin/Support/Faq/Detail',Id]);
    }
}
