import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import {AddComponent} from './add/add.component';
import {FaqComponent} from './faq.component';
import {ListComponent} from './list/list.component';
import {DetailComponent} from './detail/detail.component';
export const routes: Routes = [
    {
        path: '',
        component: FaqComponent,
        children: [
         
            {
                path: 'Add',
                component: AddComponent
            },
          {
                path: 'List',
                component: ListComponent
            },

            {
                path:'Detail/:id',
                component:DetailComponent
            },
             


        ]
    }
];
export const routing = RouterModule.forChild(routes);