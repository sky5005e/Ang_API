import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonService } from '../../../../_services/commonservice';
import { Global } from '../../../../Shared/global';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FAQ } from '../model/FAQ';
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html'
})
export class DetailComponent implements OnInit {
    FaqId: number;
    Model = new FAQ();
  constructor(private Service: CommonService, private Route: Router, private ActivatedRoute: ActivatedRoute) { }

  ngOnInit() {
      this.FaqId = this.ActivatedRoute.snapshot.params['id']
        this.GetFaqDetail();
  }
    GetFaqDetail() {
        return this.Service.get(Global.BaseUrl + "faq/Get/" + this.FaqId).subscribe((res) => { this.Model = res, this.GetSupportType() });
        
    }
    GetSupportType()
    {
        this.Service.get(Global.BaseUrl + "Support/SupportType").subscribe((res) => { this.Model.SupportTypeList = res, this.GetSubSupportType() });
    }
    GetSubSupportType()
    {
        this.Service.get(Global.BaseUrl + "Support/SupportSubType/" + this.Model.Type).subscribe((res) => { this.Model.SubSupportTypeList = res, this.GetPriorityLevel() });
    }
    GetPriorityLevel()
    {
        this.Service.get(Global.BaseUrl + "Faq/PriorityLevel").subscribe((res) => this.Model.PriorityLevelList = res);
    }

    UpdateFaq()
    {
        this.Service.put(Global.BaseUrl + "faq/Put", this.Model).subscribe((res) => { this.Route.navigateByUrl('Admin/Support/Faq/List') });
    }
     GetSupportSubType(Id: number) {
         debugger;
        if (Id!=0)
        {
            this.Service.get(Global.BaseUrl + "Support/SupportSubType/" + Id).subscribe((res) => { this.Model.SubSupportTypeList = res });
        }
        else {
            this.Model.SupportSubType = null;

        }
    }
}
