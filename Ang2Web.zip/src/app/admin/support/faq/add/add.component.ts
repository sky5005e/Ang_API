import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonService } from '../../../../_services/commonservice';
import { Global } from '../../../../Shared/global';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { FAQ } from '../model/FAQ';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html'

})
export class AddComponent implements OnInit {
Model = new FAQ();
  constructor(private Service: CommonService, private Router: Router) { }

  ngOnInit() {
     this.GetSupportType();
        this.GetPriorityLevel();
  }
    Save()
    {
        this.Service.post(Global.BaseUrl + "faq/Post", this.Model).subscribe((res) => { this.Router.navigate(['Admin/Support/Faq/List'])});
    }
    GetSupportType() {
        this.Service.get(Global.BaseUrl + "Support/SupportType").subscribe((res) => { this.Model.SupportTypeList =res });
    }
     GetSupportSubType(Id: number) {
        if (Id!=0)
        {
            this.Service.get(Global.BaseUrl + "Support/SupportSubType/" + Id).subscribe((res) => { this.Model.SubSupportTypeList = res });
        }
        else {
            this.Model.SupportSubType = null;

        }
    }
    GetPriorityLevel() {
        this.Service.get(Global.BaseUrl + "Faq/PriorityLevel").subscribe((res) => this.Model.PriorityLevelList = res);
    }
}
