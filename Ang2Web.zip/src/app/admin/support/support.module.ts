import { NgModule } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {AddComponent} from './add/add.component';
import {SupportComponent} from './support.component';
import {DetailComponent} from './detail/detail.component';
import{ListComponent} from './list/list.component';
import {routing} from './support.routing';
import { Ng2DatetimePickerModule } from 'ng2-datetime-picker';
import {NgxPaginationModule} from 'ngx-pagination';
import {DatePickerModule} from 'angular-io-datepicker';

@NgModule({
    imports: [CommonModule , FormsModule, ReactiveFormsModule, HttpModule,RouterModule,routing,
        Ng2DatetimePickerModule,NgxPaginationModule,DatePickerModule],
    declarations: [SupportComponent,ListComponent,AddComponent, DetailComponent]
})
export class SupportModule { }