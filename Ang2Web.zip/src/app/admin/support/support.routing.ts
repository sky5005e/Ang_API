import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import {AddComponent} from './add/add.component';
import {SupportComponent} from './support.component';
import {ListComponent} from './list/list.component';
import {DetailComponent} from './detail/detail.component';
import {FaqComponent} from './faq/faq.component';
import { AuthGuardService } from '../../_services/auth-guard.service';
export const routes: Routes = [
    {
        path: '',
        component: SupportComponent,
        canActivate:[AuthGuardService],
        children: [
         
            {
                path: 'Add',
                component: AddComponent
            },
          {
                path: 'List',
                component: ListComponent
            },

            {
                path:'Detail/:id',
                component:DetailComponent
            },
             {
                path:'Faq',
                loadChildren:'./faq/faq.module#FaqModule'
            }


        ]
    }
];
export const routing = RouterModule.forChild(routes);