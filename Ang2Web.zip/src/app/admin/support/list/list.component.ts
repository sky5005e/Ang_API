import { Component, OnInit } from '@angular/core';
import { Support } from '../model/Support';
import { SupportList } from '../model/SupportList';
import { CommonService } from '../../../_services/commonservice';
import { Global } from '../../../Shared/global';
import { Routes, RouterModule, Router } from '@angular/router';
import { SupportFilter } from '../model/SupportFilter';
import { Filter } from '../model/FilterList';
import { NgForm } from '@angular/forms';
import {Paging} from '../../../Common/Paging';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',

})
export class ListComponent implements OnInit {
    SupportObject =new SupportList();
    Support= new Support();
    Isdelete: boolean;
    msg: string;
    Filter = new SupportFilter();
    Filters = new Filter();
    Paging =new  Paging ();
  constructor(private Supportservice: CommonService, private router: Router) { }

  ngOnInit() {
        this.SupportList(0);
        this.GetFilterDropdown();
  }
       SupportList(Page:Number): void {  
           this.Paging.PageNumber=Page;
            this.Supportservice.post(Global.BaseUrl + "Support/SupportList",this.Paging).subscribe(
            res => { this.SupportObject = res},
            error => { this.msg = <any>error },
        );
       
        
    }

    SingleSupport(SupportId: number): void
    {
        this.router.navigate(['Admin/Support/Detail', SupportId]);
    }

    Getstatus() {
        this.Supportservice.get(Global.BaseUrl + "Support/GetStatus").subscribe((res) => this.Filters.CallStatus = res);
    }
  
    deleteSupport(SupportId: number): void
    {
        this.Supportservice.delete(Global.BaseUrl + "Support/Delete" + SupportId).subscribe((res) => this.Isdelete = res);
    }
    SearchSupport()
    {
        this.Supportservice.get(Global.BaseUrl + "Support/SingleSupport/" + this.Support.SupportId).subscribe(
            (res) => this.SupportObject = res);
    }

    GetFilterDropdown(): void
    {
        this.Supportservice.get(Global.BaseUrl + "Support/SupportFilter").subscribe((res) => this.Filters = res);
    }

    SupportFilter():void
    {      
        this.Supportservice.post(Global.BaseUrl + "Support/Filter", this.Filter).subscribe((res) => this.SupportObject = res);
    }
    CancelSearch()
    {
        this.Support.SupportId = null;
    }
    Refresh()
    {
        this.Filter.SelectedAllocated = '';
        this.Filter.SelectedCallStatus = '';
        this.Filter.SelectedDateAfter = null;
        this.Filter.SelectedDateBefore = null;
        this.Filter.SelectedLevel = '';
        this.Filter.SelectedTakenFrom = '';
        this.Filter.SelectedIndustrySector = '';
        this.Filter.SelectedClosedAfter = null;
        this.Filter.SelectedClosedBefore = null;
        this.Filter.SelectedResponseibilty = '';
    }
   
}
