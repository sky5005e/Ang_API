import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Support } from '../model/Support';
import { CommonService } from '../../../_services/commonservice';
import { Global } from '../../../Shared/global';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import {Paging} from "../../../Common/Paging";
import { Common } from '../../../Shared/common';
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html'
 
})
export class DetailComponent implements OnInit {
  IsProgressOn: boolean = true;
     IsResolutionOn: boolean = false;
     IsAssociatedFileOn: boolean = false;
     IsAuditTrialOn: boolean = false;
     SupportId: number;
     displayDate: string = new Date().toLocaleString();
     Model = new Support();
     Paging =new  Paging ();
     constructor(private Service: CommonService, private route: ActivatedRoute, private Router: Router) { }

  ngOnInit() {
        this.SupportId = this.route.snapshot.params['id'];
        this.SupportDetail();
        this.GetAllocated();
  }
    Project(): void {
        this.Service.get(Global.BaseUrl + "Support/Project").subscribe((res) => this.Model.Project = res);
    }

   SupportDetail(): void
   {
           this.Service.get(Global.BaseUrl + "Support/SupportDetail/" + this.SupportId).subscribe(
           (res) => {this.Model = res,this.Project(),this.Level(),this.GetSupportType()});     
           }

   Getstatus() {
       this.Service.get(Global.BaseUrl + "Support/GetStatus").subscribe((res) => { this.Model.StatusList = res,this.GetLocation()});
   }

   GetFaq() {
       this.Router.navigate(['/Admin/Support/Faq/List']);
   } 

   GetSupportType() {
       this.Service.get(Global.BaseUrl + "Support/SupportType").subscribe((res) => {this.Model.SupportTypeList = res,this.FormatTime()});
   }
  
   GetSupportSubType(Id: number) {
       this.Service.get(Global.BaseUrl + "Support/SupportSubType/" + Id).subscribe((res) => this.Model.SupportSubTypeList = res);
   }
   GetLocation() {
       this.Service.get(Global.BaseUrl + "Support/Location").subscribe((res) => this.Model.LocationList = res);
   }

   ShowProgressDiv() {
   }
   ShowResolutionDiv() { 
       this.GetSupportType();
   }
   ShowAssociatedFileDiv() {
  
   }
   ShowAuditTrialDiv() {
       this.GetAuditDetail();
   
   }
   Line() {
       this.Model.SupportAction = this.Model.SupportAction != null ? this.Model.SupportAction + "\n" + this.displayDate : this.displayDate;

   }
   Chasedphone() {
       var text = "-Chased the client via the phone.";
       this.Model.SupportAction = this.Model.SupportAction != null ? this.Model.SupportAction + "\n" + this.displayDate + text : this.displayDate + text;
   }
   ChasedEmail() {
       var text = " -Chased the client via email.";
       this.Model.SupportAction = this.Model.SupportAction != null ? this.Model.SupportAction + "\n" + this.displayDate + text : this.displayDate + text;
   }
   Level(): void {
       this.Service.get(Global.BaseUrl + "Support/Level").subscribe((res) => {this.Model.Level = res,this.Getstatus()})
   }
   GetProductName(): void {
       this.Service.get(Global.BaseUrl + "Product/Name/" + this.Model.ProjectId).subscribe((res) => this.Model.Product = res);
   }
   AddHour() {
       this.Model.ManHoursActual = this.Model.ManHoursActual == null ? 0.25 : this.Model.ManHoursActual + 0.25;
   }
   GetAuditDetail() {
       this.Service.get(Global.BaseUrl + "Support/AuditDetail/" + this.SupportId).subscribe((res) => this.Model.AuditDetailList = res);
   }
   GetAllocated() {
       this.Service.get(Global.BaseUrl + "Operator/Name").subscribe((res) => {
           this.Model.AllocatedList = res,
               this.Model.TakenByList = res
       });
   }
   FormatTime()
   {
       this.Model.StrTimeResolved=Common.FormatTimeIn12Hours(this.Model.TimeResolved,false);
       this.Model.StrFixTime=Common.FormatTimeIn12Hours(this.Model.FixTime,false);
       this.Model.StrTimeOpened=Common.FormatTimeIn12Hours(this.Model.TimeOpened,false);
       this.Model.StrFirstResponseTime=Common.FormatTimeIn12Hours(this.Model.FirstResponseTime,false);
       this.Model.StrTimeEscalated=Common.FormatTimeIn12Hours(this.Model.TimeEscalated,false);
       this.Model.StrTimeResolved=Common.FormatTimeIn12Hours(this.Model.StrTimeResolved,false);
   }

  
}
