import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Support } from '../model/Support';
import { CommonService } from '../../../_services/commonservice';
import { Global } from '../../../Shared/global';
import { Router,ActivatedRoute } from '@angular/router';
import {  Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
@Component({
 selector: 'app-add',
  templateUrl: './add.component.html'
 
  
})
export class AddComponent implements OnInit {
     IsProgressOn: boolean = true;
     IsResolutionOn: boolean = false;
     IsAssociatedFileOn: boolean = false;
     IsAuditTrialOn: boolean = false;            
    location: Location;
    fileList: FileList;
    file: File;

  constructor(private Service: CommonService, private router: Router,private ActivatedRoute :ActivatedRoute) {
       }

  ngOnInit() {
        this.Getstatus();
        this.GetLocation();
        this.Project();
        this.Level();
        this.Model.DateOpened = new Date();
        this.GetAllocated();
  }


    Support: string; 
    displayDate :string = new Date().toLocaleString();
    Model = new Support();
    Save() {
            
            let formData: FormData = new FormData();
            formData.append("model", JSON.stringify(this.Model));
            if (this.file)
                formData.append('uploadFile', this.file, this.file.name);
            let headers = new Headers();
            let options = new RequestOptions({ headers: headers });
            this.Service.PostImage(Global.BaseUrl + "Support/UploadFile", formData, options)
                .subscribe((res) => { this.router.navigateByUrl('Admin/Support/List') });
           
        
      
    }

    Getstatus()
    {
        this.Service.get(Global.BaseUrl +"Support/GetStatus").subscribe((res) => this.Model.StatusList = res);
    }
    GetFaq()
    {
        this.router.navigate(['/Admin/Support/Faq/List']);
    }  

    GetSupportType()
    {
        this.Service.get(Global.BaseUrl + "Support/SupportType").subscribe((res) => this.Model.SupportTypeList = res);
    }
    GetSupportSubType(Id:number)
    {
        if(Id!=0)
        this.Service.get(Global.BaseUrl + "Support/SupportSubType/" + Id).subscribe((res) => this.Model.SupportSubTypeList = res);
        else{
            this.Model.SupportSubTypeList=null;
        }
    }
    GetLocation() {
        this.Service.get(Global.BaseUrl + "Support/Location").subscribe((res) => this.Model.LocationList = res);
    }

    ShowProgressDiv()
    {
        if (this.IsProgressOn)
        { 
            this.IsProgressOn = this.IsProgressOn;
            this.IsResolutionOn = false;
            this.IsAssociatedFileOn = false;
            this.IsAuditTrialOn = false;
        }
        else{
            this.IsProgressOn = !this.IsProgressOn;
            this.IsResolutionOn = false;
            this.IsAssociatedFileOn = false;
            this.IsAuditTrialOn = false;
        }
      
    }
    ShowResolutionDiv()
    {
        this.IsProgressOn = false;
        this.IsResolutionOn = !this.IsResolutionOn;
        this.IsAssociatedFileOn = false;
        this.IsAuditTrialOn = false;
        this.GetSupportType();
    }
    ShowAssociatedFileDiv()
    {
        this.IsProgressOn = false;
        this.IsResolutionOn = false;
        this.IsAssociatedFileOn = !this.IsResolutionOn;
        this.IsAuditTrialOn = false;
    }
    ShowAuditTrialDiv()
    {
        this.IsProgressOn = false;
        this.IsResolutionOn = false;
        this.IsAssociatedFileOn = false;
        this.IsAuditTrialOn = !this.IsAssociatedFileOn;
        this.GetAuditDetail();
    }
    Line()
    {
        this.Model.SupportAction = this.Model.SupportAction != null ? this.Model.SupportAction + "\n" + this.displayDate : this.displayDate;
       
    }
    Chasedphone()
    {
        var text = "-Chased the client via the phone.";
        this.Model.SupportAction = this.Model.SupportAction != null ? this.Model.SupportAction + "\n" + this.displayDate + text : this.displayDate + text;
    }
    ChasedEmail()
    {
        var text = " -Chased the client via email.";
        this.Model.SupportAction = this.Model.SupportAction != null ? this.Model.SupportAction + "\n" + this.displayDate + text : this.displayDate + text;
    }
    Project(): void
    {
        this.Service.get(Global.BaseUrl + "Support/Project").subscribe((res) => this.Model.Project = res);
    }
    Level(): void
    {
        this.Service.get(Global.BaseUrl + "Support/Level").subscribe((res) => this.Model.Level = res)
    }
    GetProjectVersion(Id: number)
    {
        if (Id==0)
        {
            this.Model.Version = null;
            this.Model.Phone = null;
            this.Model.Product = null;
        }
        else {
            for (let i = 0; i < this.Model.Project.length; i++) {
                if (this.Model.Project[i].ProjectId == Id) {
                    this.Model.Version = this.Model.Project[i].Version;
                    this.Model.Phone = this.Model.Project[i].Phone;
                    this.Model.LocationId = this.Model.Project[i].LocationId;
                }
            }
            this.GetProductName(Id);
        }
    }
    GetProductName(Id:number):void
    {
        this.Service.get(Global.BaseUrl + "Product/Name/" + Id).subscribe((res) => this.Model.Product = res);
    }
    AddHour()
    {
        this.Model.ManHoursActual = this.Model.ManHoursActual == null ? 0.25 : this.Model.ManHoursActual + 0.25;
    }
    GetAllocated()
    {        
        this.Service.get(Global.BaseUrl + "Operator/Name").subscribe((res) =>
        {
            this.Model.AllocatedList = res,
            this.Model.TakenByList = res
        });      
        
    }
    fileChange(event: any): void {
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            this.file = fileList[0];
           
        }
    }

    GetAuditDetail()
    {
        this.Service.get(Global.BaseUrl + "Support/AuditDetail/0").subscribe((res) => this.Model.AuditDetailList = res);
    }
TextAppend()
{
    
}
}
