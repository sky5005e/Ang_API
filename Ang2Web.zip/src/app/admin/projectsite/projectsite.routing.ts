import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import {ProjectSiteComponent} from './projectsite.component';
import {AddComponent} from './add/add.component';
import {DetailComponent} from './detail/detail.component';
export const routes: Routes = [
    {
        path: '',
        component: ProjectSiteComponent,
        children: [

            {
                path: 'Add/:id',
                component: AddComponent
            },
          
 {
                path: 'Detail/:id',
                component: DetailComponent
            },

        ]
    }
];
export const routing: ModuleWithProviders = RouterModule.forChild(routes);