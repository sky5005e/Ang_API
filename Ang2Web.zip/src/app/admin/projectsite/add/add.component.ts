import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { CommonService } from "../../../_services/CommonService";
import { ProjectSite } from '../model/ProjectSite';
import { Global } from '../../../Shared/global';
import { ContactDetail } from "../model/ContactDetail";

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  providers:[CommonService]
})
export class AddComponent implements OnInit {
 constructor(private Service: CommonService, private Route: Router, private ActivatedRoute: ActivatedRoute) { }
    ngOnInit(): void {
        this.ProjectId = this.ActivatedRoute.snapshot.params['id'];
        this.GetLocationList();
    }


    ProjectId: number;
    Model = new ProjectSite();
     ShowContactDiv: boolean = true;
     ShowNoteDiv: boolean = false;
     ShowNetworkDiv: boolean = false;
     ShowRemoteConnectionDiv: boolean = false;
     showNetWorkType: boolean = false;
     showNetWorkVersion: boolean = false;
     LocationId: number;

    Object = new ContactDetail();
    GetLocationList()
    {
        this.Service.get(Global.BaseUrl + "ProjectSite/Location").subscribe((res) => this.Model.LocationList = res)
    }
    GetContactList(Id:number)
    {
        
        this.LocationId = Id;
        this.Service.get(Global.BaseUrl + "ProjectSite/Contact/" + Id).subscribe((res) => {
            this.Object = res, this.Model.ContactList = this.Object.ContactList;
            this.Model.Address = this.Object.Address;
            this.Model.Address1 = this.Object.Address1;
            this.Model.Address2 = this.Object.Address2;
            this.Model.Address3 = this.Object.Address3;
            this.Model.Client = this.Object.Client;
            this.Model.ClientName = this.Object.ClientName;
            this.Model.Phone1 = this.Object.Phone1;
            this.Model.Phone2 = this.Object.Phone2;
            this.Model.PostCode = this.Object.PostCode;
            this.Model.Fax = this.Object.Fax;
        });
    }

    


    Contacts() {
        if (this.ShowContactDiv) {
            this.ShowContactDiv = this.ShowContactDiv;
            this.ShowNoteDiv = false;
            this.ShowNetworkDiv = false;
            this.ShowRemoteConnectionDiv = false;
        }
        else {
            this.ShowContactDiv = !this.ShowContactDiv;
            this.ShowNoteDiv = false;
            this.ShowNetworkDiv = false;
            this.ShowRemoteConnectionDiv = false;
        }
    }
    Notes() {
        this.ShowContactDiv = false;
        this.ShowNoteDiv = !this.ShowNoteDiv;
        this.ShowNetworkDiv = false;
        this.ShowRemoteConnectionDiv = false;
    }
    Network() {
        this.ShowContactDiv = false;
        this.ShowNoteDiv = false;
        this.ShowNetworkDiv = !this.ShowNetworkDiv;
        this.ShowRemoteConnectionDiv = false;
    }
    RemoteConnection() {
        this.ShowContactDiv = false;
        this.ShowNoteDiv = false;
        this.ShowNetworkDiv = false;
        this.ShowRemoteConnectionDiv = !this.ShowRemoteConnectionDiv;
        this.GetRemoteConnectionLink();
    }
    ShowNetwork(e) {
        if (e.target.checked)
        {
            this.showNetWorkType = true;
            this.showNetWorkVersion = true;
            this.GetNetworkType();

        }
        else {
            this.showNetWorkType = false;
            this.showNetWorkVersion = false;
        }
    }

    GetNetworkType()
    {
        this.Service.get(Global.BaseUrl + "/ProjectSite/NetWorkType").subscribe((res) => this.Model.NetWorkTypeList = res);
    }
    GetRemoteConnectionLink()
    {
        this.Service.get(Global.BaseUrl + "ProjectSite/RemoteConnectionLink").subscribe((res) => this.Model.LinkType = res);
    }
    Save()
    {
        this.Service.post(Global.BaseUrl + "ProjectSite/Post", this.Model).subscribe((res) => { this.Route.navigate(['/Admin/Project/Add']) });

    }

}
