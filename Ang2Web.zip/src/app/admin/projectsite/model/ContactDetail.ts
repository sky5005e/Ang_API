﻿export class ContactDetail
{
    public Client: string;
    public ClientName:string;
    public Address: string;
    public Address1: string;
    public Address2: string;
    public Address3: string;
    public Phone1: string;
    public Phone2: string;
    public Fax: string;
    public PostCode: string;
    public ContactList: [any];
}