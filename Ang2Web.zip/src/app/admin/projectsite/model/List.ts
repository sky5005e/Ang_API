export class List
{
     public  ProjectSiteId :number;        
     public  ClientVersion :string;      
     public  ServerVersion :string;   
     public  MainSite :boolean;
     public  CurrentVersion :string;   
     public ProjectId :number;     
     public  Client :string;
     public  PrimaryContact :string;
}