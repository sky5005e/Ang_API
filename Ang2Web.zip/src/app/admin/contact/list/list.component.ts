import { Component, OnInit } from '@angular/core';
import { Global } from "../../../shared/global";
import { CommonService } from "../../../_services/commonservice";
import { Contact } from "../model/Contact";
import { Routes, RouterModule, Router } from '@angular/router';
import { ContactList } from "../model/ContactList";
import { ContactFilter } from "../model/ContactFilter";
import {Paging} from '../../../Common/Paging';
@Component({
   selector: 'app-list',

   templateUrl: './list.component.html'
})


export class ListComponent implements OnInit
{
    Contact=new ContactList();
    ContactObject = new Contact();
    Filter = new ContactFilter();
    Paging=new Paging();
    constructor(private Service: CommonService, private router: Router) { }

    ngOnInit(): void
    {
        this.ContactList()
    }

    ContactList(PageNumber:number=0): void
    {
        this.Paging.PageNumber=PageNumber;
        this.Service.post(Global.BaseUrl + "Contact/ContactList",this.Paging).subscribe((res) => { 
            this.Contact = res,
             this.GetLocationList(),
             console.log(this.Contact.TotalRecord)
         });
    }

    ContactDetail(ContactId:number): void
    {
        this.router.navigate(['/Admin/Contact/Detail', ContactId]);  
    }

    DeleteContact(ContactId:number): void
    {
        this.Service.delete(Global.BaseUrl + "Contact/Delete" + ContactId).subscribe((res) => this.Contact = res);
    }
    SearchContact():void
    {
        this.Service.get(Global.BaseUrl + "Contact/ContactDetail/" + this.ContactObject.ContactId).subscribe((res) => this.Contact = res);
    }
    GetLocationList() {
        this.Service.get(Global.BaseUrl + "Contact/Locations").subscribe((res) => { this.Filter.LocationList = res });
    }

    ContactFilter()
    {
        this.Service.post(Global.BaseUrl + "Contact/QueryFilter", this.Filter).subscribe((res) => this.Contact = res);
    }
    ResetList()
    {
        this.Filter.Email = null;
        this.Filter.ForeNames = null;
        this.Filter.SelectedLocation = null;
        this.Filter.SurName = null;
    }
    
}