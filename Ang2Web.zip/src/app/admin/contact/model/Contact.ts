﻿

export class Contact {
    public Comments: string;
    public ContactId: number;
    public Department: string;
    public DirectFax: string;
    public DirectNumber: string;
    public Email: string;
    public Extension: string;
    public Forenames: string;
    public Initials: string;
    public JobTitle: string;
    public KnownAs: string;
    public LocationId: number;
    public MobileNumber: string;
    public Status: string;
    public Surname: string;
    public Title: string;
    public Client: string;
    public ClientName: string;
    public Address: string;
    public Address1: string;
    public Address2: string;
    public Address3: string;
    public Phone1: string;
    public Phone2: string;
    public PostCode: string;
    public Fax: string;
    public StatusList: [any];
    public LocationList: [any];
    public TitleList: [any];
}