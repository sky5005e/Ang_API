﻿export class ContactFilter
{
    public SelectedLocation: number;
    public ForeNames: string;
    public SurName: string;
    public Email: string;
    public LocationList:[any];
}