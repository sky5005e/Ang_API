﻿export class ContactList
{
    // public ContactId: number;
    // public Forenames: string;
    // public Surname: string;
    // public Loctaion: string;
    // public Department: string;
    // public HI41: string;
    // public Current: string;

    public ContactList:[any];
    public TotalRecord:number;
}