import { Component, OnInit } from '@angular/core';
import { Contact } from "../model/Contact";
import { CommonService } from "../../../_services/commonservice";
import { Global } from "../../../shared/global";
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { ContactDetail } from "../model/ContactDetail";
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html'
})
export class DetailComponent implements OnInit {

   ContactId: number;
    Contact = new Contact();
    Object = new ContactDetail();
  constructor(private Service: CommonService, private Route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
      this.ContactId = this.Route.snapshot.params['id'];
        this.ContactDetail();
  }
    ContactDetail(): void
    {
        this.Service.get(Global.BaseUrl + "Contact/Get/" + this.ContactId).subscribe((res) => { this.Contact = res, this.GetLocationList() });      
    }
    GetLocationList() {
        this.Service.get(Global.BaseUrl + "Contact/Locations").subscribe((res) => { this.Contact.LocationList = res, this.GetStatus() });
    }

    GetStatus() {
        this.Service.get(Global.BaseUrl + "Contact/Status").subscribe((res) => { this.Contact.StatusList = res, this.GetTitle() });
    }
    GetTitle() {
        this.Service.get(Global.BaseUrl + "Contact/Title").subscribe((res) => { this.Contact.TitleList = res, this.GetContactDetail(this.Contact.LocationId)});
    }



    GetContactDetail(Id: number) {
       
            this.Service.get(Global.BaseUrl + "Contact/LocationContact/" + Id).subscribe((res) => {
                this.Object = res,
                this.Contact.Address = this.Object.Address;
                this.Contact.Address1 = this.Object.Address1;
                this.Contact.Address2 = this.Object.Address2;
                this.Contact.Address3 = this.Object.Address3;
                this.Contact.Client = this.Object.Client;
                this.Contact.ClientName = this.Object.ClientName;
                this.Contact.Phone1 = this.Object.Phone1;
                this.Contact.Phone2 = this.Object.Phone2;
                this.Contact.PostCode = this.Object.PostCode;
                this.Contact.Fax = this.Object.Fax;
            })

        }     

    UpdateContact(): void
    {
        debugger;
        this.Service.put(Global.BaseUrl + "Contact/Put", this.Contact).subscribe((res)=>(this.router.navigate(['Admin/Contact/List'])));
       
    }
}
