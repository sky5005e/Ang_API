import { Component, OnInit } from '@angular/core';
import { Contact } from "../model/Contact";
import { CommonService } from "../../../_services/commonservice";
import { Router } from "@angular/router";
import { Global } from "../../../shared/global";
import { BrowserModule } from '@angular/platform-browser';
import { ContactDetail } from "../model/ContactDetail";
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html'

})
export class AddComponent implements OnInit {

   Contact = new Contact();
    Object = new ContactDetail();
  constructor(private Service: CommonService, private router: Router) { }

  ngOnInit() {
    this.GetLocationList();
  }

    SaveContact():void
    {
        this.Service.post(Global.BaseUrl + "Contact/Post", this.Contact).subscribe((res) => {  this.router.navigate(['/Admin/Contact/List']) });
    }   

    GetLocationList()
    {
        this.Service.get(Global.BaseUrl + "Contact/Locations").subscribe((res) => { this.Contact.LocationList = res, this.GetStatus() });
    }

    GetStatus()
    {
        this.Service.get(Global.BaseUrl + "Contact/Status").subscribe((res) => { this.Contact.StatusList = res, this.GetTitle() });
    }
    GetTitle()
    {
        this.Service.get(Global.BaseUrl + "Contact/Title").subscribe((res) => this.Contact.TitleList = res);
    }
    GetContactDetail(Id:number)
    {
        if (Id!=0)
        {
            this.Service.get(Global.BaseUrl + "Contact/LocationContact/" + Id).subscribe((res) => {
                this.Object = res,
                this.Contact.Address = this.Object.Address;
                this.Contact.Address1 = this.Object.Address1;
                this.Contact.Address2 = this.Object.Address2;
                this.Contact.Address3 = this.Object.Address3;
                this.Contact.Client = this.Object.Client;
                this.Contact.ClientName = this.Object.ClientName;
                this.Contact.Phone1 = this.Object.Phone1;
                this.Contact.Phone2 = this.Object.Phone2;
                this.Contact.PostCode = this.Object.PostCode;
                this.Contact.Fax = this.Object.Fax;
            })

        }
        else {
            this.Contact.Address = null;
            this.Contact.Address1 = null;
            this.Contact.Address2 = null;
            this.Contact.Address3 = null;
            this.Contact.Client = null;
            this.Contact.ClientName = null;
            this.Contact.Phone1 = null;
            this.Contact.Phone2 = null;
            this.Contact.PostCode = null;
            this.Contact.Fax = null;
        }
        
       
    }
}
