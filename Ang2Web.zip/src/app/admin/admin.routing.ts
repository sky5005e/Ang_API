import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { AdminComponent } from './admin.component';
import { AuthGuardService } from '../_services/auth-guard.service';

export const routes: Routes = [
    {
        path: '',
        component: AdminComponent,
        canActivate:[AuthGuardService],
        children: [

            {
                path: 'Contact',               
                loadChildren:'./contact/contact.module#ContactModule'
            },
          
{
                path: 'Support',               
                loadChildren:'./support/support.module#SupportModule'
            },
        {
            path:"Project",
            loadChildren:'./project/project.module#ProjectModule'
        },
         {
            path:"ProjectSite",
            loadChildren:'./projectsite/projectsite.module#ProjectSiteModule'
        },
{
            path:"Location",
            loadChildren:'./location/location.module#LocationModule'
        },
        {
            path:"SupportContract",
            loadChildren:'./supportcontract/supportcontract.module#SupportContractModule'
        },

        ]
    }
];
export const routing: ModuleWithProviders = RouterModule.forChild(routes);