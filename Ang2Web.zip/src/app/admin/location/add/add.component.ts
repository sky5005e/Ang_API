import { Component, OnInit } from '@angular/core';
import { CommonService } from "../../../_services/CommonService";
import { Location } from "../model/Location";
import { Router } from "@angular/router";
import { Global } from "../../../Shared/global";
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  providers:[CommonService]
})
export class AddComponent implements OnInit {

  Location = new Location();
    Status = [];
    LocationType = [];
    constructor(private Service: CommonService, private Route: Router) { }   
    ngOnInit(): void
    {
        this.GetLocationStatus();
        this.GetLocationType();
    }
  
    SaveLocation(): void {
        this.Service.post(Global.BaseUrl + "Location/Post", this.Location).subscribe((res) => {this.Route.navigate(['Admin/Location/List'])});
        
    }
    GetLocationStatus(): void {
        this.Service.get(Global.BaseUrl +"Location/LocationStatus").subscribe((res) => this.Status = res);
    }
    GetLocationType(): void {
        this.Service.get(Global.BaseUrl +"Location/LocationType").subscribe((res) => this.LocationType = res);
    }
}
