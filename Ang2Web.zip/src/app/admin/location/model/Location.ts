﻿
export class Location {
    public LocationId: number;
    public Address1: string;
    public Address2: string;
    public Address3: string;
    public Address4: string;
    public ApprovedFor: string
    public ApprovedSupplier: boolean;
    public ClientSupplierNumber: string;
    public Comments: string;
    public DateOn?: Date;
    public Email: string;
    public Fax: string;
    public InvoiceAddress1: string;
    public InvoiceAddress2: string;
    public InvoiceAddress3: string;
    public InvoiceAddress4: string;
    public InvoiceFax: string;
    public InvoiceName: string;
    public InvoicePhone: string;
    public InvoicePostCode: string;
    public KnownAs: string;
    public Name: string;
    public NHSOrganisationNumber: string;
    public Phone1: string;
    public Phone2: string;
    public PostCode: string;
    public Status: string;
    public SupplierAccountNumber: string;
    public SupplierApprovalDate: Date;
    public SupplierAprovedBy: string;
    public SupplierCassification: string;
    public Type: string;
    public VATExempt: boolean;
    public WebSite: string;

}