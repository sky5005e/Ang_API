﻿export class LocationList
{
    // public LocationId: number;
    // public KnownAs: string;
    // public Phone :string;
    // public Fax: string;
    // public LocationType: string;
    // public VatExempt: boolean;

    public List:[any];
    public TotalRecord:number;
}