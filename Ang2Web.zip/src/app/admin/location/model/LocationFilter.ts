export class LocationFilter
{
    public SurName:string;
    public ForeName:string;
    public LocationName:string;
}