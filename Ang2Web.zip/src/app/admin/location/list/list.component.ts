import { Component, OnInit } from "@angular/core";
import { Router, Routes, RouterModule } from "@angular/router";
import { Location } from "../model/Location";
import { CommonService } from "../../../_services/CommonService";
import { Global } from "../../../Shared/global";
import { LocationList } from "../model/LocationList";
import { LocationFilter } from '../model/LocationFilter';
import {Paging} from "../../../Common/Paging";
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',

  providers:[CommonService]
})
export class ListComponent implements OnInit {
    Filter=new LocationFilter();
    LocationObject = new Location();
    Location=new  LocationList();
    Paging =new Paging();
    ngOnInit(): void
    {
        this.GetLocationList();
    }
    constructor(private Route: Router, private Service: CommonService) { }

    GetLocationList(PageNumber:number=0): void
    {
        this.Paging.PageNumber=PageNumber;
        this.Service.post(Global.BaseUrl + "Location/Locations",this.Paging).subscribe((res) => this.Location = res);
    }
    EditLocation(LocationId: number): void {
        this.Route.navigate(['Admin/Location/Detail', LocationId]);
    }
    DeleteLocation(LocationId: number): void {
        this.Service.delete(Global.BaseUrl + "Location/Delete" + LocationId).subscribe((res) => {this.Route.navigate(['/Admin/Location/List'])});
        
    }
    SearchLocation(): void
    {
        this.Service.get(Global.BaseUrl + "Location/LocationDetail" + this.LocationObject.LocationId).subscribe((res) => this.Location == res);
    }
    Reset()
    {
        this.Filter.ForeName=null;
        this.Filter.LocationName=null;
        this.Filter.SurName=null;
    }
    ApplyFilter()
    {
        this.Service.post(Global.BaseUrl+"Location/LocationFilter",this.Filter).subscribe((res)=>this.Location=res);

    }
}
