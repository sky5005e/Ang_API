import{Component,OnInit} from "@angular/core";
@Component({

    template:`<router-outlet></router-outlet>`
})
export class LocationComponent implements OnInit{
constructor(){}
ngOnInit()
{

}
}