import {NgModule} from "@angular/core";
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {routing} from './location.routing';
import {LocationComponent} from './location.component';
import { AddComponent } from './add/add.component';
import { ListComponent } from './list/list.component';
import { DetailComponent } from './detail/detail.component';
import { Ng2DatetimePickerModule } from 'ng2-datetime-picker';
import {NgxPaginationModule} from 'ngx-pagination';
@NgModule({

    imports:[CommonModule
        ,HttpModule
        ,RouterModule
        ,routing
        ,FormsModule
        ,Ng2DatetimePickerModule
    ,NgxPaginationModule],
    declarations:[LocationComponent, AddComponent, ListComponent, DetailComponent]

})
export class LocationModule {
    
    
}