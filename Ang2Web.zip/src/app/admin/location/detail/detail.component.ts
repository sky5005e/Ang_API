import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { Location } from "../model/Location";
import { CommonService } from "../../../_services/CommonService";
import { Global } from '../../../Shared/global';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  providers:[CommonService]
})
export class DetailComponent implements OnInit {
 LocationId: number;
    Location = new Location();
    Status = [];
    LocationType = [];
    constructor(private ActivatedRoute: ActivatedRoute, private Service: CommonService, private Route: Router) { }
    ngOnInit(): void
    {
        this.LocationId = this.ActivatedRoute.snapshot.params['id'];
        this.LocationDetail();
        this.GetLocationStatus();
        this.GetLocationType();
    }

    LocationDetail(): void
    {
        this.Service.get(Global.BaseUrl + "Location/Get" + this.LocationId).subscribe((res) => this.Location = res);
    }
    GetLocationStatus(): void {
        this.Service.get(Global.BaseUrl + "Location/LocationStatus").subscribe((res) => this.Status = res);
    }
    GetLocationType(): void {
        this.Service.get(Global.BaseUrl + "Location/LocationType").subscribe((res) => this.LocationType = res);
    }

    EditLocation(): void
    {
        this.Service.put(Global.BaseUrl + "Location/Put", this.Location).subscribe((res) => {this.Route.navigate(['/Admin/Location/List'])});

    }
}
