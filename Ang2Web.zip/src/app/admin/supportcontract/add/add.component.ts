import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { CommonService } from "../../../_services/CommonService";
import { Global } from "../../../Shared/global";
import { SupportContract } from "../model/SupportContracts";
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  providers:[CommonService]
})
export class AddComponent implements OnInit {

    Response: string;
    Input = new SupportContract();
    ProjectRefrence = [];
    Status = [];
    ContractType = [];
    constructor(private Service: CommonService, private Route: Router) {  }
    ngOnInit(): void
    {
        this.GetStatus();
        this.GetprojectRefrence();
        this.GetContractType();
    }

    Save(): void
    {
        this.Service.post(Global.BaseUrl + "SupportContract/Post", this.Input).subscribe((res) =>{this.Route.navigate(['Admin/SupportContract/List'])});
        
    }
    GetStatus(): void
    {
        this.Service.get(Global.BaseUrl + "SupportContract/ContractStatus").subscribe((res) => this.Status = res);
    }
    GetprojectRefrence(): void
    {
        this.Service.get(Global.BaseUrl + "SupportContract/ProjectRefrence").subscribe((res) => this.ProjectRefrence = res);
    }
    GetContractType(): void
    {
        this.Service.get(Global.BaseUrl +"SupportContract/ContractType").subscribe((res) => this.ContractType = res);
    }

    onProjectChange(deviceValue)
    {
        for (let i = 0; i < this.ProjectRefrence.length; i++)
        {
            if (this.ProjectRefrence[i].ProjectId == deviceValue)
            {
                this.Input.ProjectName= this.ProjectRefrence[i].ProjectName;
            }
        }
    }

}
