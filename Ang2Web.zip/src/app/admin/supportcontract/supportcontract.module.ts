import {NgModule} from "@angular/core";
import { APP_BASE_HREF } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {routing} from './supportcontract.routing';
import {SupportContractComponent} from './supportcontract.component';
import {ListComponent } from './list/list.component';
import {AddComponent} from './add/add.component';
import {NgxPaginationModule} from 'ngx-pagination';
@NgModule({
   imports:[HttpModule,
    RouterModule,
    FormsModule,
    routing,
    CommonModule,
    NgxPaginationModule
],
   declarations:[ListComponent,AddComponent,SupportContractComponent] 
})
export class SupportContractModule{}