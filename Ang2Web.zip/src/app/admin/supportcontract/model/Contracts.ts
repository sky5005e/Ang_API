﻿export class Contracts
{
    public ContractId: number;
    public Project: string;
    public ContractTitle: string;
    public ContractStartDate: string;
    public ContractRenewalDate: string;
    public CurrentSupportCharge: number;
    public ContractStatus: string;
    public DateRenewalLetterSent: string;
    public DateRenewalLetterReturned: string;
    public PurchaseOrderRequired: string;
    public List :[any];
    public TotalRecord :number;

}