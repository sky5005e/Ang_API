import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Contracts } from "../model/Contracts";
import { Global } from "../../../Shared/global";
import { CommonService } from "../../../_services/CommonService";
import {Paging} from '../../../Common/Paging';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',

  providers:[CommonService]
})
export class ListComponent implements OnInit {

 Contracts = new Contracts();
    Paging =new Paging();
    ngOnInit(): void
    {
        this.GetContractDetails()
    }
    constructor(private Service: CommonService, private Route: Router) { }

    GetContractDetails(PageNumber:number=0)
    {
        this.Paging.PageNumber=PageNumber;
        this.Service.post(Global.BaseUrl + "SupportContract/ContractList",this.Paging).subscribe((res) => this.Contracts = res);
    }

    GetContractDetail():void
    {
        this.Service.get(Global.BaseUrl + "/SupportContract/ContractDetail" + this.Contracts.ContractId).subscribe((res) => this.Contracts = res);
    }

}
