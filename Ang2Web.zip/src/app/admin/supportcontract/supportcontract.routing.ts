import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import {SupportContractComponent} from './supportcontract.component';
import { AddComponent } from './add/add.component';
import { ListComponent } from './list/list.component';
export const routes: Routes = [
    {
        path: '',
        component: SupportContractComponent,
        children: [
         
            {
                path: 'Add',
                component: AddComponent
            },
          {
                path: 'List',
                component: ListComponent
            },

          


        ]
    }
];
export const routing = RouterModule.forChild(routes);