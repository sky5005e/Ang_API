import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
@Injectable()
export class CommonService {
    constructor(private _http: Http) { }

    get(url: string): Observable<any> {
        return this._http.get(url).map((res) => res.json());
    }

    delete(url: string): Observable<any> {
        return this._http.delete(url).map((res) => res.json());
    }

    put(url: string, model: any): Observable<any> {
        return this._http.put(url, model).map((res) => res.json());
    }

    post(url: string, model: any): Observable<any> {

        return this._http.post(url, model).map((res) => res.json());
    }
    PostImage(url: string, formdata: any, options: any): Observable<any> {
        return this._http.post(url, formdata, options).map((res) => res.json());
    }

}