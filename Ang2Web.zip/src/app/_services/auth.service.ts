import {LoginResult} from '../login/model/loginResult';
import { Observable } from 'rxjs/Observable';
export class AuthService
{
	constructor( ){}
    private redirectUrl: string = '/';
	private loginUrl: string = '/Login';
	 loggedInUser: LoginResult;
    isUserAuthenticated(UserData:any ): boolean {   
		this.loggedInUser=UserData;
     if( this.loggedInUser.LoginAttemptResult) {
			this.loggedInUser.IsloggedIn = true;
			this.store(UserData);
			return true;
		} else {
			this.loggedInUser.IsloggedIn = false;
			return false;
		}
}
        	
	isUserLoggedIn(): boolean {
		return this.loggedInUser.IsloggedIn;
	}
	getRedirectUrl(): string {
		return this.redirectUrl;
	}
	setRedirectUrl(url: string): void {
		this.redirectUrl = url;
	}
	getLoginUrl(): string {
		return this.loginUrl;
	}
	getLoggedInUser(): LoginResult {
		return this.loggedInUser;
	}
	logoutUser(): void{
		this.loggedInUser.IsloggedIn = false;
	}

	  store(body: LoginResult): void {  
        // Stores access token in local storage to keep user signed in.  
        localStorage.setItem('Is_loggedIn', String(body.IsloggedIn));  
        // Stores refresh token in local storage.  
        // localStorage.setItem('refresh_token', body.refresh_token);  
  
        // Decodes the token.  
        //this.decodeToken();  
  
	}  
	LogOut()
	{
		//this.loggedInUser.IsloggedIn=false;
		localStorage.removeItem('Is_loggedIn');
	}
}