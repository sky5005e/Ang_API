import { CanActivate, CanActivateChild, Router, ActivatedRouteSnapshot, RouterStateSnapshot,ActivatedRoute } from '@angular/router';
import {Injectable} from "@angular/core";
import {AuthService} from '../_services/auth.service';

@Injectable()
export class AuthGuardService implements CanActivate, CanActivateChild {

  constructor(private authService: AuthService,private router: Router)
  {

  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):boolean
  {
  let url: string = state.url;
    let token: boolean = Boolean(localStorage.getItem('Is_loggedIn'));  
  if (token) {
		return true; 
  }
   this.authService.setRedirectUrl(url);
   this.router.navigate([this.authService.getLoginUrl()]);
	return false;
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):boolean
  {
   let loggedInUser= this.authService.getLoggedInUser();
   
	if (loggedInUser.RoleName === 'TeamManager') {
	  return true;		
    }
   else {
		return false;
	}
  }
}