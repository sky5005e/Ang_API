import { Component, OnInit } from '@angular/core';
import {UsernameAndPassword} from "./model/UsernameAndPassword";
import {CommonService} from "../_services/commonservice";
import {Global} from '../shared/global';
import {LoginResult} from './model/loginResult';
import {AuthService} from '../_services/auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
	 loggedInUser=new  LoginResult(); 
  
   constructor(private Service:CommonService,
    private AuthService:AuthService,
    private Router:Router,
  ) { }
    redirectUrl: string = '/';
		invalidCredentialMsg:string;
   Login=new UsernameAndPassword();
  ngOnInit() {
    this.SetPageheight();
  }
 DoLogin():void{
  this.Service.post(Global.LoginUrl+"User/ValidateUser",this.Login).subscribe((res)=>{
    this.loggedInUser=res ,this.ValidateUser();
  } 
    );

 }

 SetPageheight()
  {
     $(document).ready(function () {
            if ($("body").width() > 767) {
                var temp = $("footer").height() + $("nav").height();
                var temp2 = $(window).height() - 2
                $(".user-login-wrapper").height(temp2 - temp);
            }

        });
  }
ValidateUser()
{
  if(this.loggedInUser.LoginAttemptResult)
  {
	this.loggedInUser.IsloggedIn=true;
  this.AuthService.isUserAuthenticated(this.loggedInUser);
  	if (this.loggedInUser.RoleName === 'TeamManager') {
       this.Router.navigate(['/Admin/Support/List'])
    }
	}
else{
	this.invalidCredentialMsg = 'Invalid Credentials. Try again.';
}
}
}
