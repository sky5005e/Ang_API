export class LoginResult
{
    public UserID:number;
    public LoginAttemptResult:boolean;
    public LoginErrorMessage:string;
    public OTAC:string;
    public RoleId:string;
    public RoleName:string;
    public IsloggedIn:boolean;
}