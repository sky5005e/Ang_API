export class UsernameAndPassword
{
   public UserName:string;
   public Password:string;
}