import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResgisteruserComponent } from './resgisteruser.component';

describe('ResgisteruserComponent', () => {
  let component: ResgisteruserComponent;
  let fixture: ComponentFixture<ResgisteruserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResgisteruserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResgisteruserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
