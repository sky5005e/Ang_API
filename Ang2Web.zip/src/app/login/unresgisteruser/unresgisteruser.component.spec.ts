import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnresgisteruserComponent } from './unresgisteruser.component';

describe('UnresgisteruserComponent', () => {
  let component: UnresgisteruserComponent;
  let fixture: ComponentFixture<UnresgisteruserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnresgisteruserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnresgisteruserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
