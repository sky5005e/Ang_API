import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unresgisteruser',
  templateUrl: './unresgisteruser.component.html',
  styleUrls: ['./unresgisteruser.component.css']
})
export class UnresgisteruserComponent implements OnInit {

  constructor() { }

 ngOnInit() {
    this.SetPageheight();
  }

  SetPageheight()
  {
     $(document).ready(function () {
            if ($("body").width() > 767) {
                var temp = $("footer").height() + $("nav").height();
                var temp2 = $(window).height() - 2
                $(".user-login-wrapper").height(temp2 - temp);
            }

        });
  }

}
