import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-choose-login',
  templateUrl: './choose-login.component.html',
  styleUrls: ['./choose-login.component.css']
})
export class ChooseLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
      this.SetPageheight();
  }

  SetPageheight()
  {
     $(document).ready(function () {
            if ($("body").width() > 767) {
                var temp = $("footer").height() + $("nav").height();
                var temp2 = $(window).height() - 2
                $(".user-login-wrapper").height(temp2 - temp);
            }

        });
  }
}
