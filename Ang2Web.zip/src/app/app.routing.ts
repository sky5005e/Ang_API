import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import {AppComponent} from './app.component';
import {HomeComponent} from './home.component';
import {LoginComponent} from './login/login.component';
import { AuthGuardService } from './_services/auth-guard.service';
import {LogoutComponent} from './logout/logout.component';
import {ChooseLoginComponent} from './login/choose-login/choose-login.component';
import {ResgisteruserComponent} from './login/resgisteruser/resgisteruser.component';
import {UnresgisteruserComponent} from './login/unresgisteruser/unresgisteruser.component';

const appRoutes: Routes = [

    
   {path: 'Admin', loadChildren : './admin/admin.module#AdminModule'},
     {path: 'User', loadChildren : './user/user.module#UserModule'},
     // otherwise redirect to home
    { path: '', redirectTo: 'Home', pathMatch: 'full' },
    { path: 'Home', component: HomeComponent }, 
    { path: 'Login', component: LoginComponent }, 
    { path: 'Logout', component: LogoutComponent },
    { path: 'ChoseLogin', component: ChooseLoginComponent },
    { path: 'RegisterUserLogin', component: ResgisteruserComponent },
    { path: 'UnRegisterUserLogin', component: UnresgisteruserComponent }
];


export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);