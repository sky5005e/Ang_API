package DemoFFpackage;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class DemoclassFF {

	public static WebDriver driver;
	
	public static void main(String[] args) throws Exception {
	
		System.setProperty("webdriver.gecko.driver", "C:\\Selenium\\geckodriver.exe");
		DesiredCapabilities capabilities=DesiredCapabilities.firefox();
		capabilities.setCapability("marionette", true);
		driver = new FirefoxDriver(capabilities);
		driver.manage().window().maximize();
		driver.get("http://hissvr02/Intrepid/Accent/Web/");
		driver.findElement(By.linkText("Login")).click(); 
		WebElement Email = driver.findElement(By.id("txtUsername"));
		Email.sendKeys("priya.kumari@hicom.in");
		WebElement Pin = driver.findElement(By.id("txtUserpin"));
		Pin.sendKeys("22222");
		WebElement Password = driver.findElement(By.id("txtPassword"));
		Password.sendKeys("Abc1234!");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		Thread.sleep(2000);
		
		WebElement drag = driver.findElement(By.id("29"));
		WebElement drop = driver.findElement(By.id("30"));
		 
		Robot robot = new Robot();
		robot.setAutoDelay(500);
		//robot.mouseMove(200, 200);
		robot.keyPress(KeyEvent.VK_F11);
        robot.mousePress(InputEvent.BUTTON1_MASK);
        Dimension fromSize = drag.getSize();
        Dimension toSize = drop.getSize();
        int xCentreFrom = fromSize.width / 2;
        int yCentreFrom = fromSize.height / 2;
        int xCentreTo = toSize.width / 2;
        int yCentreTo = toSize.height / 2;
        Point toLocation = drop.getLocation();
        Point fromLocation = drag.getLocation();
        toLocation.x +=  xCentreTo;
        toLocation.y +=  yCentreTo;
        fromLocation.x +=  xCentreFrom;
        fromLocation.y +=  yCentreFrom;
        robot.mouseMove(fromLocation.x, fromLocation.y);
        robot.mousePress(InputEvent.BUTTON1_MASK);
        robot.mouseMove(((toLocation.x - fromLocation.x) / 2) + fromLocation.x, ((toLocation.y
        		- fromLocation.y) / 2) + fromLocation.y);
        robot.mouseMove(toLocation.x, toLocation.y);
        robot.mouseRelease(InputEvent.BUTTON1_MASK);

        driver.findElement(By.cssSelector("a[title='My Account'] > img")).click();
		Thread.sleep(2000);
        driver.findElement(By.id("upload_link")).click();
		
		StringSelection s = new StringSelection("C:\\Users\\priya kumari\\Pictures\\Screenshot\\35.NewsPost.png");
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s, null);
	
		 Thread.sleep(1000);
		  // Press Enter
		 robot.keyPress(KeyEvent.VK_CONTROL);
         robot.keyPress(KeyEvent.VK_V);
         robot.keyRelease(KeyEvent.VK_V);
         robot.keyRelease(KeyEvent.VK_CONTROL);
         robot.keyPress(KeyEvent.VK_ENTER);
         robot.keyRelease(KeyEvent.VK_ENTER);
		 driver.findElement(By.id("SaveProfileImage")).click();
		 Thread.sleep(3000);
	   driver.close();

	}

}
