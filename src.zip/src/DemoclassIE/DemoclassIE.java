package DemoclassIE;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;

public class DemoclassIE {

	public static void main(String[] args) throws Exception{
		
		System.setProperty("webdriver.ie.driver","C:\\Users\\priya kumari\\Downloads\\IEDriverServer_Win32_2.53.1\\IEDriverServer.exe");
		WebDriver driver=new InternetExplorerDriver();
		driver.get("http://hissvr02/Intrepid/Accent/Web/");
		driver.findElement(By.linkText("Login")).click(); 
		WebElement Email = driver.findElement(By.id("txtUsername"));
		Email.sendKeys("priya.kumari@hicom.in");
		WebElement Pin = driver.findElement(By.id("txtUserpin"));
		Pin.sendKeys("22222");
		WebElement Password = driver.findElement(By.id("txtPassword"));
		Password.sendKeys("Abc1234!");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		Thread.sleep(2000);
		
		// Drag and Drop through Action class
			Actions builder = new Actions(driver);
			WebElement dragElementFrom = driver.findElement(By.id("30"));
			WebElement dropElementTo = driver.findElement(By.id("29"));
			builder.clickAndHold(dragElementFrom).moveToElement(dropElementTo).perform();
			builder.release(dragElementFrom).build().perform();
			Thread.sleep(5000);
			
			driver.findElement(By.cssSelector("a[title='My Account'] > img")).click();
			Thread.sleep(2000);
			driver.findElement(By.id("upload_link")).click();
			
			StringSelection s = new StringSelection("C:\\Users\\priya kumari\\Pictures\\Screenshot\\35.NewsPost.png");
		    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s, null);
		    Robot robot = new Robot();
			
			 Thread.sleep(1000);
			  // Press Enter
			 robot.keyPress(KeyEvent.VK_ENTER);
			 // Release Enter
			 robot.keyRelease(KeyEvent.VK_ENTER);
			 // Press CTRL+V
			 robot.keyPress(KeyEvent.VK_CONTROL);
			 robot.keyPress(KeyEvent.VK_V);
			 // Release CTRL+V
			 robot.keyRelease(KeyEvent.VK_CONTROL);
			 robot.keyRelease(KeyEvent.VK_V);
			 Thread.sleep(1000);
			 robot.keyPress(KeyEvent.VK_ENTER);
			 robot.keyRelease(KeyEvent.VK_ENTER);
			 Thread.sleep(3000);
			 driver.findElement(By.id("SaveProfileImage")).click();
			 Thread.sleep(3000);
			
			driver.close();
			
		
	}

}
