﻿

var app = angular.module('careModule', []);

app.factory('patientService', function ($http) {

    var factory = {};

    factory.getallrecords = function () {

        return $http.get('api/Patient/getpatients');

    }

    return factory;

});